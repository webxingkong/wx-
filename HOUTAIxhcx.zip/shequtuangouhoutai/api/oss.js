
import OSS from 'ali-oss';
export default (conf) => {
    return new OSS(conf);
};
