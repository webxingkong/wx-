const data=[
  "goodimg":{
    "goods_imgurl":'mock/24/admin/path/getgoosList_Image',
    "method":'get'
  },
  export default
  {
    goodimg
  }
]
