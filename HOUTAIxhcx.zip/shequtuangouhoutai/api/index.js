/* 包含多个模块ajax函数
* 封装接口请求函数(一部分例子)
* */
import ajax from './ajax'
//const BASE_URL = '/api'  // 关于跨域
import https from './https.vue'
// import goodslist_img from '../src/pages/Img/index'
// console.log(goodslist_img.goodslist_img);
// 1、根据经纬度获取位置详情
// 此处直接这么写，当请求时会出错，因为后台代码的端口是4000（或域名），与本地的请求端口不一致，自然无法实现跨域ajax请求，需要代理配置
// export const reqAddress = (geohash) => ajax(`/position/${geohash}`)
// import ajax from './ajax'

const BASE_URL = 'http://yhxsever.top/'
export default {
  BASE_URL
}

// const url = https.goodsdata[0].goodimg.url
//请求方法
// export const getHomeCasual = (url)=>ajax(BASE_URL + url);
export const getHomeCasual = (url,name,method)=>ajax(BASE_URL + url,'参数','GET');
export const postHomeCasual = (url,name,method)=>ajax(BASE_URL + url,'','POST');
