import axios from '../src/axios.js'
/*
 ajax请求模块
 封装ajax请求函数
 */
 export default function ajax(url = '',params = {} ,type = 'GET'){
   let promise;
   return new Promise((resolve ,reject)=>{
   //  判断请求的方式
     if(type == 'GET'){
       let paramsStr = '';
       Object.keys(params).forEach( key=>{
         paramsStr += key+'='+params[key]+'&';
       })
       if(paramsStr != ''){
         paramsStr = paramsStr.substr(0,paramsStr.lastIndexOf('&'));
       }
       url+='?'+paramsStr;
       promise = axios.get(url);
     }else{
       promise = axios.post(url,params);
       console.log(params);
     }
     promise.then((res)=>{
       resolve(res.data)
     }).catch((err)=>{
       reject(err);
     })
   })
 }
