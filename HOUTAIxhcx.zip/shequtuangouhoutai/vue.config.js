const path = require('path');


module.exports = {
  publicPath: '/',
  lintOnSave: false,
  configureWebpack: {
    resolve: {
      extensions: ['.js', '.json', '.vue'],
      alias: {
        '@': path.resolve(__dirname, 'src/'),
      },
    },
  },
  devServer: {
    proxy: {
      '/api': { // 匹配所有以 '/api'开头的请求路径
        target: 'http://yhxapi.me/', // 代理目标的基础路径
        changeOrigin: true, // 支持跨域
        secure: false, // 接受 运行在 https 上的服务
        // ws: true,
        pathRewrite: { // 重写路径: 去掉路径中开头的'/api'
          '^/api': ''
        }
      }
    }
  }
};
