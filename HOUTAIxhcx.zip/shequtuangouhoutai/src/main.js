import Vue from 'vue';
import ElementUI from 'element-ui';
import VCharts from 'v-charts';
import 'element-ui/lib/theme-chalk/index.css';
import 'normalize.css/normalize.css';
import './styles/index.scss';
import './styles/common.css';
import App from './App.vue';
import router from './router';
import axios from './axios';
import VueQuillEditor from 'vue-quill-editor'
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'
Vue.use(VueQuillEditor);

axios.defaults.withCredentials=true;//让ajax携带cookie

Vue.prototype.$axios = axios;

// axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
Vue.use(ElementUI);
Vue.use(VCharts);
Vue.config.productionTip = false;

new Vue({

  router,
  render: h => h(App),
}).$mount('#app');
