<template>
  <router-view/>
</template>
<script type="text/javascript">

</script>
