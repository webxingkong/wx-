<template>
	<div class="select Lntegral-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="会员积分" name="first"></el-tab-pane></el-tabs>
			<div class="search">
				<!---->
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
					<el-form-item label="会员名称" style="margin-top: 20px;"><el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input></el-form-item>
					<el-form-item label="手机号" style="margin-top: 20px;"><el-input size="small" v-model="formInline.region" style="width: 120px;"></el-input></el-form-item>
					<el-form-item label="会员状态" style="margin-top: 20px;"><el-input size="small" v-model="formInline.states" style="width: 120px;"></el-input></el-form-item>
					&emsp;
					<el-form-item label="注册时间" style="margin-top: 20px;"><el-input size="small" v-model="formInline.times" style="width: 120px;"></el-input></el-form-item>
					&emsp;
					<el-form-item><el-button size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button></el-form-item>
				</el-form>
				<!---->
			</div>
			<br />


			<div class="right"><el-button size="medium">导出查询结果</el-button></div>
			<br />
			<el-table ref="multipleTable" @row-click="select" :data="integrals_list.slice((currentPage-1)*pagesize,currentPage*pagesize)" tooltip-effect="dark" style="width: 100%">
				<el-table-column label="会员名称">
					<template slot-scope="scope">
						{{ scope.row.wx_name }}
			</template>
		</el-table-column>
		<el-table-column prop="mobile" label="手机号码"></el-table-column>
		<el-table-column prop="user_level_name" label="等级"></el-table-column>
		<el-table-column prop="cumulative_integrals" label="累计积分"></el-table-column>
		<el-table-column prop="user_integrals" label="可用积分"></el-table-column>
		<el-table-column prop="create_time" label="注册时间"></el-table-column>

		<el-table-column fixed="right" label="操作">
			<template slot-scope="scope">
				<el-button type="text" size="small" @click="dialogFormVisible = true">调整积分</el-button>
				<el-button type="text" size="small">查看</el-button>
		</template>
				</el-table-column>
			</el-table>

			<br />
			<!--分页-->
						 <el-pagination class="block"
						     background
						     @size-change="handleSizeChange"
						     @current-change="handleCurrentChange"
						     :current-page="currentPage"
						     :page-sizes="[5, 10, 20, 50]"
						     :page-size="pagesize"
						     layout="total, sizes, prev, pager, next, jumper"
						     :total="total">
						   </el-pagination>
		</div>
		<el-dialog title="积分调整" :visible.sync="dialogFormVisible" width="700px">
			<el-form>
				<el-form-item label="操作" :label-width="formLabelWidth">
					<!-- <el-select v-model="form.types" style="width:20%">
						<el-option label="增加" value="1"></el-option>
						<el-option label="减少" value="2"></el-option>
					</el-select> -->
					<el-select @change="typeschange" v-model="form.types" style="width:20%" placeholder="请选择">
				    <el-option
				      v-for="item in options"
				      :key="item.value"
				      :label="item.label"
				      :value="item.value">
				    </el-option>
				  </el-select>
					&emsp;&emsp;
					<el-input v-model="form.roce" style="width: 72%;" placeholder="请输入积分"></el-input>
				</el-form-item>
				<el-form-item label="备注" :label-width="formLabelWidth" style="line-height:20px">
				<el-input
				  type="textarea"
				  :autosize="{ minRows: 2, maxRows: 4}"
				  placeholder="请输入内容"
				  v-model="form.remarks">
				</el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="dialogFormVisible = false">取 消</el-button>
				<el-button type="primary" @click="leaveladd()">确 定</el-button>
			</div>
		</el-dialog>
	</div>

</template>

<script>
import https from "../../../api/https.vue"
import axios from '../../axios.js';
import Rootpath from "../../../api/index.js"
export default {
	data() {
		return {
			total: 0,
			options: [{
          value: '1',
          label: '增加'
        }, {
          value: '2',
          label: '减少'
        }],
			currentPage: 1,
			pagesize: 5,
			dialogTableVisible: false,
			dialogFormVisible: false,
			form: {
				user_id:null,
				types: '',
				roce: '',
				remarks:''
			},
			clickrow:[],
			formLabelWidth: '80px',
			activeName: 'first',
			integrals_list: [],
			formInline: {
				user: '',
				region: '',
				states: '',
				times: ''
			},



		      };
		    },
				created(){
					this.getData();
				},
			  methods: {
			      handleClose(done) {
			        this.$confirm('确认关闭？')
			          .then(_ => {
			            done();
			          })
			          .catch(_ => {});
			      },
				  onSubmit() {
				  	console.log('submit!');
				  },
				  //分页
				  handleSizeChange(size) {
				    this.pagesize = size
				  },
				  handleCurrentChange(currentPage) {
				    this.currentPage = currentPage
				  },
					typeschange(value){
						this.form.types=value;
					},
					//获取点击的数据
					select(val){
						this.clickform=val;
						console.log(val);
					},
					// 获取数据
					async getData(){
			         const result = await axios.get(Rootpath.BASE_URL+'accumulate');
			         // console.log(result);
							 this.integrals_list = result.data.integrals_list
			 				this.total = result.data.integrals_list.length
			      },
					//积分调整保存
					async leaveladd(index){
						let that=this;
						// that.clickrow.id='';
						// that.form.types='';
						// that.form.roce='';
						// that.form.remarks='';
								axios.post(Rootpath.BASE_URL+'adjustment', {
									user_id: that.clickform.id,
									types: that.form.types,
									roce: that.form.roce,
									remarks  :that.form.remarks
									// data:that.form
					  })
					  .then(function (response) {
					    that.dialogFormVisible=false;
							console.log(that.clickform.id);
							that.getData();
					  })
					  .catch(function (error) {
					    console.log(error);
					  });
					},
					//搜索
					async search() {
							let that = this;
							axios.get(Rootpath.BASE_URL + 'recordsech', {
											params: {
													update_time: that.formInline.update_time,
													integral: that.formInline.integral,
											}
									})
									.then(function (response) {
											console.log(response);
											that.user_list = response.data.user_list
											that.total = response.data.user_list.length
									})
									.catch(function (error) {
											console.log(error);
									});
					},
			 }
};
</script>

<style scoped>
	.block{
		text-align: right;
	}
	.text {
		display: flex;
		left: 20px;
		position: relative;
		top: 15px;
	}
	.right {
		text-align: right;
	}
	.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	} /*border: solid 1rpx #007AFF;
	*/
	.search {
		height: 70px;
		background-color: #f5f5f5;
	}
</style>
