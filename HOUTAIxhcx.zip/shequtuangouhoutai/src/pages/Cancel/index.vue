<template>
  <div class="Cancel-page" style="margin: 20px;">
	  <el-tabs v-model="activeName">
	     <el-tab-pane label="整单退款" name="1">
			<div><!-- 输入框 -->
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				  <el-form-item label="会员名称" style="margin-top: 20px;">
				    <el-input  size="small" v-model="formInline.name" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="订单编号：" style="margin-top: 20px;">
				    <el-input  size="small" v-model="formInline.order_number" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="审核状态：" style="margin-top: 20px;">
				    <el-input  size="small" v-model="formInline.state" style="width: 120px;"></el-input>
				  </el-form-item>&emsp;
				  <el-form-item label="下单时间：" style="margin-top: 20px;">
				    <!-- <el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input> -->
            <el-date-picker
              v-model="formInline.create_time"
              type="daterange"
              style="width: 380px;"
              size="small"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期">
            </el-date-picker>
				  </el-form-item>&emsp;
				  <el-form-item style="margin-top: 20px;">
				    <el-button  size="small" @click="searcfinfo" type="primary">搜索</el-button>
				  </el-form-item>
				</el-form>
				<div class="right">
				<el-button size="medium">导出查询结果</el-button>
				</div>
			</div>
					<div>
						<el-table
						    :data="order_info.slice((currentPage-1)*pagesize,currentPage*pagesize)"
						    stripe
                @row-click="select"
						    style="width: 100%">
						    <el-table-column
						      prop="order_number"
						      label="订单号"
                  align="center">
						    </el-table-column>
						    <el-table-column
						      prop="user_name"
						      label="团长名称">
						    </el-table-column>
                <el-table-column
						      prop="order_sum"
						      label="订单总价">
						    </el-table-column>
                <el-table-column
						      prop="discount"
						      label="优惠金额">
						    </el-table-column>
                <el-table-column
						      prop="payable"
						      label="应付金额">
						    </el-table-column>
                <el-table-column
						      prop="delivery_date"
						      label="发货日期">
						    </el-table-column>
						    <el-table-column
						      prop="community_name"
						      label="店铺">
						    </el-table-column>
                <el-table-column
						      prop="order_state"
						      label="订单状态">
						    </el-table-column>
                <el-table-column
						      prop="order_remarks"
						      label="备注">
						    </el-table-column>
                <el-table-column
						      prop="order_cancel_state_name"
						      label="审核状态">
						    </el-table-column>
							<el-table-column
							  prop="address"
							  label="操作">
                <template slot-scope="scope">
        					<el-button type="text">详情</el-button>
        					<el-button type="text" v-if="scope.row.order_cancel_state_name=='未审核'" @click="adopt($event,scope.row)">通过</el-button>
        					<el-button type="text" v-if="scope.row.order_cancel_state_name=='未审核'" @click="adopt($event,scope.row)">拒绝</el-button>
        				</template>
							</el-table-column>
						  </el-table>
              <!--分页-->
          		<el-pagination
          			class="pagination"
          			background
          			@size-change="handleSizeChange"
          			@current-change="handleCurrentChange"
          			:current-page="currentPage"
          			:page-sizes="[5, 10, 20, 50]"
          			:page-size="pagesize"
          			layout="total, sizes, prev, pager, next, jumper"
          			:total="total"
          		></el-pagination>
					</div>
		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
   data() {
        return {
          infodata:[],
  			  activeName: '1',
  			  formInline: {
           create_time: '',
           order_number: '',
           name:'',
           state:''
          },

			    num: 1,
          clickrow:[],
          order_info: [],
          info: {
            order_number: "",
            order_cancel_state: null
          },//编辑     拒绝操作数据
          total: 0,
    			currentPage: 1,
    			table_index: 999,
    			pagesize: 5,
          options: [{
          value: '选项1',
          label: '未审核'
        }, {
          value: '选项2',
          label: '已拒绝'
        }, {
          value: '选项3',
          label: '审核通过'
        }]
        }
      },
      created() {
    		this.getData();
    	},
	   methods: {
	        handleChange(value) {
	          console.log(value);
	        },
          handleSizeChange(size) {
      			this.pagesize = size;
      		},
      		handleCurrentChange(currentPage) {
      			this.currentPage = currentPage;
      		},
          //查询
          async searcfinfo() {
            let that = this;
            let filedate=that.formInline.create_time;
            let date1='';
            for (var i = 0; i < filedate.length; i++) {
              var d = new Date(filedate[i]);
              d=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
              if (date1=="") {
                date1=d;
              }else {
                date1 = date1+' - '+d
              }
            }
            const result = await axios.get(
              Rootpath.BASE_URL
              + 'getOrderList_search?state='
              +that.formInline.state
              +'&&create_time='+date1+'&&name='
              +that.formInline.name
              +'&&order_number='+that.formInline.order_number);
              this.order_info = result.data.order_info;
              // console.log(this.tableData);
              this.total = result.data.order_info.length;
          },
          //获取点击的数据
      		select(val){
      			this.clickrow=val;
            console.log(val);
      		},
          //通过
          async adopt(e,row){
            let es=e.target.innerHTML;
            if (es=="通过") {
              es=2
            }else if (es=="拒绝") {
              es=-1
            }else {
              es=1
            }
            let that = this;
            let info={
              order_number: row.order_number,
              order_cancel_state: es,
            };
            axios.post(Rootpath.BASE_URL + 'changeCxamine', {
              info:info
             })
             .then(function (response) {
               that.getData();
             })
             .catch(function (error) {

            });
          },
          // 获取数据
          async getData() {
              const result = await axios.get(Rootpath.BASE_URL + 'getOrderList');
              this.order_info = result.data.order_info;
              // console.log(this.tableData);
              this.total = result.data.order_info.length;
          },
	      },
};
</script>
<style>
	.text{
		    display: flex;
			align-items: center;
		    left: 20px;
		    position: relative;
		    top: 5px;
		  }
		.search {
		  height: 65px;
		  background-color: #F5F5F5;
		  position: relative;
		  top: 16px;
		}
		.search-frame {
		  width: 100%;
		  height: 100px;
		  margin: auto;
		  background-color: #ffffff;
		}
		.paging{
				position: fixed;
				right:0px;
				bottom:0px;
				background: #FAFAFA;
				width:100%;
				height:40px;
				float: right;
				line-height: 0px;
				z-index: 999;
				 box-shadow: darkgrey 10px 10px 30px 5px ;
			}
</style>
