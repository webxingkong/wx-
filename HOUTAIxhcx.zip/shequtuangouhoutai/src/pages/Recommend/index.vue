<template>
  <div class="Service-page" style="margin: 20px;">
	  <el-tabs v-model="activeName" @tab-click="handleClick">
	     <el-tab-pane label="团长推荐" name="first">
				<div style="width:15%;">
					<el-form :label-position="labelPosition" label-width="100px" :model="formLabelAlign">
					  <el-form-item label="推荐现金奖励" >
					    <el-input v-model="formLabelAlign.name" placeholder="0/元"></el-input>
					  </el-form-item>
					  <el-form-item label="推荐佣金">
					    <el-input v-model="formLabelAlign.region" placeholder="0.00/%"></el-input>
					  </el-form-item>
					  <el-form-item label="推荐转发标题">
					    <el-input v-model="formLabelAlign.type" placeholder="长度≤20/%"></el-input>
					  </el-form-item>
					</el-form>
				</div>
				<p>推荐转发图片： 图片尺寸为宽度500px，高度500px，大小≤1MB，支持JPG、PNG、JPEG</p>
				<img src="../../assets/404.png"  style="height: 500px; width: 500px;"/>
		 </el-tab-pane>
		 <el-button type="primary">保存</el-button>
	   </el-tabs>
  </div>
</template>
<script>
export default {
  name: 'first',
  components: {},
   data() {
        return {
          labelPosition: 'right',
          formLabelAlign: {
            name: '',
            region: '',
            type: ''
          },
		  dialogVisible: false,
		   activeName: 'first',
		   formInline: {
		            user: '',
		            region: ''
		          },
        };
      }
    }
</script>
<style scoped>

</style>
