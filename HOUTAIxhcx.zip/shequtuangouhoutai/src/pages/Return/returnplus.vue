<template>
	<div class="select returnplus-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="新增退回清单" name="first"></el-tab-pane></el-tabs>
			<el-button size="small" type="primary" @click="Purchaseorder">请选择采购单</el-button>
			<br />
			<h4>基本信息</h4>
			<el-row :gutter="20">
  			<el-col :span="6">
					<div class="grid-content bg-purple">
						仓库：{{info.warehouse}}
					</div>
				</el-col>
  			<el-col :span="6">
					<div class="grid-content bg-purple">
						采购类型：{{info.purchase_type_name}}
					</div>
				</el-col>
  			<el-col :span="6">
					<div class="grid-content bg-purple">
						采购员/供应商：{{info.purchaser_name}}
					</div>
				</el-col>
  			<el-col :span="6">
					<div class="grid-content bg-purple">
						源采购单号：{{info.purchase_bill}}
					</div>
				</el-col>
			</el-row>
			<h4>采购清单退回</h4>
			<el-table ref="multipleTable" :data="goodsList" tooltip-effect="dark" style="width: 100%">
				<el-table-column align="center" prop="goods_number" label="序号"></el-table-column>
				<el-table-column align="center" prop="product_name" label="商品名称"></el-table-column>
				<el-table-column align="center" prop="unit" label="单位"></el-table-column>
				<el-table-column align="center" prop="received_count" label="收货数量"></el-table-column>
				<el-table-column align="center" prop="purchase_price" label="收货单价"></el-table-column>
				<el-table-column align="center" prop="already_return_count" label="已退数量"></el-table-column>
				<el-table-column align="center" prop="return_count" label="退货数量">
					<template slot-scope="scope">
							<el-input v-model="scope.row.return_count" @input="countchange(scope.row)" size="mini" style="width:100px"></el-input>
					</template>
				</el-table-column>
				<el-table-column align="center" prop="return_price" label="退货单价">
					<template slot-scope="scope">
							<el-input v-model="scope.row.return_price" @input="pricechange(scope.row)" size="mini" style="width:100px"></el-input>
					</template>
				</el-table-column>
				<el-table-column align="center" prop="return_sum" label="退货小计(元)">
					<template slot-scope="scope">
							<el-input v-model="scope.row.return_sum" readonly size="mini" style="width:100px"></el-input>
					</template>
				</el-table-column>
				<el-table-column align="center" prop="product_desc" label="备注"></el-table-column>
				<el-table-column align="center" label="操作">
					<template slot-scope="scope">
						<el-button type="text" size="small" @click="deleterow(scope.$index,goodsList)">删除</el-button>
					</template>
				</el-table-column>
			</el-table>
			<br>
			<div class="footer top">
				<span>合计：</span>
				<span style="color: #436BE5">{{Calculation}}</span>
			</div><br>
			<span style="line-height:50px">备注 ：</span>
			<el-input type="textarea" autosize placeholder="请输入内容" v-model="textarea1" style="width: 200px;"></el-input>
			<br />
			<br />
			<br />
			<el-button size="small" @click="Submitaudit" type="primary">提交审核</el-button>
			<el-button size="small" type="primary" @click="save">保存</el-button>
			<el-button size="small"  @click="save">取消</el-button>
		</div>
		<!--弹窗-->
		<el-dialog title="请选择一个采购单" :visible.sync="dialogVisible" width="75%">
			<span slot="footer" class="dialog-footer">
				<el-form :inline="true" class="flex">
					<el-form-item label="状态">
						<el-select v-model="value" placeholder="请选择" size="small" style="width: 130px;">
							<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"></el-option>
						</el-select>
					</el-form-item>
					&emsp;
					<el-form-item label="供应商/采购员"><el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input></el-form-item>
					<el-form-item label="日期">
						<el-date-picker
	      			v-model="formInline.region"
      			type="datetime"
						size="small"
      			placeholder="选择日期时间"
						style="width: 220px;">
    				</el-date-picker>
					</el-form-item>
					<el-form-item label="单号"><el-input size="small" v-model="formInline.states" style="width: 120px;"></el-input></el-form-item>
					&emsp;

					<el-form-item><el-button size="small" type="primary" @click="search">搜索</el-button></el-form-item>
				</el-form>
				<br />
				<br />
				<el-table style="width: 100%" :data="purchaseBillList.slice((currentPage-1)*pagesize,currentPage*pagesize)">
					<el-table-column align="cente" prop="purchase_bill" label="采购单"></el-table-column>
					<el-table-column align="cente" prop="create_date" label="创建时间"></el-table-column>
					<el-table-column align="cente" prop="producer" label="制单人"></el-table-column>
					<el-table-column align="cente" prop="bill_state" label="状态"></el-table-column>
					<el-table-column align="cente" fixed="right" label="操作">
						<template slot-scope="scope">
							<el-button type="text" size="small">整单退</el-button>
							<el-button type="text" size="small">部分退</el-button>
						</template>
					</el-table-column>
				</el-table>
				<!--分页-->
				<el-pagination class="pagination"
						background
						@size-change="handleSizeChange"
						@current-change="handleCurrentChange"
						:current-page="currentPage"
						:page-sizes="[5, 10, 20, 50]"
						:page-size="pagesize"
						layout="total, sizes, prev, pager, next, jumper"
						:total="total">
					</el-pagination>
				<br />
				<br />
				<el-button @click="dialogVisible = false">取 消</el-button>
				<el-button type="primary" @click="dialogVisible = false">确 定</el-button>
			</span>
		</el-dialog>
	</div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			total: 0,
		 	currentPage: 1,
		 	pagesize: 5,
			dialogVisible: false,
			textarea1: '',
			allreturn_sum:0,//总价
			activeName: 'first',
			info: [],
			examineinfo: {
    	company_id: 1,    //公司城市表id
    	warehouse_id: 1,  //仓库表id
    	purchaser_id: 1, //采购商表id
    	purchase_bill_id: 9,  //采购单表id
    	purchase_bill: "CGD4600537445",//采购单号
    	record: [],
    	goodsList: [],
    	sum: 0,
    	remarks: ""
	  },
		formInline:{
			user:'',
			region:'',
			states:''

		},
			goodsList:[],
			purchaseBillList: [],
			options: [
				{
					value: '选项1',
					label: '全部收货'
				},
				{
					value: '选项2',
					label: '待收货'
				}
			],
			value: ''
		};
	},
	//计算属性
	computed:{
			 Calculation:function(){
	 			let gl=this.goodsList;
	 			let t=0;
	 			for (var i = 0; i < gl.length; i++) {
	 				t+=gl[i].return_price * gl[i].return_count;
	 			}
	 			return t;
	 		}
	 },
	created() {
			this.getData();
	},
	methods: {
		deleterow(index,row){
			row.splice(index, 1);
		},
		handleSizeChange(size) {
			this.pagesize = size
		},
		handleCurrentChange(currentPage) {
			this.currentPage = currentPage
		},
		//搜索
    async search() {
        let that = this;
        axios.get(Rootpath.BASE_URL + 'choiceReturnPurchaser_search', {
                params: {
                    purchase_bill: that.formInline.states,
                    create_date: that.formInline.region,
                    state: that.value,
										type:that.formInline.user,
                    purchaser_name: that.formInline.user
                }
            })
            .then(function (response) {
                console.log(response);
								that.purchaseBillList=response.data.info.purchaseList;
								that.total=response.data.info.purchaseList.length;
            })
            .catch(function (error) {
                console.log(error);
            });
    },
		//提交审核
		Submitaudit(){
			let that=this;
			axios.post(Rootpath.BASE_URL + 'addReturnPurchaserReturn', {
				company_id: that.info.company_id,    //公司城市表id
				warehouse_id: that.info.warehouse_id,  //仓库表id
				purchaser_id: that.info.purchaser_id, //采购商表id
				purchase_bill_id: that.info.purchase_bill_id,  //采购单表id
				purchase_bill: that.info.purchase_bill,//采购单号
				record: that.info.record,
				goodsList: that.info.goodsList,
				sum: that.info.sum,
				remarks: that.info.remarks
        })
        .then(function (response) {
            that.dialogFormVisible = false;
            console.log(that.clickform.id);
        })
        .catch(function (error) {
            console.log(error);
        });
		},
		//请选择采购单
		async Purchaseorder(){
			this.dialogVisible = true;
			const result = await axios.get(Rootpath.BASE_URL + 'choiceReturnPurchaser');
			console.log(result.data);
			this.purchaseBillList=result.data.info;
			this.total=result.data.info.length;
		},
		//保存
		save(){
			this.$router.push({ path: '/profile/fail'});
		},
		// 获取数据
		async getData() {
			var return_number = this.$route.query.return_number;
			const result = await axios.get(Rootpath.BASE_URL + 'addReturnPurchaserReturnPage?pno=' + return_number);
			console.log(result.data.info);
			this.info = result.data.info;
			this.goodsList=result.data.info.goodsList;
		},
		//详情
		Accessdetails(Accessdetails) {
			this.$router.push({ path: '/library/Access/Accessdetails', query: { id: Accessdetails } });
		},
		deleteRow(index, rows) {
			rows.splice(index, 1);
		},
		//分页
		handleSizeChange(size) {
		  this.pagesize = size;
		},
		handleCurrentChange(currentPage) {
		  this.currentPage = currentPage;
		},
		countchange(row){
			row.return_sum = row.return_price * row.return_count;
		},
		pricechange(row){
			row.return_sum = row.return_price * row.return_count;
		},

	}
};
</script>

<style scoped>
.returnplus-page h4{
	padding-left: 10px;
	background: #f5f5f5;
	line-height: 30px;
}
	.block{
		text-align: right;
	}
.grid-content {
	font-size: 8px;
}
.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select {
	margin: auto;
	width: 96%;
	background-color: #ffffff;
} /*border: solid 1rpx #007AFF;
*/
.footer{
	text-align: right;
}

</style>
