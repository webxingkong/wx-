<template>
	<div class="select">
		<div class="select-table">
			<el-tabs v-model="activeName" @tab-click="handleClick"><el-tab-pane label="退回详情" name="first"></el-tab-pane></el-tabs>
			<h4>基本信息</h4>
			<el-row>
				<!--类型-->
				<el-col :span="8">
					<div class="grid-content bg-purple flex_c_m">
						<name>
							单号：AJS52635468
							<br />
							<br />
							制单人：代号四十七
							<br />
							<br />
							采购员/供应商：南宁绿源山庄
							
						</name>
					</div>
				</el-col>
				<!--仓库-->
				<el-col :span="8">
					<div class="grid-content bg-purple flex_c_m">
						<name>
							仓库：南宁农贸市场
							<br />
							<br />
							数据日期：2019-10-20 15:20:59
							<br />
							<br />
							原采购单号：SHD56985645
						</name>
					</div>
				</el-col>
				<!--交货日期-->
				<el-col :span="8">
					<div class="grid-content bg-purple flex_c_m">
						<name>
							单据状态：已完成
							<br />
							<br />
						退货金额：265.0元
						</name>
					</div>
				</el-col>
			</el-row>
			<h4>采购退回清单</h4>
			<el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
				<el-table-column width="55"></el-table-column>
				<el-table-column prop="order" label="序号" width="100">
				</el-table-column>
				<el-table-column prop="Name" label="商品名称" width="160"></el-table-column>
				<el-table-column prop="Company" label="单位" width="120"></el-table-column>
				<el-table-column prop="amount" label="退货数量" width="130"></el-table-column>
				<el-table-column prop="price" label="退货单价" width="130"></el-table-column>
				<el-table-column prop="Subtotal" label="退货小计(元)" width="140"></el-table-column>
				<el-table-column prop="Remarks" label="备注"></el-table-column>
				
			</el-table>
			<div class="footer top">
				<span>合计：</span>
				<span style="color: #436BE5">0.5</span>
			</div>
			<div>
				<span>备注：</span>
				<span style="color: #436BE5">暂无</span>
			</div>
			<br />
			<h4>单据操作清单历史</h4>
			<el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
				<el-table-column prop="order" label="序号" width="100"></el-table-column>
				<el-table-column prop="people" label="操作人" width="200"></el-table-column>
				<el-table-column prop="time" label="时间" width="240"></el-table-column>
				<el-table-column prop="History" label="操作历史"></el-table-column>
			</el-table>
			<br><br>
			<el-button size="small"  type="primary">返回</el-button>
		</div>
	</div>
</template>

<script>
export default {
	data() {
		return {
			activeName: 'first',
			tableData: [
				{
					Name:'八宝粥/500克',
					Company: '斤',
					order:'01',
					amount:'20',
					price:'￥2.0',
					Subtotal:'￥20.0',
					Remarks:'？',
					people:'詹三',
					time:'2018-05-16 16:15:02',
					History:'生成采购单'
					
				},
				{
					Name:'八宝粥/500克',
					Company: '斤',
					order:'01',
					amount:'20',
					price:'￥2.0',
					Subtotal:'￥20.0',
					Remarks:'？',
					people:'詹三',
					time:'2018-05-16 16:15:02',
					History:'全部收货'
				}
			]
		};
	},
	methods: {
		onSubmit() {
			console.log('submit!');
		},
		//详情
		Accessdetails(Accessdetails) {
			this.$router.push({ path: '/library/Access/Accessdetails', query: { id: Accessdetails } });
		},
		deleteRow(index, rows) {
			rows.splice(index, 1);
		}
	}
};
</script>

<style scoped>
.grid-content {
	height: 160px;
	font-size: 8px;
}
.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select {
	margin: auto;
	width: 96%;
	background-color: #ffffff;
} /*border: solid 1rpx #007AFF;
*/
.footer{
	text-align: right;
}

</style>
