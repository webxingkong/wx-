<template>
	<div class="select Return-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="采购退回" name="first"></el-tab-pane></el-tabs>

			<div class="search">
				<!---->
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
					<el-form-item label="供应商" style="margin-top: 20px;"><el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input></el-form-item>
					<el-form-item label="采购单" style="margin-top: 20px;"><el-input size="small" v-model="formInline.region" style="width: 120px;"></el-input></el-form-item>
					<el-form-item label="采购类型" style="margin-top: 20px;"><el-input size="small" v-model="formInline.states" style="width: 120px;"></el-input></el-form-item>
					&emsp;

					<el-form-item><el-button size="small" type="primary" style="margin-top: 23px;">搜索</el-button></el-form-item>
				</el-form>
				<!---->
			</div>
			<br />
			<br />
			<div class="flex_fcs">
				<el-button @click="dialogframe()" size="small" type="primary">新增退回单</el-button>
				<el-button size="medium" >导出查询结果</el-button>
			</div>

			<br />
			<el-table ref="multipleTable" :data="returnPurchaser.slice((currentPage-1)*pagesize,currentPage*pagesize)" tooltip-effect="dark" style="width: 100%">
				<el-table-column align="center" prop="return_number" label="采购单号"></el-table-column>
				<el-table-column align="center" prop="return_sum" label="退货金额"></el-table-column>
				<el-table-column align="center" prop="purchase_bill" label="原采购单"></el-table-column>
				<el-table-column align="center" prop="purchaser_name" label="供应商/采购员"></el-table-column>
				<el-table-column align="center" prop="warehouse" label="仓库"></el-table-column>
				<el-table-column align="center" prop="remarks" label="备注"></el-table-column>、
				<el-table-column align="center" prop="producer" label="制单人"></el-table-column>
				<el-table-column align="center" prop="bill_state" label="状态" ></el-table-column>
						<el-table-column fixed="right" label="操作">
					<template slot-scope="scope">
						<el-button @click="dialogs(scope.row)" type="text" size="small">详情</el-button>

						<el-button type="text" size="small">导出</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!--分页-->
			<el-pagination class="pagination"
					background
					@size-change="handleSizeChange"
					@current-change="handleCurrentChange"
					:current-page="currentPage"
					:page-sizes="[5, 10, 20, 50]"
					:page-size="pagesize"
					layout="total, sizes, prev, pager, next, jumper"
					:total="total">
				</el-pagination>
		</div>
	</div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			activeName: 'first',
			returnPurchaser: [],
			total: 0,
		 	currentPage: 1,
		 	pagesize: 5,
			formInline: {
				user: '',
				region: '',
				states: '',
				times: ''
			},


		};
	},
	created() {
			this.getData();
	},
	methods: {
		handleSizeChange(size) {
			this.pagesize = size;
		},
		handleCurrentChange(currentPage) {
			this.currentPage = currentPage;
		},
		//新增
		dialogframe(row){
		 this.$router.push({path:'/profile/fail/Returnplus'});
		},
		//详情
		dialogs(row){
		 this.$router.push({path:'/profile/fail/returnfeeling',query: {return_number:row.return_number}});
		},
		// 获取数据
		async getData() {
			const result = await axios.get(Rootpath.BASE_URL + 'returnPurchaserList');
			console.log(result);
			this.returnPurchaser = result.data.returnPurchaser;
			this.total = result.data.returnPurchaser.length;
		},

		},

};
</script>

<style scoped>
	.block{
		text-align: right;
	}
.footer {
	height: 44px;
	text-align: right;
}
.right {
	text-align: right;
	margin-top: -33px;
}

p {
	position: relative;
	top: -12px;
}
.text {
	display: flex;
	left: 20px;
	position: relative;
	top: 15px;
}

h3 {
	color: #436be5;
	border-bottom: solid 2px #436be5;
	margin-left: 20px;
}
.text-frame-member {
	width: 100px;
	position: relative;
	top: 10px;
}
.text-frame {
	height: 50px;
	width: 100%;
	background-color: #ffffff;
	border-bottom: solid 1px #f0f2f0;
}

.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select {
	margin: auto;
	width: 96%;
	background-color: #ffffff;
} /*border: solid 1rpx #007AFF;
*/
.search {
	height: 70px;
	background-color: #f5f5f5;
}
.search-Button {
	margin-left: 20px;
}
</style>
