<template>
  <el-form :model="goodsInfo" ref="goodsInfo" label-width="150px" class="demo-goodlists editdashboard">
    <p class="title">
      <span>商品信息</span>
    </p>
    <el-form-item class="leftlabel" label="商品名称：">
      <el-input class="inputtext" v-model="goodsInfo.goods_sort_name"></el-input>
    </el-form-item>
    <el-form-item class="leftlabel" label="商品分类：">
      <el-select class="inputtext" v-model="sort_name" placeholder="请选择活动区域">
        <el-option
         v-for="item in goodsInfo.goods_sort"
        :key="item.id"
        :label="item.sort_name"
        :value="item.id">
      </el-option>

      </el-select>
    </el-form-item>
    <el-form-item class="leftlabel" label="商品编码：">
      <el-input class="inputtext" v-model="goodsInfo.goods_brand_id"></el-input>
    </el-form-item>
    <el-form-item class="leftlabel" label="商品品牌：">
      <el-input class="inputtext" v-model="goodsInfo.goods_brand"></el-input>
    </el-form-item>
    <el-form-item class="leftlabel" label="商品产地：">
      <el-input class="inputtext" v-model="goodsInfo.goods_source"></el-input>
    </el-form-item>
    <el-form-item class="leftlabel" label="采购类型：">
      <el-button-group>
        <el-button size="small" :autofocus="true">供应商送货</el-button>
        <el-button size="small">市场自采</el-button>
        <el-checkbox class="ml10" label="临时" name="type">临时指定</el-checkbox>
      </el-button-group>
    </el-form-item>
    <el-form-item class="leftlabel" label="供应商：">
      <el-select class="inputtext" v-model="purchaser_name" placeholder="请选择活动区域">
        <el-option
          v-for="item in supplier"
          :key="item.id"
          :label="item.purchaser_name"
          :value="item.id">
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item class="leftlabel" label="标签：">
     <el-radio-group v-model="label">
       <el-radio
       v-for="item in goodsInfo.label"
       :key="item.id"
       :label="item.product_label_name"
       :value="item.id"
       ></el-radio>
     </el-radio-group>
   </el-form-item>
   <el-form-item class="leftlabel" label="主图：">
      <!-- <img :src="img.img_url" alt="" style="height:100px;width:100px;border:1px solid red"> -->
      <!-- <img width="100%" :src="img.img_url" alt=""> -->
      <el-upload
      action="https://jsonplaceholder.typicode.com/posts/"
      list-type="picture-card"
      :on-preview="handlePictureCardPreview"
      :file-list="mainimg"
      :on-remove="handleRemove">
        <i class="el-icon-plus"></i>
      </el-upload>
      <p class="Identification">主图至少上传一张,建议尺寸：800*800,支持GIF、PNG、IPG、JPEG格式,大小不超过1M</p>
        </el-upload>
    </el-form-item>
    <el-form-item class="leftlabel" label="封面图：" prop="name">
     <el-upload
     action="https://jsonplaceholder.typicode.com/posts/"
     list-type="picture-card"
     :on-preview="handlePictureCardPreview"
     :file-list="coverimg"
     :on-remove="handleRemove">
       <i class="el-icon-plus"></i>
     </el-upload>
     <el-dialog :visible.sync="dialogVisible">
     <img width="100%" alt="">

     </el-dialog>
     <p class="Identification">团长店铺首页显示图片,建议尺寸：750*400，支持GIF、PNG、IPG、JPEG格式,大小不超过1M</p>
       </el-upload>
   </el-form-item>
   <el-form-item class="leftlabel" label="主图视频：" prop="video">
      <el-upload
      action="https://jsonplaceholder.typicode.com/posts/"
      list-type="picture-card"
      :on-preview="handlePictureCardPreview"
      :on-remove="handleRemove">
        <i class="el-icon-plus"></i>
      </el-upload>
      <el-dialog :visible.sync="dialogVisible">
      <img width="100%" alt="">

      </el-dialog>
      <!-- <el-upload
      class="avatar-uploader el-upload--text"
      :action="uploadUrl"
      :show-file-list="false"
      :on-success="handleVideoSuccess"
      :before-upload="beforeUploadVideo"
      :on-progress="uploadVideoProcess">
        <video v-if="videoForm.Video !='' && videoFlag == false" :src="videoForm.Video" class="avatar" controls="controls">您的浏览器不支持视频播放</video>
        <i v-else-if="videoForm.Video =='' && videoFlag == false" class="el-icon-plus avatar-uploader-icon"></i>
        <el-progress v-if="videoFlag == true" type="circle" :percentage="videoUploadPercent" style="margin-top:30px;"></el-progress>
    </el-upload> -->
    </el-form-item>
    <p class="title">
      <span>商品规格</span>
    </p>
    <el-form-item class="leftlabel" label="单位：">
      <el-radio-group v-model="childrenunits.unit">
        <el-radio
        v-for="item in childrenunits"
        :key="item.id"
        :label="item.unit"
        :value="item.id"
        ></el-radio>
      </el-radio-group>
    </el-form-item>
    <el-form-item label="描述：" class="describe leftlabel" prop="details">
     <el-input  class="inputtext" type="textarea" v-model="goodsInfo.details"></el-input>
   </el-form-item>

   <el-form-item class="leftlabel" label="商城价：">
     <el-input class="inputtext" v-model="units.product_spurious_price"></el-input>
     <span>&nbsp;&nbsp;&nbsp;元&nbsp;&nbsp;&nbsp;(精确到0.01)</span>
   </el-form-item>
   <el-form-item class="leftlabel" label="划线价：">
      <el-input class="inputtext" v-model="units.product_price"></el-input>
      <span>&nbsp;&nbsp;&nbsp;元&nbsp;&nbsp;&nbsp;(精确到0.01)</span>
    </el-form-item>
    <el-form-item class="leftlabel" label="团长等级佣金比列：">
      <el-input class="inputtext" v-model="units.commission"></el-input>
    </el-form-item>
    <el-form-item class="leftlabel" label="库存：">
      <el-input class="inputtext" v-model="units.spurious_sale_amount"></el-input>
    </el-form-item>
    <el-form-item class="leftlabel" label="销量：">
      <el-input class="inputtext" v-model="units.product_stock"></el-input>
    </el-form-item>
    <p class="title">
      <span>其他</span>
    </p>
      <div class="flex">
        <el-form-item class="leftlabel" label="商品排序：">
          <el-input class="inputtextinline" v-model="other.Commodity_ordering"></el-input>
        </el-form-item>
        <el-form-item class="leftlabelinline" label="打印排序：">
          <el-input class="inputtextinline" v-model="other.Print_sort"></el-input>
        </el-form-item>
        <el-radio-group v-model="other.redioval" style="line-height:40px;width:360px">
          <el-radio label="标品"></el-radio>
          <el-radio label="非标品"></el-radio>
          <el-checkbox class="ml10" v-model="other.check" label="商城中不显示基础单位" name="type"></el-checkbox>
        </el-radio-group>
      </div>
    <el-form-item class="leftlabel" label="到货时间：">
      <el-radio-group v-model="other.arrivetime">
        <el-radio label="跟随时间设定"></el-radio>
        <el-radio label="单独设定到货时间"></el-radio>
      </el-radio-group>
      到货时间&nbsp;&nbsp;&nbsp;
      <el-date-picker
      v-model="other.arrivedatetime"
      type="datetime"
      placeholder="选择日期时间"
      default-time="12:00:00">
      </el-date-picker>
    </el-form-item>
    <el-form-item class="leftlabel" label="图文详情描述">
      <el-upload
      action="https://jsonplaceholder.typicode.com/posts/"
      list-type="picture-card"
      :on-preview="handlePictureCardPreview"
      :on-remove="handleRemove">
        <i class="el-icon-plus"></i>
      </el-upload>
      <el-dialog :visible.sync="dialogVisible">
      <img width="100%" alt="">

      </el-dialog>
      <p class="Identification">建议尺寸宽度800,高度不限,支持GIF、PNG、IPG、JPEG格式,大小不超过1M</p>
        </el-upload>
    </el-form-item>
    <el-form-item style="margin-left:2%">
      <el-button type="primary" @click="savereturn()">保存并返回到列表页</el-button>
      <!-- <el-button @click="resetForm('goodsInfo')">保存并继续新增</el-button> -->
      <el-button @click="resetForm('goodsInfo')">取消</el-button>
    </el-form-item>
</el-form>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      king:'',
      dialogVisible:false,
      dialogImageUrl:'',
      redioname:'',
      goodsInfo:{},
      goods_sort:[],
      sort_name:'',
      labelunnit:'',
      purchaser_name:'',
      childrenunits:{},
      label:'',
      other:{
        Commodity_ordering:0,
        Print_sort:0,
        check:true,
        redioval:'标品',
        arrivetime:'跟随时间设定',
        arrivedatetime:''
      },
      mainimg:[{
        name:'ha',
        url:''
      }],
      coverimg:[{
        name:'ha',
        url:''
      }],
      // supplier:[],
      // label:[],
      // img:[],
      // units:{},
      // childrenunits:[],
      // goodsSort:[],
      supplier:[],
      purchaseman:[],
      unit:[],
      units:{},
    }
  },
  created(){
    this.getData();
  },
  methods:{
    // 获取数据
    async getData (){
        // const result = await getHomeCasual('mock/24/admin/getProductInfo?gid=1','tupian');
        // const result = await axios.get( 'mock/24/admin/getProductInfo?gid='+this.tabPosition);
        var routerParams = this.$route.query.gid;
        const result = await axios.get( Rootpath.BASE_URL +'getProductInfo?gid=' + routerParams);
        console.log(result);
        this.goodsInfo = result.data.goodsInfo;
        this.goods_sort=result.data.goodsInfo.goods_sort;//array   childrenunits
        this.supplier=result.data.goodsInfo.supplier;
        this.purchaseman=result.data.purchaseman;
        this.unit=result.data.unit;
        // console.log(this.goodsInfo.img[0].image_name);
        // this.mainimg[0].url=this.goodsInfo.img[0].img_url;
        // this.mainimg[0].name=this.goodsInfo.img[0].image_name;
        this.coverimg=this.goodsInfo.img[1].img;
        this.childrenunits=result.data.unit;
        this.units=result.data.goodsInfo.units;
    },
    savereturn(){
      let that = this;
      axios.post( Rootpath.BASE_URL +'editProduct', {
           goods_info: that.goodsInfo,
           other:that.other
               // data:that.form
       })
       .then(function (response) {
           // that.dialogFormVisible = false;
           console.log(response);
       })
       .catch(function (error) {
           console.log(error);
       });
    },
    handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePictureCardPreview(file) {
        this.dialogImageUrl = file.url;
        this.dialogVisible = true;
      }
  }
};
</script>

<style scoped>
.inputtext{
  width: 220px
}
/* 标题 */
.title{
  background: #F5F5F5;
  line-height: 40px;
}
.title span{
  font-weight: bold;
  margin-left: 15px;
}

/* label */
.describe label{
  line-height: 15px
}
.inputtext{
  width: 15%
}
.inputtext span{
  float: right;
}
.editdashboard .el-form-item__label{
  width: 150px !important;
}
.checkboxlabel{
  width: 100px ;
}
</style>
