<template>
  <el-form :model="goodsInfo" ref="goodsInfo" label-width="150px" class="demo-goodlists addnew-page">
    <p class="title">
      <span>商品信息</span>
    </p>
    <el-form-item class="leftlabel" label="商品名称：">
      <el-input class="inputtext" v-model="goodsInfo.goods_name"></el-input>
    </el-form-item>
    <el-form-item class="leftlabel" label="商品分类：">
      <el-select class="inputtext" v-model="product_sort_name" @change="shoptypechange" placeholder="请选择活动区域">
        <el-option
          v-for="item in goodsSort"
          :value="item.id"
          :key="item.id"
          :label="item.product_sort_name">
        </el-option>

      </el-select>
    </el-form-item>
    <!-- <el-form-item class="leftlabel" label="商品编码：">
      <el-input class="inputtext" v-model="goodsInfo.goods_brand_id"></el-input>
    </el-form-item> -->
    <el-form-item class="leftlabel" label="商品品牌：">
      <el-input class="inputtext" v-model="goodsInfo.product_brand_id"></el-input>
    </el-form-item>
    <el-form-item class="leftlabel" label="商品产地：">
      <el-input class="inputtext" v-model="goodsInfo.goods_source"></el-input>
    </el-form-item>
    <el-form-item class="leftlabel" label="采购类型：">
      <el-button-group>
        <el-button size="small" :autofocus="true" value="供应商送货"  @click.stop="checkinlist">供应商送货</el-button>
        <el-button size="small" value="市场自采" @click.stop="checkinlist">市场自采</el-button>
        <el-checkbox class="ml10" label="临时" name="type">临时指定</el-checkbox>
      </el-button-group>
    </el-form-item>
    <el-form-item class="leftlabel" label="供应商：">
      <el-select class="inputtext" v-model="purchaser_name" @change="purchaserchange" placeholder="请选择活动区域">
        <el-option
          v-for="item in supplier"
          :key="item.id"
          :label="item.purchaser_name"
          :value="item.id">
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item class="leftlabel" label="标签：">
     <el-radio-group v-model="labelunnit
     " @change="labelunitchange">
       <el-radio
       v-for="item in label"
       :key="item.id"
       :label="item.id"
       >{{item.product_label_name}}</el-radio>
     </el-radio-group>
   </el-form-item>
   <el-form-item class="leftlabel" label="主图：">
      <!-- <img :src="img.img_url" alt="" style="height:100px;width:100px;border:1px solid red"> -->
      <!-- <img width="100%" :src="img.img_url" alt=""> -->
      <el-upload
      action="https://jsonplaceholder.typicode.com/posts/"
      list-type="picture-card"
      :on-preview="handlePictureCardPreview"
      :file-list="mainimg"
      :on-remove="handleRemove">
        <i class="el-icon-plus"></i>
      </el-upload>
      <p class="Identification">主图至少上传一张,建议尺寸：800*800,支持GIF、PNG、IPG、JPEG格式,大小不超过1M</p>
        </el-upload>
    </el-form-item>
    <el-form-item class="leftlabel" label="封面图：" prop="name">
     <el-upload
     action="https://jsonplaceholder.typicode.com/posts/"
     list-type="picture-card"
     :on-preview="handlePictureCardPreview"
     :file-list="coverimg"
     :on-remove="handleRemove">
       <i class="el-icon-plus"></i>
     </el-upload>
     <el-dialog :visible.sync="dialogVisible">
     <img width="100%" alt="">

     </el-dialog>
     <p class="Identification">团长店铺首页显示图片,建议尺寸：750*400，支持GIF、PNG、IPG、JPEG格式,大小不超过1M</p>
       </el-upload>
   </el-form-item>
   <el-form-item class="leftlabel" label="主图视频：" prop="video">
      <el-upload
      action="https://jsonplaceholder.typicode.com/posts/"
      list-type="picture-card"
      :on-preview="handlePictureCardPreview"
      :on-remove="handleRemove">
        <i class="el-icon-plus"></i>
      </el-upload>
      <el-dialog :visible.sync="dialogVisible">
      <img width="100%" alt="">

      </el-dialog>
    </el-form-item>
    <p class="title">
      <span>商品规格</span>
    </p>
    <el-form-item class="leftlabel" label="单位：">
      <el-radio-group v-model="orderunit" @change="labelchange">
        <el-radio
        v-for="item in unit"
        :label="item.id"
        :value="item.id"
        >{{item.unit}}</el-radio>
      </el-radio-group>
    </el-form-item>
    <el-form-item label="描述：" class="describe leftlabel" prop="details">
     <el-input  class="inputtext" type="textarea" v-model="units.describe"></el-input>
   </el-form-item>

   <el-form-item class="leftlabel" label="商城价：">
     <el-input class="inputtext" v-model="units.product_spurious_price"></el-input>
     <span>&nbsp;&nbsp;&nbsp;元&nbsp;&nbsp;&nbsp;(精确到0.01)</span>
   </el-form-item>
   <el-form-item class="leftlabel" label="划线价：">
      <el-input class="inputtext" v-model="units.product_price"></el-input>
      <span>&nbsp;&nbsp;&nbsp;元&nbsp;&nbsp;&nbsp;(精确到0.01)</span>
    </el-form-item>
    <el-form-item class="leftlabel" label="团长等级佣金比列：">
      <el-input class="inputtext" v-model="units.commission"></el-input>
    </el-form-item>
    <el-form-item class="leftlabel" label="库存：">
      <el-input class="inputtext" v-model="units.spurious_sale_amount"></el-input>
    </el-form-item>
    <el-form-item class="leftlabel" label="销量：">
      <el-input class="inputtext" v-model="units.product_stock"></el-input>
    </el-form-item>
    <p class="title">
      <span>其他</span>
    </p>
      <div class="flex">
        <el-form-item class="leftlabel" label="商品排序：">
          <el-input class="inputtextinline" v-model="other.Commodity_ordering"></el-input>
        </el-form-item>
        <el-form-item class="leftlabelinline" label="打印排序：">
          <el-input class="inputtextinline" v-model="other.Print_sort"></el-input>
        </el-form-item>
        <el-radio-group v-model="other.redioval" style="line-height:40px;width:360px">
          <el-radio label="标品"></el-radio>
          <el-radio label="非标品"></el-radio>
          <el-checkbox class="ml10" v-model="other.check" label="商城中不显示基础单位" name="type"></el-checkbox>
        </el-radio-group>
      </div>
    <el-form-item class="leftlabel" label="到货时间：">
      <el-radio-group v-model="other.arrivetime">
        <el-radio label="跟随时间设定"></el-radio>
        <el-radio label="单独设定到货时间"></el-radio>
      </el-radio-group>
      到货时间&nbsp;&nbsp;&nbsp;
      <el-date-picker
      v-model="other.arrivedatetime"
      type="datetime"
      placeholder="选择日期时间"
      default-time="12:00:00">
      </el-date-picker>
    </el-form-item>
    <el-form-item class="leftlabel" label="图文详情描述">
      <el-upload
      action="https://jsonplaceholder.typicode.com/posts/"
      list-type="picture-card"
      :on-preview="handlePictureCardPreview"
      :on-remove="handleRemove">
        <i class="el-icon-plus"></i>
      </el-upload>
      <el-dialog :visible.sync="dialogVisible">
      <img width="100%" alt="">

      </el-dialog>
      <p class="Identification">建议尺寸宽度800,高度不限,支持GIF、PNG、IPG、JPEG格式,大小不超过1M</p>
        </el-upload>
    </el-form-item>
    <el-form-item style="margin-left:2%">
      <el-button type="primary" @click="savereturn()">保存并返回到列表页</el-button>
      <!-- <el-button @click="resetForm('goodsInfo')">保存并继续新增</el-button> -->
      <el-button @click="resetForm('goodsInfo')">取消</el-button>
    </el-form-item>
</el-form>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      goodsSort:[],
      supplier:[],
      purchaseman:[],
      unit:[],
      label:[],
      dialogVisible:false,
      dialogImageUrl:'',
      redioname:'',
      orderunit:'',
      goodsInfo: {
        goods_name: "",
        goods_sort_id: null,
        goods_brand_id: null,
        // product_brand_id:1,
        goods_source: "",
        purchase_type: null,
        purchaser_id: null,
        goods_label_id: null,
        goods_video: "",
        order_by: null,
        sign_product: 0,
        arrival_time: "",
        // details:'',
        img: [],
        img_type_one:"'图片1','图片2'",//商品主图
        img_type_two:"图片1",//封面图
        img_type_details:"图片1,图片2",//详情图
        units: {
          units_id: null,
          product_stock: null,
          product_price: "",
          product_spurious_price: "",
          commission: "",
          spurious_sale_amount: null,
          describe: null,
          units: {
            id: 0,
            company_id: null,
            unit: ""
          }
        }
      },
      units:{
        product_spurious_price:'',
        product_price:'',
        commission:'',
        describe:'',
        spurious_sale_amount:'',
        product_stock:'',
      },
      goods_sort:[],
      product_sort_name:'',
      labelunnit:'',
      purchaser_name:'',
      childrenunits:{},
      // label:'',
      other:{
        Commodity_ordering:0,
        Print_sort:0,
        check:true,
        redioval:'标品',
        arrivetime:'跟随时间设定',
        arrivedatetime:''
      },
      mainimg:[{
        name:'ha',
        url:''
      }],
      coverimg:[{
        name:'ha',
        url:''
      }],
    }
  },
  created(){
    this.getData();
  },
  methods:{
    //商品排序修改
    // othercochange(value){
    //   this.goodsInfo.order_by=value;
    // },
    //标签点击
    labelunitchange(value){
      console.log(value);
      this.goodsInfo.goods_label_id=value;
    },
    //单位
    labelchange(value){
      console.log(value);
      this.goodsInfo.units.units_id=value;
    },
    checkinlist(e){
      e.currentTarget.value=="供应商送货"?e.currentTarget.value=1:e.currentTarget.value=2;
      this.goodsInfo.purchase_type=e.currentTarget.value;
    },
    // checkinlisttext(e){
    //   console.log(e.currentTarget.value);
    // },
    // 获取数据
    async getData (){
        const result = await axios.get(Rootpath.BASE_URL + 'addProductPage');
        console.log(result);
        this.goodsSort=result.data.info.goodsSort;
        this.supplier=result.data.info.supplier;
        this.purchaseman=result.data.info.purchaseman;
        this.unit=result.data.info.unit;
        this.label=result.data.info.label;
    },
    //分类选择
    shoptypechange(value){
      console.log(value);
      this.product_sort_name=value;
      this.goodsInfo.goods_sort_id=value;
    },
    //供应商选择
    purchaserchange(value){
      console.log(value);
      this.goodsInfo.purchaser_id=value;
    },
    //保存
    savereturn(){
      let that = this;
      that.goodsInfo.order_by=that.other.Commodity_ordering;
      // that.goodsInfo.units.product_stock=that.units.product_stock;
      that.goodsInfo.units=that.units;
      // that.goodsInfo.units.spurious_sale_amount=that.units.spurious_sale_amount;
      axios.post(Rootpath.BASE_URL + 'addProduct', {
           goodsInfo:that.goodsInfo,
           other:that.other
       })
       .then(function (response) {
           // that.dialogFormVisible = false;
           console.log(response);
       })
       .catch(function (error) {
           console.log(error);
       });
    },
    handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePictureCardPreview(file) {
        this.dialogImageUrl = file.url;
        this.dialogVisible = true;
      }
  }
};
</script>

<style scoped>
.inputtext{
  width: 220px
}
/* 标题 */
.title{
  background: #F5F5F5;
  line-height: 40px;
}
.title span{
  font-weight: bold;
  margin-left: 15px;
}

/* label */
.describe label{
  line-height: 15px
}
.inputtext{
  width: 15%
}
.inputtext span{
  float: right;
}
.editdashboard .el-form-item__label{
  width: 150px !important;
}
.checkboxlabel{
  width: 100px ;
}
</style>
