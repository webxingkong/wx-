<template>
  <div class="dashboard-page">
    <div class="searchfrom flex_m">
      <label class="goods_name_label">
        商品名称
      </label>
      <el-input
    placeholder="请输入内容"
    class="goodsname"
    size="mini"
    v-model="searchinfo.product_name">
      </el-input>
      <label class="goods_name_label">
        商品货号
      </label>
      <el-input
    placeholder="请输入内容"
    class="goodsname"
    size="mini"
    v-model="searchinfo.product_number">
      </el-input>
      <el-button size="mini" @click="searchlist" class="search_btn">搜索</el-button>
      <span class="open">展开</span>
      <i class="el-icon-arrow-down"></i>
    </div>
    <div class="btn flex_m">
      <el-button-group>
        <el-button size="small" @click="lower_shelf(clickrow)">下架商品</el-button>
        <el-button size="small" @click="deleterow(clickrow)">删除</el-button>
      </el-button-group>
      <el-button size="small ml16" @click="addnew">发布商品</el-button>
    </div>
    <el-table
            ref="multipleTable"
            :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)"
            border
            stripe
            @select="select"
            @select-all="select"
            class="goods_table"
            min-height="100%">
            <el-table-column type="selection"
                             align="center">
            </el-table-column>
            <el-table-column
              prop="goods_img"
              label="商品图片"
              align="center">
              <!-- 图片的显示 -->
                 <template   slot-scope="scope">
                    <img :src="scope.row.url"  min-width="40" height="40" />
                 </template>
            </el-table-column>
            <el-table-column
              prop="goods_name"
              label="商品名称"
              align="center">
            </el-table-column>
            <el-table-column
              prop="goods_sort"
              label="商品分类"
              align="center">
              <template slot-scope="scope">
                <span v-if="scope.row.goods_sort.sort_name==='肉类'">肉类</span>
                <span v-if="scope.row.sort===2">蔬菜</span>
                <span v-if="scope.row.sort===3">生鲜</span>
                <span v-if="scope.row.sort===4">零食</span>
              </template>
              <!-- //商品分类1:水果；2：蔬菜；3：生鲜；4：零食 -->
            </el-table-column>
            <el-table-column
              prop="goods_brand.goods_brand"
              label="品牌"
              align="center">
            </el-table-column>
            <el-table-column
              prop="goods_unit.unit_name"
              label="单位"
              align="center">
              <template slot-scope="scope">
                <span v-if="scope.row.goods_unit.unit_name==='斤'">斤</span>
                <!-- <span v-if="scope.row.unit===2">袋</span>
                <span v-if="scope.row.goods_unit.units.unit==='个'">个</span>
                <span v-if="scope.row.unit===4">盒</span>
                <span v-if="scope.row.unit===5">斤</span>
                <span v-if="scope.row.unit===6">桶</span> -->
              </template>
              <!-- //单位1：瓶；2：袋；3：个；4：盒；5：斤；6：桶 -->
            </el-table-column>
            <el-table-column
              prop="goods_unit.goods_price"
              label="商城价"
              align="center">
            </el-table-column>
            <el-table-column
              prop="is_sale"
              label="状态"
              align="center">
              <template slot-scope="scope">
              <el-switch
			  class="switchStyle"

                v-model="scope.row.is_sale"
                active-color="#13ce66"
                inactive-color="#ff4949"
                :active-value="1"
                :inactive-value="-1"
                active-text="上架"
                inactive-text="下架">
              </el-switch>
              </template>
            </el-table-column>
            <el-table-column
              prop="goods_unit.goods_stock"
              label="售卖库存"
              align="center">
            </el-table-column>
            <el-table-column label="操作"  align="center">
              <template slot-scope="scope">
                <!-- <el-button type="text"
                           @click="listEdit(scope.$index, scope.row)">编辑</el-button> -->
                           <!-- <el-button type="text" @click="dialogTableVisible = true">编辑</el-button> -->

                            <el-button type="text" @click="edit(scope.row)">编辑</el-button>
                <el-button type="text"
                            @click="deleterowindex(scope.$index, tableData)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <!--分页-->
          <el-pagination class="pagination"
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="[5, 10, 20, 50]"
              :page-size="pagesize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
            </el-pagination>
<!-- 编辑弹窗 -->

  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
    data() {
      return {
        searchinfo:{
          product_name:'',
          product_number:''
        },
        clickrow:[],//点击的行数据
        tableData: [],
        total: 0,
        currentPage: 1,
        table_index: 999,
        pagesize: 5,
        dialogTableVisible: false,
        imageUrl: '',
        arrivetime:'',

      }
    },
    components: {

    },
    created() {
      this.getData();
    },
    methods: {
      handleSizeChange(size) {
        this.pagesize = size
      },
      // 获取数据
      async getData() {
        const result = await axios.get(Rootpath.BASE_URL + 'adminProduct');
        console.log(result.data);
        this.tableData = result.data.goodlists;
        this.total = result.data.goodlists.length;
      },
      handleCurrentChange(currentPage) {
        this.currentPage = currentPage
      },
      //搜索
      searchlist(){
        let that = this;
        axios.get(Rootpath.BASE_URL + 'product_search', {
                params: {
                    product_name: that.searchinfo.product_name,
                    product_number: that.searchinfo.product_number,
                }
            })
            .then(function (response) {
                console.log(response);
                if (response.data=="") {
                  console.log("数据为空");
                }else{
                  that.tableData = response.data.goodlists;
                  that.total = response.data.goodlists.length;
                }
                // that.user_list = response.data.user_list
                // that.total = response.data.user_list.length
            })
            .catch(function (error) {
                console.log(error);
            });
      },
      //获取点击的数据
      select(val){
        this.clickrow=val;
      },
      //发布弹窗
      addnew(){
          this.$router.push({path:'/dashboard/analysis/Addnew'})
      },
      //下架
      lower_shelf(rows){
        if(rows){
          // rows.forEach(row => {
          //   row.is_sale=1;
          //   console.log(row);
          // });
          for (var i = 0; i < rows.length; i++) {
            if (rows[i].is_sale=-1) {
            }else{
              row.is_sale=-1;
            }
          }
        }else{
        }
      },
      //编辑弹窗
      edit(row){
          this.$router.push({path:'/dashboard/analysis/Editdashboard',query: {gid:row.id}})
      },
      //删除
      deleterow(row){
        this.tableData.splice(row,row.length);
      },
      deleterowindex(index,row){
        row.splice(index, 1);
      },
      handleAvatarSuccess(res, file) {
        this.imageUrl = URL.createObjectURL(file.raw);
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg';
        const isLt2M = file.size / 1024 / 1024 < 2;

        if (!isJPG) {
          this.$message.error('上传头像图片只能是 JPG 格式!');
        }
        if (!isLt2M) {
          this.$message.error('上传头像图片大小不能超过 2MB!');
        }
        return isJPG && isLt2M;
      },
      // listEdit(index, row) {
      //   this.dialogFormVisible = true
      //   this.form = Object.assign({}, row)
      //   this.table_index = index
      // },
      listCheck() {
        console.log(1)
      }
    }
  }
</script>
<style scoped>
.el-dialog{
  width: 100%;
}
.Service-page{
  background: #ffffff
}
.inputtextinline{
  width: 120px
}
/* 搜索块 */
.searchfrom{
  height: 35px;
  background: #F5F5F5
}
.goods_name_label{
  margin-left: 15px;
  margin-right: 5px;
  display:
}
.search_btn{
  background: #436BE5;
  color: #ffffff;
  margin-left: 15px;
  margin-right: 12px;
}
.open{
  color: #436BE5
}
i{
  color: #436BE5
}
/* 图片上传 */
.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 130px;
    height: 130px;
    line-height: 130px;
    text-align: center;
  }
  .avatar {
    width: 130px;
    height: 130px;
    display: block;
  }
.Identification{
  line-height: 16px;
  color: #999999;
  margin-left: 50px;
}



.goodsname{
  width: 167px
}
.open{
  margin-right: 5px;
}
.noborder{
  border:none;
  color:#436BE5
}
.el-table th{
  border: none !important;
}
.el-table tr{
  border-bottom:1px solid #EBEEF5;
  border-right: none
}
.el-table--border td{
    border-right: none;
}
.has-gutter th{background:#F5F5F5}
.noborder:hover{
  background: #F5F7FA;
  color: #436BE5;
  border: none;
}
/* 按钮 */
.btn{
  height: 60px;
}
.ml16{
  margin-left: 16px
}
el-button-group{
  width: 90px;
}
.small{
  width: 50% !important;
  height: 15px !important;
}
.pagination{
  margin-left: 50%;
}

</style>
