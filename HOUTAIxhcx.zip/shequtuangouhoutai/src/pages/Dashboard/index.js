import Dashboard from './Dashboard.vue';

export default Dashboard;
