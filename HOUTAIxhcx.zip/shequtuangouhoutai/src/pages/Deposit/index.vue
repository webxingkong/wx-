<template>
	<div class="select">
	<div class="select-table">
		<el-tabs v-model="activeName" @tab-click="handleClick">
			<!--余额-->
		    <el-tab-pane label="会员余额" name="first">
		<div class="search">
			<!---->
			<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
			  <el-form-item label="注册时间" style="margin-top: 20px;">
			    <el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
			  </el-form-item>
			  <el-form-item label="手机号" style="margin-top: 20px;">
			    <el-input  size="small" v-model="formInline.region" style="width: 120px;"></el-input>
			  </el-form-item>
			  <el-form-item label="名称" style="margin-top: 20px;">
			    <el-input  size="small" v-model="formInline.Name" style="width: 120px;"></el-input>
			  </el-form-item>&emsp;
			  <el-form-item>
			    <el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>
			  </el-form-item>
			</el-form>
			<!---->
				</div>
		<br>
				<div class="Button">
				<div class="right">
				 <el-button size="medium">导出查询结果</el-button>
	 </div>
	 </div>
	 <br>
	<el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
		<el-table-column  width="55"></el-table-column>
				<el-table-column label="会员名称" width="120">
					<template slot-scope="scope">
						{{ scope.row.date }}
					</template>
				</el-table-column>
				<el-table-column prop="name" label="手机号码" width="200"></el-table-column>
				<el-table-column prop="rank" label="注册时间" width="200"></el-table-column>
				<el-table-column prop="integral" label="余额"></el-table-column>
				<el-table-column
				      fixed="right"
				      label="操作"
				      width="160">
				      <template slot-scope="scope">
				        <el-button @click="handleClick(scope.row)" type="text" size="small">充值</el-button>
				        <el-button type="text" size="small">扣款</el-button>
						<el-button type="text" size="small">收支明细</el-button>
				      </template>
				    </el-table-column>
			</el-table>
			<br>
			<!--分页-->
			 <el-pagination class="block"
			     background
			     @size-change="handleSizeChange"
			     @current-change="handleCurrentChange"
			     :current-page="currentPage"
			     :page-sizes="[5, 10, 20, 50]"
			     :page-size="pagesize"
			     layout="total, sizes, prev, pager, next, jumper"
			     :total="total">
			   </el-pagination>
			</el-tab-pane>
			<!--余额明细-->
		    <el-tab-pane label="会员余额明细" name="second">
				<div class="search">
					<!---->
					<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
					  <el-form-item label="注册时间" style="margin-top: 20px;">
					    <el-input  size="small" v-model="formInline.times" style="width: 120px;"></el-input>
					  </el-form-item>
					  <el-form-item label="手机号" style="margin-top: 20px;">
					    <el-input  size="small" v-model="formInline.Mobilephone" style="width: 120px;"></el-input>
					  </el-form-item>
					  <el-form-item label="名称" style="margin-top: 20px;">
					    <el-input  size="small" v-model="formInline.Names" style="width: 120px;"></el-input>
					  </el-form-item>&emsp;
					  <el-form-item>
					    <el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>
					  </el-form-item>
					</el-form>
					<!---->
						</div>
						
				<div class="Button">
				<div class="right">
					<br>
				 <el-button size="medium">导出查询结果</el-button>
				 </div>
				 </div>
				 <br>
				<el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
					<el-table-column  width="55"></el-table-column>
					<el-table-column label="会员名称" width="120">
						<template slot-scope="scope">
							{{ scope.row.date }}
						</template>
					</el-table-column>
					<el-table-column prop="name" label="手机号码" width="200"></el-table-column>
					<el-table-column prop="time" label="流水" width="200"></el-table-column>
					<el-table-column prop="type" label="收支类型" width="150"></el-table-column>
					<el-table-column prop="budget" label="收入/支出" width="120"></el-table-column>
					<el-table-column prop="change" label="变动金额" width="120"></el-table-column>
					<el-table-column prop="changes" label="变动后余额" width="120"></el-table-column>
					<el-table-column prop="operation" label="操作时间" width="200"></el-table-column>
					<el-table-column prop="remarks" label="备注" width=" show-overflow-tooltip"></el-table-column>
				</el-table>
				<br>
				<!--分页-->
				 <el-pagination class="block"
				     background
				     @size-change="handleSizeChange"
				     @current-change="handleCurrentChange"
				     :current-page="currentPage"
				     :page-sizes="[5, 10, 20, 50]"
				     :page-size="pagesize"
				     layout="total, sizes, prev, pager, next, jumper"
				     :total="total">
				   </el-pagination>
						
				</el-tab-pane>
			
		  </el-tabs>

	</div>
	</div>
</template>

<script>
	
export default {
	data() {
			return {
				 activeName: 'first',
				tableData: [
					{
						date: '小虎',
						name: '13557322395',
						rank: '2019-10-20 10:24:25',
						integral: '0.00',
						time: 'Ls19.95806498',
						type:'充值卡充值',
						budget:'收入',
						change:'￥138.0',
						changes:'￥18.0',
						operation:'2019-10-20 12:12:12',
						remarks:'充值卡YSJD256251充值'
					},
					{
						date: '大虎',
						name: '13557322395',
						rank: '2019-10-20 10:24:25',
						integral: '0.00',
						time: 'Ls19.95806498',
						type:'充值卡充值',
						budget:'收入',
						change:'￥138.0',
						changes:'￥18.0',
						operation:'2019-10-20 12:12:12',
						remarks:'充值卡YSJD256251充值'
					},
				],
			formInline: {
			      user: '',
			      region: '',
				  Name:'',
				  times:'',
				  Mobilephone:'',
				  Names:''
			    },
			  
			
			};
		},
		methods: {
		  onSubmit() {
		    console.log('submit!');
		  },
		  //分页
		  handleSizeChange(size) {
		    this.pagesize = size
		  },
		  handleCurrentChange(currentPage) {
		    this.currentPage = currentPage
		  },
		  
		}
	};

</script>

<style scoped>
	.footer{height: 44px;
	text-align: right;
	
	}
	.right{
		text-align: right;
		
	}
	.Button{
		background-color: #ffffff;
	}
	p{position: relative;
		top: -12px;
			}
	
	.search {
		height: 70px;
		background-color: #F5F5F5;
		
	}
.search-Button{
margin-left: 20px;
		
}

h3 {
	color: #436be5;
	border-bottom: solid 2px #436be5;
	margin-left: 20px;
}
.text-frame-member {
	width: 100px;
	position: relative;
	top: 10px;
}
.text-frame {
	height: 50px;
	width: 100%;
	background-color: #ffffff;
	border-bottom: solid 1px #f0f2f0;
}

.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select{
	margin: auto;
	width: 96%;
	background-color: #ffffff;
}/*border: solid 1rpx #007AFF;
*/
.block{
	text-align: right;
}
</style>
