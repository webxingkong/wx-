<template>
    <div class="select Pin-page">
        <div class="select-table">
            <el-tabs v-model="activeName">
                <!--商品统计-->
                <el-tab-pane label="商品统计" name="first">
                    <el-radio-group size="small" v-model="tabPosition">
                        <el-radio-button label="thisweek">本周</el-radio-button>
                        <el-radio-button label="lastweek">上周</el-radio-button>
                        <el-radio-button label="thismonth">本月</el-radio-button>
                        <el-radio-button label="lastmonth">上月</el-radio-button>
                    </el-radio-group>
                    <!--时间选择器-->
                    &emsp;
                    <span class="demonstration">日期：</span>
                    <el-date-picker size="small" v-model="value1" type="datetime" placeholder="选择日期时间" style="width: 10%"></el-date-picker>
                    &emsp;店铺名称：
                    <el-input size="small" v-model="input" placeholder="请输入内容" style="width: 10%"></el-input>
                    &emsp;商品编码：
                    <el-input size="small" v-model="input" placeholder="请入内容" style="width: 10%;"></el-input>
                    &emsp;

                    <el-button size="small" type="primary">搜索</el-button>
                    </el-form-item>
                    <br />
                    <br />
                    <el-col :span="8">
                        <div class="grid-content ">
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m shadow">
                                    <h1>{{top_data.order_goods}}</h1>
                                    订货数量
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m border-left">
                                    <h1>{{top_data.return_goods}}</h1>
                                    退货数量
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m">
                                </div>
                            </el-col>
                        </div>
                    </el-col>
                    <el-col :span="8">
                        <div class="grid-content ">
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m shadow">
                                    <h1>{{top_data.order_count}}</h1>
                                    订单笔数
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m border-left">
                                    <h1>{{top_data.return_order}}</h1>
                                    退单笔数
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m">
                                </div>
                            </el-col>
                        </div>
                    </el-col>
                    <el-col :span="8">
                        <div class="grid-content ">
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m shadow">
                                    <h1>{{top_data.order_total}}</h1>
                                    订货金额
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m border-left">
                                    <h1>{{top_data.return_total}}</h1>
                                    退货金额
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m border-left">
                                    <h1>{{top_data.price_total_sum}}</h1>
                                    金额小计
                                </div>
                            </el-col>
                        </div>
                    </el-col>
                    <div>&emsp;</div>
                    <div class="block">
                        <el-button size="medium">一键导出查询</el-button>
                    </div>
                    <br>
                    <!--下面表格和统计图-->
                    <el-tabs type="border-card " name="first">
                        <el-tab-pane label="列表模式">
                            <!--表格-->
                            <el-table :data="data_list.slice((currentPage-1)*pagesize,currentPage*pagesize)" stripe style="width: 100%">
                                <el-table-column prop="product_name" label="商品名称">
                                </el-table-column>
                                <el-table-column prop="product_sort_name" label="分类">
                                </el-table-column>
                                <el-table-column prop="order_number" label="商品编码">
                                </el-table-column>
                                <el-table-column prop="shop_count" label="订货笔数">
                                </el-table-column>
                                <el-table-column prop="after_count" label="退货笔数">
                                </el-table-column>
                                <el-table-column prop="order_count" label="订单笔数">
                                </el-table-column>
                                <el-table-column prop="return_order" label="退单笔数">
                                </el-table-column>
                                <el-table-column prop="order_price" label="订货金额">
                                </el-table-column>
                                <el-table-column prop="return_price" label="退货金额">
                                </el-table-column>
                                <el-table-column prop="price_total" label="金额小计">
                                </el-table-column>
                                <el-table-column prop="ranking" label="综合排名">
                                </el-table-column>
                                </el-table-column>
                            </el-table>
                            <!--分页-->
                            <el-pagination
														class="block"
														background
														@size-change="handleSizeChange"
														@current-change="handleCurrentChange"
														:current-page="currentPage"
														:page-sizes="[5, 10, 20, 50]"
														:page-size="pagesize"
														layout="total, sizes, prev, pager, next, jumper"
														:total="total">
                            </el-pagination>
                        </el-tab-pane>
                        <br>
                        <!--统计图-->
                        <el-tab-pane label="列表模式">

                            <el-col :span="12">
                                <h1 class="h1in">订货总金额：600.0</h1>
                                <div class=" block flex_c">

                                    <ve-pie :data="chartData" width="500px" height="500px"></ve-pie>

                                </div>
                            </el-col>
                            <el-col :span="12">
                                <h1 class="h1in">退货总金额：600.0</h1>
                                <div class=" block flex_c">

                                    <ve-pie :data="chartData" width="500px" height="500px"></ve-pie>

                                </div>
                            </el-col>
                        </el-tab-pane>
                    </el-tabs>
                </el-tab-pane>
                <!--图片统计-->
                <el-tab-pane label="分类统计" name="second">分类统计
                    <el-radio-group size="small" v-model="tabPosition">
                        <el-radio-button label="thisweek">本周</el-radio-button>
                        <el-radio-button label="lastweek">上周</el-radio-button>
                        <el-radio-button label="thismonth">本月</el-radio-button>
                        <el-radio-button label="lastmonth">上月</el-radio-button>
                    </el-radio-group>
                    <!--时间选择器-->
                    &emsp;
                    <span class="demonstration">日期：</span>
                    <el-date-picker size="small" v-model="value1" type="datetime" placeholder="选择日期时间" style="width: 10%"></el-date-picker>
                    &emsp;店铺名称：
                    <el-input size="small" v-model="input" placeholder="请输入内容" style="width: 10%"></el-input>
                    &emsp;商品编码：
                    <el-input size="small" v-model="input" placeholder="请入内容" style="width: 10%;"></el-input>
                    &emsp;

                    <el-button size="small" type="primary">搜索</el-button>
                    </el-form-item>
                    <br />
                    <br />
                    <el-col :span="8">
                        <div class="grid-content ">
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m shadow">
                                    <h1>0</h1>
                                    订货数量
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m border-left">
                                    <h1>0</h1>
                                    退货数量
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m">
                                </div>
                            </el-col>
                        </div>
                    </el-col>
                    <el-col :span="8">
                        <div class="grid-content ">
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m shadow">
                                    <h1>0</h1>
                                    订单笔数
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m border-left">
                                    <h1>0</h1>
                                    退单笔数
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m">
                                </div>
                            </el-col>
                        </div>
                    </el-col>
                    <el-col :span="8">
                        <div class="grid-content ">
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m shadow">
                                    <h1>0.00</h1>
                                    订货金额
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m border-left">
                                    <h1>0.00</h1>
                                    退货金额
                                </div>
                            </el-col>
                            <el-col :span="8">
                                <div class="grid-content flex_line_c_m border-left">
                                    <h1>0.00</h1>
                                    金额小计
                                </div>
                            </el-col>
                        </div>
                    </el-col>
                    <div>&emsp;</div>
                    <div class="block">
                        <el-button size="medium">一键导出查询</el-button>
                    </div>
                    <br>
                    <!--一、二级分类统计-->
                    <el-tabs type="border-card " name="first">
                        <!--一级分类统计-->
                        <el-tab-pane label="一级分类">
                            <!--表格-->
                            <el-table :data="tableData" stripe style="width: 100%">

                                <el-table-column prop="branch" label="分类">
                                </el-table-column>

                                <el-table-column prop="Orderpennumber" label="订货数量">
                                </el-table-column>
                                <el-table-column prop="Returnnumber" label="退货数量">
                                </el-table-column>

                                <el-table-column prop="Orderamount" label="订货金额">
                                </el-table-column>
                                <el-table-column prop="Refundamount" label="退货金额">
                                </el-table-column>
                                <el-table-column prop="Subtotal" label="金额小计">
                                </el-table-column>
                                <el-table-column prop="ranking" label="综合排名">
                                </el-table-column>
                                </el-table-column>
                            </el-table>
                            <!--分页-->
                            <el-pagination class="block" background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[5, 10, 20, 50]" :page-size="pagesize" layout="total, sizes, prev, pager, next, jumper" :total="total">
                            </el-pagination>
                        </el-tab-pane>
                        <br>
                        <!--二级分类统计-->
                        <el-tab-pane label="二级分类">
                            <!--表格-->
                            <el-table :data="tableData" stripe style="width: 100%">

                                <el-table-column prop="branch" label="分类">
                                </el-table-column>

                                <el-table-column prop="Orderpennumber" label="订货数量">
                                </el-table-column>
                                <el-table-column prop="Returnnumber" label="退货数量">
                                </el-table-column>

                                <el-table-column prop="Orderamount" label="订货金额">
                                </el-table-column>
                                <el-table-column prop="Refundamount" label="退货金额">
                                </el-table-column>
                                <el-table-column prop="Subtotal" label="金额小计">
                                </el-table-column>
                                <el-table-column prop="ranking" label="综合排名">
                                </el-table-column>
                                </el-table-column>
                            </el-table>
                            <!--分页-->
                            <el-pagination class="block" background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[5, 10, 20, 50]" :page-size="pagesize" layout="total, sizes, prev, pager, next, jumper" :total="total">
                            </el-pagination>
                        </el-tab-pane>
                    </el-tabs>
                </el-tab-pane>
            </el-tabs>

        </div>
    </div>
</template>

<script>
    import axios from '../../axios.js'
    import https from "../../../api/https.vue"
    import Rootpath from "../../../api/index.js"
    import qs from '../../../node_modules/qs'
    import VeLine from 'v-charts/lib/line'
    export
    default {
        data() {
                return {
                    total: 0,
                    currentPage: 1,
                    pagesize: 5,
                    activeName: 'first',
                    tabPosition: 'thisweek',

                    value1: '',
                    value2: '',
                    input: '',
                    top_data: [],
                    data_list: [],
                    chartData: {
                        columns: ['日期', '访问用户'],
                        rows: [{
                            '日期': '1/1',
                            '访问用户': 1393
                        }, {
                            '日期': '1/2',
                            '访问用户': 3530
                        }, {
                            '日期': '1/3',
                            '访问用户': 2923
                        }, {
                            '日期': '1/4',
                            '访问用户': 1723
                        }, {
                            '日期': '1/5',
                            '访问用户': 3792
                        }, {
                            '日期': '1/6',
                            '访问用户': 4593
                        }]
                    }
                }
            },
            created() {
                this.getData();
            },
            methods: {
                handleClick(tab, event) {
                        console.log(tab, event);
                    },
                    // 获取数据
                    async getData() {
                        const result = await axios.get(Rootpath.BASE_URL + 'shop_sales?time=' + this.tabPosition);
                        // console.log(result.data);
                        this.top_data = result.data.top_data;
                        this.data_list = result.data.data_list;
                        this.total = result.data.data_list.length;
                    },
                    //分页
                    handleSizeChange(size) {
                        this.pagesize = size;
                    },
                    handleCurrentChange(currentPage) {
                        this.currentPage = currentPage;
                    },

            }
    };
</script>

<style scoped>
    .grid-content {
        height: 80px;
    }
    .border-left {
        border-left: 2px solid #4CAF50;
        box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1)
    }
    .shadow {
        box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1)
    }
    h1 {
        font-size: 20px;
    }
    .block {
        text-align: right;
    }
    .select-table {
        margin: auto;
        width: 96%;
        margin-top: 20px;
    }
    .select {
        margin: auto;
        width: 96%;
        background-color: #ffffff;
    }
    .h1in {
        text-align: center;
    }
</style>
