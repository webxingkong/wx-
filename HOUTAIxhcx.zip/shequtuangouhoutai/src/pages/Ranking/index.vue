<template>
  <div class="Service-page" style="margin: 20px;">
	  <el-tabs v-model="activeName" @tab-click="handleClick">
	     <el-tab-pane label="配送总汇" name="first">
			 <!-- 弹层详情html -->
	 <div>
	 <el-dialog
	   title="单据详情"
	   :visible.sync="seedialog"
	   width="60%"
	   :before-close="handleClose">
	   <hr />
	   <div>
		   <el-table
		       :data="tableData"
		       stripe
		       style="width: 100%">
		       <el-table-column
		         prop="date"
		         label="会员单号"
		         width="180">
		       </el-table-column>
		       <el-table-column
		         prop="name"
		         label="配送日期"
		         width="180">
		       </el-table-column>
		       <el-table-column
		         prop="address"
		         label="发货金额">
		       </el-table-column>
			   <el-table-column
			     prop="address"
			     label="退货金额">
			   </el-table-column>
			   <el-table-column
			     prop="address"
			     label="实际金额">
			   </el-table-column>
		     </el-table>
	   </div>
		 <hr />
		 <div>
		 	  <div style="padding-left:75%;align-items: center;padding-top:9px;" class="flex">
		 		<div style="line-height:25px;">1/6页，54条结果</div>
		 		 <el-pagination>
		 		 </el-pagination>
		 	</div>
		 </div>
	   <span slot="footer" class="dialog-footer">
		 <el-button @click="seedialog = false">取 消</el-button>
		 <el-button type="primary" @click="seedialog = false">确 定</el-button>
	   </span>
	 </el-dialog>
		</div>
				<div>
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				  <el-form-item label="团长名称" style="margin-top: 20px;">
					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="店铺名称" style="margin-top: 20px;">
					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="团长账号" style="margin-top: 20px;">
					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>&emsp;
				  <el-form-item>
					<el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>		
				  </el-form-item>
				</el-form>
				</div>
					 <div class="right">
					 <el-button size="medium">导出查询结果</el-button>
					 </div>
					<div>
						<el-table
						    :data="tableData"
						    stripe
						    style="width: 100%">
						    <el-table-column
							  align="center" 
							     prop="name"
						      label="配送单号"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center" 
						      prop="name"
						      label="团长账号"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center" 
						      prop="address"
						      label="团长邮编">
						    </el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="店铺名称">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="团长名称">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="下单时间">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="订单数量">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="发货金额">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="退货金额">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="实际金额">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="操作">
							  <el-button type="text" @click="seedialog = true">详情</el-button>
							</el-table-column>
						  </el-table>
					</div>
					<div class="paging">
					  <div style="padding-left:80%;align-items: center;padding-top:9px;" class="flex">
						<div style="line-height:25px;">1/6页，54条结果</div>
						 <el-pagination>
						 </el-pagination>
					</div>
				</div>
									

		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
export default {
  name: 'first',
  components: {},
   data() {
        return {
			 activeName: 'first',
			  seedialog: false,
			  num: 1,
			   formInline: {
			            user: '',
			            region: ''
			          },
          tableData: [{
            date: '2016-05-02',
            name: '王小虎',
            address: '上海市普陀区'
          }, {
            date: '2016-05-04',
            name: '王小虎',
            address: '上海市普陀区'
          }, {
            date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区'
          },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区'
		  },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区'
		  },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  }]
        }
      },
	   methods: {
	        handleChange(value) {
	          console.log(value);
	        },
			onSubmit() {
			        console.log('submit!');
			      }
	      }
};
</script>
<style scoped>
	.text{
	    display: flex;
		align-items: center;
	    left: 20px;
	    position: relative;
	    top: 15px;
	  }
	.search {
	  height: 75px;
	  background-color: #F5F5F5;
	  position: relative;
	  top: 16px;
	}
	.search-frame {
	  width: 100%;
	  height: 100px;
	  margin: auto;
	  background-color: #ffffff;
	}
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px; 
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
