<template>
    <div class="Fruit-page" style="margin:25px;background: #FFFFFF;">
        <el-tabs v-model="activeName">
            <el-tab-pane label="页面装修" name="first">
                <div style="width:100%;">
                    <el-tabs :tab-position="tabPosition" v-model="sonactivename" @tab-click="handleClick">
                        <el-tab-pane label="顶部广告" name="0">
                            <div style="display: flex; justify-content: space-around;">
                                <!-- 展示图 -->
                                <div>
                                    <img src="http://yhx-img.oss-cn-hongkong.aliyuncs.com/web/img-4@2x.png" />
                                </div>
                                <!-- 设置区域 -->
                                <div style="width:400px;box-shadow:0 0 1px #000 inset;">
                                    <div style="background: #EEEEEE;height:30px;line-height:30px;">内容设置</div>
                                    <div style="font-size:15px; margin:5px;">编辑内容</div>
                                    <el-upload class="upload-demo"
                                    action="https://jsonplaceholder.typicode.com/posts/"
                                    :on-preview="handlePreview"
                                    :on-remove="handleRemove"
                                    :file-list="imgurl"
                                    list-type="picture">
                                        <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
                                    </el-upload>
                                    <el-form ref="form" :model="form" label-width="90px">
                                        <el-form-item label="链接">
                                            <el-select v-model="link.value" @change="linkchange" placeholder="请选择">
                                              <el-option
                                                v-for="item in link"
                                                :key="item.value"
                                                :label="item.label"
                                                :value="item.value">
                                              </el-option>
                                            </el-select>
                                        </el-form-item>
                                        <el-form-item label="">
                                          <el-select v-model="link_to.value" @change="linktochange" placeholder="请选择">
                                            <el-option
                                              v-for="item in link_to"
                                              :label="item.label"
                                              :value="item.value">
                                            </el-option>
                                          </el-select>
                                        </el-form-item>
                                    </el-form>
                                    <div class="addimg">添加一张图片</div>
                                    <!-- <div>
                                        <el-button type="primary" class="inbutton">保存</el-button>
                                        <el-button type="primary" class="inbutton">保存并使用</el-button>
                                    </div> -->
                                </div>
                            </div>
                        </el-tab-pane>
                        <el-tab-pane label="底部广告" name="1">
                          <div style="display: flex; justify-content: space-around;">
                              <!-- 展示图 -->
                              <div>
                                  <img src="http://yhx-img.oss-cn-hongkong.aliyuncs.com/web/img@2x%20(1).png" />
                              </div>
                              <!-- 设置区域 -->
                              <div style="width:400px;box-shadow:0 0 1px #000 inset;">
                                  <div style="background: #EEEEEE;height:30px;line-height:30px;">内容设置</div>
                                  <div style="font-size:15px; margin:5px;">编辑内容</div>
                                  <el-upload class="upload-demo"
                                   action="https://jsonplaceholder.typicode.com/posts/"
                                   :on-preview="handlePreview"
                                   :on-remove="handleRemove"
                                   :file-list="imgurl"
                                   list-type="picture">
                                      <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
                                  </el-upload>
                                  <el-form ref="form" :model="form" label-width="90px">
                                      <el-form-item label="活动区域">
                                        <el-select v-model="link.value" @change="btmlinkchange" placeholder="请选择">
                                          <el-option
                                            v-for="item in btmlink"
                                            :key="item.value"
                                            :label="item.label"
                                            :value="item.value">
                                          </el-option>
                                        </el-select>
                                    </el-form-item>
                                    <el-form-item label="">
                                      <el-select v-model="link_to.value" @change="btmlinktochange" placeholder="请选择">
                                        <el-option
                                          v-for="item in btmlink_to"
                                          :label="item.label"
                                          :value="item.value">
                                        </el-option>
                                      </el-select>
                                    </el-form-item>
                                  </el-form>
                                  <div class="addimg">添加一张图片</div>
                                  <!-- <div>
                                      <el-button type="primary" class="inbutton">保存</el-button>
                                      <el-button type="primary" class="inbutton">保存并使用</el-button>
                                  </div> -->
                              </div>
                          </div>
                        </el-tab-pane>
                        <el-tab-pane label="按钮菜单">
                            <div style="display: flex; justify-content: space-around;">
                                <!-- 展示图 -->
                                <div>
                                    <img src="http://yhx-img.oss-cn-hongkong.aliyuncs.com/web/img@2x.png" />
                                </div>
                                <!-- 设置区域 -->
                                <div style="width:400px;box-shadow:0 0 1px #000 inset;">
                                    <div style="background: #EEEEEE;height:30px;line-height:30px;">内容设置</div>
                                    <div style="font-size:15px; margin:5px;">编辑内容</div>
                                    <font>多列布局：</font>
                                    <el-switch v-model="multiseriateswich" @change="multiseriatechange" active-color="#13ce66" inactive-color="#ff4949">
                                    </el-switch>
                                    <!-- 	十个按钮控件列表 (请后续把style样式统一)-->
                                    <div id="Icon" style="width:100%">
                                                <div class="grid-content bg-purple flex_wrap" style="overflow:none">
                                                  <img
                                                  v-for="(item,index) in btnmenu_img_url.slice(0,5)"
                                                  :src="item.url"
                                                  style="margin-left:4.5%"
                                                  class="itemicos"
                                                  @click="imgclick(index,$event)"
                                                  :name="item.name"
                                                   />
                                                </div>
                                    </div>
                                    <div class="Icon" style="width:100%" :class="[multiseriateswich?'insecblock':'iconsec']">
                                                <div class="grid-content bg-purple flex_wrap" style="overflow:none">
                                                  <img
                                                  v-for="(item,index) in btnmenu_img_url.slice(5)"
                                                  style="margin-left:4.5%"
                                                  :src="item.url"
                                                  class="itemicos"
                                                  @click="imgclick(index,$event)"
                                                  :name="item.name" />
                                                </div>
                                    </div>



                                    <el-form :data="btnmenu_img_link" label-width="90px">
                                            <el-form-item label="活动名称">
                                                <el-input v-model="iconname" @input="activechange" style="width:220px;padding-left:10px;"></el-input>
                                            </el-form-item>
                                        <el-form-item label="链接">
                                            <!-- <el-select v-model="btnmenu_img_link.region" placeholder="请选择活动区域">
                                                <el-option label="区域一" value="shanghai"></el-option>
                                                <el-option label="区域二" value="beijing"></el-option>
                                            </el-select> -->
                                            <el-select v-model="btnmenu_img_link_value" placeholder="请选择">
                                              <el-option
                                                v-for="item in btnmenu_img_link"
                                                :label="item.label"
                                                :value="item.value">
                                              </el-option>
                                            </el-select>
                                        </el-form-item>
                                        <el-form-item label="">
                                          <el-select v-model="btnmenu_link_to_value" placeholder="请选择">
                                            <el-option
                                              v-for="item in btnmenu_link_to"
                                              :label="item.label"
                                              :value="item.value">
                                            </el-option>
                                          </el-select>
                                        </el-form-item>
                                    </el-form>
                                    <div>
                                        <el-button type="primary" @click="btnsave" class="inbutton">保存</el-button>
                                        <!-- <el-button type="primary" class="inbutton">保存并使用</el-button> -->
                                    </div>
                                </div>
                            </div>
                        </el-tab-pane>
                        <el-tab-pane label="商城营业">
                            <div style="display: flex; justify-content: space-around;">
                                <!-- 展示图 -->
                                <div>
                                    <img src="http://yhx-img.oss-cn-hongkong.aliyuncs.com/web/img-4@2x.png" />
                                </div>
                                <!-- 设置区域 -->
                                <div style="width:400px;box-shadow:0 0 1px #000 inset;">
                                    <div style="background: #EEEEEE;height:30px;line-height:30px;">内容设置</div>
                                    <div style="font-size:15px; margin:5px;">编辑内容</div>
                                    <el-form :label-position="labelPosition" label-width="160px">
                                      <el-form-item label="商城营业状态">
                                        <el-switch
                                          v-model="mallswich"
                                          active-color="#13ce66"
                                          inactive-color="#ff4949">
                                        </el-switch>
                                      </el-form-item>
                                      <el-form-item label="自动切换营业状态">
                                        <el-switch
                                          v-model="businessswich"
                                          active-color="#13ce66"
                                          inactive-color="#ff4949">
                                        </el-switch>
                                      </el-form-item>
                                      <el-form-item label="活动时间">
                                        <el-time-picker
                                          v-model="business_hours.businessbegintime"
                                          placeholder="请选择开始时间">
                                        </el-time-picker>
                                      </el-form-item>
                                      <el-form-item label="">
                                        <el-time-picker
                                          v-model="business_hours.businessendtime"
                                          placeholder="请选择结束时间">
                                        </el-time-picker>
                                      </el-form-item>
                                      <el-form-item label="商场休息图片">
                                      </el-form-item>
                                      <el-form-item label="">
                                        <el-upload
                                          class="successnone"
                                          action="http://yhxapi.me/mock/24/admin/UpOssImage"
                                          list-type="picture-card"
                                          :on-preview="businessPictureCardPreview"
                                          :on-remove="businessRemove">
                                          <i class="el-icon-plus"></i>
                                        </el-upload>
                                        <el-dialog :visible.sync="businessimg">
                                          <img width="100%" :src="businessImageUrl" alt="">
                                        </el-dialog>
                                      </el-form-item>
                                      <div class="flex_c_m">
                                        <el-button size="small" @click="businesssave" type="primary">保存</el-button>
                                      </div>
                                    </el-form>
                                </div>

                            </div>
                        </el-tab-pane>
                    </el-tabs>
                </div>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
    export default {
        name: 'Shopping',
        components: {},
        data() {
            return {
              //顶部
              link:[],//链接
              sonactivename:'0',
              stype:0,
              linkvalue:'',
              linktovalue:"",
              link_to:[],//链接分类
              imgurl:[],//图片
              btmlink:[],//链接
              btmlink_to:[],//链接分类
              btmimgurl:[],//图片
              options: [{
                value: '1',
                label: '开启营业'
              }, {
                value: '-1',
                label: '关闭营业'
              }],
              //按钮菜单
              btnmenu_img_link_value:'',
              btnmenu_link_to_value:'',
              mallswich:false,
              businessswich:false,
              business_hours:{
                businessbegintime:'',
                businessendtime:'',
              },
              multiseriateswich:false,
              businessvalue: '',
              labelPosition: 'right',
              business: {
                name: '',
                region: '',
                type: ''
              },
              // 按钮菜单图片
              btnmenuimg:'',
              iconname:'',
              btnmenu_img_link:[],
              btnmenu_link_to:[],
              btnmenu_img_url:[],
              secbtnmenu_img_url:[],
              btnmenu_malls_sorts:[],
              businessImageUrl: '',
              businessimg: false,
                activeName: 'first',
                tabPosition: 'left',
                dialogImageUrl: '',
                dialogVisible: false,
                info:[],
                form: {
                    name: '',
                    region: '',
                    date1: '',
                    date2: '',
                    delivery: false,
                    type: [],
                    resource: '',
                    desc: ''
                },
                fileList: [{
                    name: 'food.jpeg',
                    url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
                }, {
                    name: 'food2.jpeg',
                    url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
                }]
            }
        },
        created(){
           this.getHomeData();
           this.btninfo();

        },
        methods: {
          handleClick(tab, event) {
            this.stype=tab.name;
            if (tab.name==1) {
              this.getdowninfo();
            }else if (tab.name==0) {
              this.getHomeData();
            }

          },
          //点击获取图片name
          imgclick(index,e){
            console.log(index);
            this.iconname=e.target.name;
            // console.log(this.btnmenu_img_link[index].label);
            // console.log(this.btnmenu_link_to[index].label);
            this.btnmenu_img_link_value=this.btnmenu_img_link[index].label;
            this.btnmenu_link_to_value=this.btnmenu_link_to[index].label;
          },
          //名称修改
          activechange(value){
            console.log(value);
          },
          async btninfo(){
            const result = await axios.get(Rootpath.BASE_URL + 'btnmenu');
            this.btnmenu_img_link=result.data.topInfo.img_link;
            this.btnmenu_malls_sorts=result.data.topInfo.malls_sorts;
            this.btnmenu_img_link_value=this.btnmenu_img_link[0].value;

            for (var z = 0; z < this.btnmenu_img_link.length; z++) {
              let btnlt=this.btnmenu_img_link[z].link_to;
              for (var q = 0; q < btnlt.length; q++) {
                this.btnmenu_link_to.push(btnlt[q]);
                this.btnmenu_link_to_value=this.btnmenu_link_to[0].value;
                console.log(this.btnmenu_link_to_value);
              }
            }
            let bil=this.btnmenu_img_link;
            for (var i = 0; i < bil.length; i++) {
              for (var j = 0; j < bil[i].img.length; j++) {
                this.btnmenu_img_url.push(bil[i].img[j]);
              }


            }
            // this.btnmenu_img_url=
            // btnmenuimg
          },
          //按钮菜单保存
          async btnsave(index) {
            let that = this;
            axios.post(Rootpath.BASE_URL + 'saveBtnmenu', {
                    img_link: that.btnmenu_img_link,
                        // data:that.form
                })
                .then(function (response) {
                    console.log("chenggong");
                })
                .catch(function (error) {
                    console.log(error);
                });
          },
          // 获取数据
          async getHomeData() {
            const result = await axios.get(Rootpath.BASE_URL + 'getMallsOpen');
            this.info = result.data.info;
            //顶部广告
            const json = await axios.get(Rootpath.BASE_URL + 'topadvertisement?stype='+this.stype);
            let ti=json.data.topInfo.malls_sorts;
            this.link=ti;
            for (var i = 0; i < ti.length; i++) {
              let lt=ti[i].link_to;
              for (var j = 0; j < lt.length; j++) {
                this.link_to.push(lt[j]);
              }
            }
            let iu=json.data.topInfo.img_link
            for (var z = 0; z < iu.length; z++) {
              this.imgurl=iu[z].img;
            }
          },
          //底部获取数据
          async getdowninfo(){
            //底部广告
            const json = await axios.get(Rootpath.BASE_URL + 'topadvertisement?stype='+this.stype);
            let tf=json.data.topInfo.malls_sorts;
            this.btmlink=tf;
            for (var i = 0; i < tf.length; i++) {
              let lt=tf[i].link_to;
              for (var j = 0; j < lt.length; j++) {
                this.btmlink_to.push(lt[j]);
              }
            }
            let iu=json.data.topInfo.img_link
            for (var z = 0; z < iu.length; z++) {
              this.btmimgurl=iu[z].img;
            }
          },
          //顶部select
          linkchange(value){
            // console.log(value);
            if (value==1) {
              console.log("操作成功");
            }
          },
          linktochange(value){
            // console.log(value);
            if (value==1) {
              console.log("操作成功");
            }
          },
          //底部select
          btmlinkchange(value){
            // console.log(value);
            if (value==1) {
              console.log("操作成功");
            }
          },
          btmlinktochange(value){
            // console.log(value);
            if (value==1) {
              console.log("操作成功");
            }
          },
          multiseriatechange(){
            console.log(this.multiseriateswich);
            if (this.multiseriateswich==true) {

            }
          },
          //商城营业保存
          businesssave(){
            axios.post(Rootpath.BASE_URL + 'leaveladd', {
            business_status: this.mallswich,
            autobusiness_status: this.businessswich,
            business_hours: this.business_hours,
            img: '22'
                // data:that.form
            })
            .then(function (response) {
                // that.dialogFormVisible = false;
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });
          },
            Return() { /* 返回界面 */  
                    this.$router.push({
                        path: '/market/Discount',
                        query: {
                            id: 1
                        }
                    })
                },
                handleRemove(file, fileList) {
                    console.log(file, fileList);
                },
                handlePreview(file) {
                    console.log(file);
                },
                handlePictureCardPreview(file) {
                    this.dialogImageUrl = file.url;
                    this.dialogVisible = true;
                },
                businessRemove(file, fileList) {
                    console.log(file, fileList);
                },
                businessPictureCardPreview(file) {
                    this.businessImageUrl = file.url;
                    this.businessimg = true;
                },
        }
    };
</script>
<style>
    /* 添加图片 */
    .addimg {
        height: 35px;
        width: 200px;
        border: dashed 1px #436BE5;
        margin: auto;
        text-align: center;
        line-height: 35px;
        color: #436BE5;cursor:pointer
    }
    .iconsec{
      display: none;
    }
    .insecblock{
      display: inline-block;
    }
    /* 保存butoon的距离 */
    .inbutton {
        margin-left: 90px;
        margin-top: 190px;
    }
    .itemicon {
        height: 55px;
        width: 55px;
    }
    .itemicos {
        height: 55px;
        width: 55px;
        border: solid 1px rgb(185, 180, 180);
    }
</style>
