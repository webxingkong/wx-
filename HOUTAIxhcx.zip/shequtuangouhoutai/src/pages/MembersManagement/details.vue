<template>
	  <div class="GroupManage-page">
	    应用管理
	  </div>
	</template>
	<script>
	export default {
	  name: 'GroupManage',
	  components: {},
	};
	</script>