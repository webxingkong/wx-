<template>
    <div class="select">
        <div class="select-table">
            <el-tabs v-model="activeName">
                <!--余额-->
                <el-tab-pane label="会员详情" name="first">
                    <!--头像-->
                    <div class="fillet frame">
                        <el-row :gutter="20" ref="user_info" :model="user_info">
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_line_c_m">
                                    <div class="block">
                                        <el-avatar :size="70" :src="user_info.head_img"></el-avatar>
                                    </div>
                                </div>
                            </el-col>
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_m">
                                    {{user_info.name}}
                                    <br>
                                    <br>V {{user_info.user_level_name}}
                                </div>
                            </el-col>
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_line_c_m">
                                    会员姓名：{{user_info.name}}
                                    <br>
                                    <br>性别：{{user_info.user_sex}}
                                    <br>
                                    <br>累计积分：{{user_info.cumulative_integrals}}
                                    <br>
                                    <br>可用积分：{{user_info.user_integrals}}
                                </div>
                            </el-col>
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_line_c_m">
                                    联系手机：{{user_info.mobile}}
                                    <br>
                                    <br>会员地址：{{user_info.address_detl}}
                                    <br>
                                    <br>注册时间：{{user_info.create_time}}
                                    <br>
                                    <br>最后登录时间：{{user_info.login_time}}
                                </div>
                            </el-col>

                        </el-row>

                    </div>
                    <!--记录-->
                    <h5>购买记录</h5>
                    <div class="frame">
                        <el-row :gutter="20">
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_c_m">
                                    近一个月消费次数:{{purchase.pay_count}}
                                </div>
                            </el-col>
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_c_m">
                                    近一个月消费金额:{{purchase.pay_sum}}
                                </div>
                            </el-col>
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_c_m">
                                    余额:{{purchase.user_money}}
                                </div>
                            </el-col>
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_c_m">
                                    优惠劵:{{purchase.coupon_count}}
                                </div>
                            </el-col>
                        </el-row>
                    </div>
                    <!--账户-->
                    <h5>银行账户</h5>
                    <div class="frame">
                        <el-row ref="user_info" :model="user_info" :gutter="20">
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_c_m">
                                    开户银行:{{user_user_bank.account_bank}}
                                </div>
                            </el-col>
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_c_m">
                                    账户姓名:{{user_info.name}}
                                </div>
                            </el-col>
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_c_m">
                                    开户支行:{{user_user_bank.account_name}}
                                </div>
                            </el-col>
                            <el-col :span="6">
                                <div class="grid-content bg-purple flex_c_m">
                                    开户账户:{{user_user_bank.account_number}}
                                </div>
                            </el-col>
                        </el-row>


                    </div>
                    <br>
                    <div class="search">
                        <!--搜索-->
                        <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
                            <el-form-item label="时间" style="margin-top: 20px;">
                              <el-date-picker
                                v-model="formInline.create_time"
                                type="daterange"
                                size="small"
                                style="width: 400px;"
                                range-separator="至"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                              </el-date-picker>
                            </el-form-item>&emsp;&emsp;
                            <el-form-item label="订单号" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.order_number" style="width: 120px;"></el-input>
                            </el-form-item>&emsp;
                            <el-form-item style="margin-top: 20px;">
                                <el-button size="small" type="primary" @click="ordersearch">搜索</el-button>
                            </el-form-item>
                        </el-form>
                        <!--按钮-->
                    </div>
                    <br>
                    <br>
                    <br />
                    <br />
                    <div class="Button">
                        <div class="right">
                            <el-button size="medium">导出查询结果</el-button>
                        </div>
                    </div>
                    <br>
                    <!--数据-->
                    <el-table ref="multipleTable" :data="order_record" tooltip-effect="dark" style="width: 100%">
                        <el-table-column width="55"></el-table-column>

                        <el-table-column prop="order_number" align="center" label="订单号"></el-table-column>
                        <el-table-column prop="community_name" align="center" label="店铺名称"></el-table-column>
                        <el-table-column prop="create_time" align="center" label="下单时间"></el-table-column>
                        <el-table-column prop="pay_money" align="center" label="订单实付金额"></el-table-column>
                        <el-table-column prop="refund_amount" align="center" label="退款金额"></el-table-column>
                        <el-table-column prop="order_sum" align="center" label="实际金额"></el-table-column>

                    </el-table>
                    <br>
                    <br>
                    <el-button size="small" type="primary" @click="returnback">返回</el-button>

                </el-tab-pane>
                <!--余额明细-->
                <el-tab-pane label="积分记录" name="second">
                    <div class="search">
                        <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
                            <el-form-item label="累计积分" style="margin-top: 20px;">
                                <el-input size="small" v-model="integral_record.order_record" style="width: 120px;"></el-input>
                            </el-form-item>
                            <el-form-item label="选择变动时间" style="margin-top: 20px;">
                                <!-- <el-input size="small" v-model="integral_record.change_time" style="width: 120px;"></el-input> -->
                                <el-date-picker
                                  v-model="integral_record.change_time"
                                  type="daterange"
                                  style="width: 400px;"
                                  size="small"
                                  range-separator="至"
                                  start-placeholder="开始日期"
                                  end-placeholder="结束日期">
                                </el-date-picker>
                            </el-form-item>

                            <el-form-item style="margin-top: 20px;">
                                <el-button size="small" type="primary" @click="search">搜索</el-button>
                            </el-form-item>
                        </el-form>
                        <!---->
                    </div>
                    <br>
                    <br>

                    <br>
                    <el-table ref="multipleTable" :data="integr_list" tooltip-effect="dark" style="width: 100%">
                        <el-table-column width="55"></el-table-column>
                        <el-table-column prop="update_time" align="center" label="变动时间"></el-table-column>
                        <el-table-column prop="change_b" align="center" label="变动"></el-table-column>
                        <el-table-column prop="balance" align="center" label="结余"></el-table-column>
                        <el-table-column prop="remarks" align="center" label="备注"></el-table-column>

                    </el-table>
                    <br>


                </el-tab-pane>
                </el-tab-pane>
            </el-tabs>

        </div>
    </div>
</template>

<script>
    import https from "../../../api/https.vue"
    import axios from '../../axios.js';
    import Rootpath from "../../../api/index.js"
    export
    default {
        data() {
                return {
                    circleUrl: "https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg", //头像
                    activeName: 'first',
                    user_info: [],
                    order_record: [],
                    purchase:[],
                    integr_list: [], //积分列表
                    formInline: {
											create_time:'',
                      order_number:''
                    },
                    integral_record:{
                      change_time:'',
                      order_record:''
                    },
										user_user_bank:'',

                };
            },
            created() {
                this.getData();
                this.integrlist();
            },
            methods: {
                    //返回
                    returnback() { 
                        this.$router.push({
                            path: '/form/Members'
                        })
                    },
                    //积分列表
                    async integrlist() {
                      var user_id = this.$route.query.user_id
                        const result = await axios.get(Rootpath.BASE_URL + 'record?user_id=' + user_id);
                        console.log(result.data.integr_list);
                        this.integr_list = result.data.integr_list
                    },
                    // 获取数据
                    async getData() {
                      var user_id = this.$route.query.user_id
              				const result = await axios.get(Rootpath.BASE_URL + 'userdetail?user_id=' + user_id);
                        // const result = await axios.get(Rootpath.BASE_URL + 'userdetail?user_id=1');
                        console.log(result.data.user_info);
												// let userinfo =user_info;
                        this.user_info = result.data.user_info[0];
												this.user_user_bank=result.data.user_info[0].user_user_bank[0];
												console.log(this.user_info.user_user_bank);
                        this.order_record = result.data.order_record;
                        this.purchase=result.data.purchase;
                        this.total = result.data.user_info.length;
                    },
                    //搜索
                    async ordersearch() {
                        var user_id = this.$route.query.user_id
                        let that = this;
                        let filedate=that.formInline.create_time;
                        let date1='';
                        for (var i = 0; i < filedate.length; i++) {
                          var d = new Date(filedate[i]);
                          d=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
                          if (date1=="") {
                            date1=d;
                          }else {
                            date1 = date1+' - '+d
                          }
                        }
                        const result = await axios.get(Rootpath.BASE_URL +
                          'consumesech?user_id=' + user_id+
                          '&order_number='+that.formInline.order_number+
                          '&create_time='+date1);
                        this.order_record = result.data.order_record;
                    },
										//搜索
                    async search() {
                            var user_id = this.$route.query.user_id
                            let that = this;
                            let filedate=that.integral_record.change_time;
                            let date1='';
                            for (var i = 0; i < filedate.length; i++) {
                              var d = new Date(filedate[i]);
                              d=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
                              if (date1=="") {
                                date1=d;
                              }else {
                                date1 = date1+' - '+d
                              }
                            }
                            const result = await axios.get(Rootpath.BASE_URL +
                              'recordsech?user_id=' + user_id+
                              '&order_number='+that.integral_record.order_record+
                              '&create_time='+date1);
                              that.integr_list = result.data.integr_list
                    },

            },
    };
</script>

<style scoped>
    .fillet {
        border-top-left-radius: 48px;
        /* 左上 */
        /* border-top-right-radius:20px; */
        /* 右上 */
        /* border-bottom-right-radius:20px; */
        /*右下*/
        border-bottom-left-radius: 48px;
        /*左下*/
    }
    .v {
        color: #F6BB6A;
    }
    .block {} .flex_m {
        /* 垂直居中*/
        display: flex;
        align-items: center;
    }
    .flex_line_c_m {
        /* 多行垂直居中，水平居中*/
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        font-size: 6px;
        color: #000000;
    }
    .frame {
        width: 100%;
        height: 105px;
        background-color: #EAEAEA;
    }
    /**/
    .as {
        width: 100%;
    }
    .el-row {
        margin-bottom: 20px;
        &: last-child {
            margin-bottom: 0;
        }
    }
    .el-col {
        border-radius: 4px;
    }
    .bg-purple-dark {
        height: 100px;
    }
    .bg-purple {
        height: 100px;
    }
    .bg-purple-light {} .grid-content {
        border-radius: 4px;
        min-height: 36px;
    }
    .row-bg {
        padding: 10px 0;
        background-color: #f9fafc;
    }
    .block {
        text-align: right;
    }
    /**/
    .footer {
        height: 44px;
        text-align: right;
    }
    .right {
        text-align: right;
    }
    p {
        position: relative;
        top: -12px;
    }
    .text {
        display: flex;
        left: 20px;
        position: relative;
        top: 15px;
    }
    h3 {
        color: #436be5;
        border-bottom: solid 2px #436be5;
        margin-left: 20px;
    }
    .text-frame-member {
        width: 100px;
        position: relative;
        top: 10px;
    }
    .text-frame {
        height: 50px;
        width: 100%;
        background-color: #ffffff;
        border-bottom: solid 1px #f0f2f0;
    }
    .select-table {
        margin: auto;
        width: 96%;
        margin-top: 20px;
    }
    .select {
        margin: auto;
        width: 96%;
        background-color: #ffffff;
    }
    /*border: solid 1rpx #007AFF;
  */
    .search {
        height: 70px;
        background-color: #f5f5f5;
    }
    .search-Button {
        margin-left: 20px;
    }
    .block {
        text-align: right;
    }
</style>
