<template>
    <div class="select MembersManagement-page">
        <div class="select-table">
            <el-tabs v-model="activeName">
                <el-tab-pane label="会员管理" name="first"></el-tab-pane>
            </el-tabs>
            <div class="search">

                <el-form :inline="true" :data="searchlist" class="demo-form-inline">
                    <el-form-item label="会员名称" style="margin-top: 20px;
">
                        <el-input size="small" v-model="searchlist.name" style="width: 120px;"></el-input>
                    </el-form-item>
                    <el-form-item label="手机号" style="margin-top: 20px;">
                        <el-input size="small" v-model="searchlist.mobile" style="width: 120px;"></el-input>
                    </el-form-item>
                    <el-form-item label="会员状态" style="margin-top: 20px;">
                        <el-input size="small" v-model="searchlist.state" style="width: 120px;"></el-input>
                    </el-form-item>
                    &emsp;
                    <el-form-item label="注册时间" style="margin-top: 20px;">
                        <el-input size="small" v-model="searchlist.create_time" style="width: 120px;"></el-input>
                    </el-form-item>
                    &emsp;
                    <el-form-item style="margin-top: 20px;">
                        <el-button size="small" type="primary" @click="search">搜索</el-button>
                    </el-form-item>
                </el-form>

            </div>
            <br />

            <div class="right">
                <el-button size="medium">导出查询结果</el-button>
            </div>
            <el-table ref="multipleTable" @row-click="select" :data="user_list.slice((currentPage-1)*pagesize,currentPage*pagesize)" tooltip-effect="dark" @selection-change="handleSelectionChange">
                <el-table-column type="selection"></el-table-column>
                <el-table-column prop="wx_name" label="会员名称">

                </el-table-column>
                <el-table-column prop="mobile" label="手机号码"></el-table-column>
                <el-table-column prop="user_level_name" label="等级"></el-table-column>
                <el-table-column prop="user_integrals" label="积分"></el-table-column>
                <el-table-column prop="create_time" label="注册时间"></el-table-column>
                <el-table-column prop="state" label="状态" show-overflow-tooltip></el-table-column>
                <el-table-column fixed="right" label="操作">
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="getEditData(scope.row)">编辑</el-button>

                        <el-button type="text" size="small" @click="dialogVis(scope.row)">详情</el-button>

                        <el-button type="text" size="small" @click="frozen(scope.row)">冻结</el-button>
                    </template>
                </el-table-column>


            </el-table>
            <br />
            <!--分页-->
            <el-pagination class="block" background @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[5, 10, 20, 50]" :page-size="pagesize" layout="total, sizes, prev, pager, next, jumper" :total="total">
            </el-pagination>

        </div>
        <!--对话框-->
        <el-dialog title="会员编辑" ref="editform" :model="editform" :visible.sync="dialogFormVisible" width="36%">
            <el-form>
                <el-form-item label="会员手机" :label-width="formLabelWidth">
                    <el-input v-model="editform.user_detail.mobile" clearable></el-input>
                </el-form-item>
                <el-form-item label="会员等级" :label-width="formLabelWidth">
                  <el-select class="inputtext" v-model="level_value" @change="shoptypechange" placeholder="请选择活动区域">
                    <el-option
                      v-for="item in level"
                      :value="item.value"
                      :key="item.id"
                      :label="item.label">
                    </el-option>

                  </el-select>
                </el-form-item>
                <el-form-item label="会员积分" :label-width="formLabelWidth">
                    <el-input v-model="editform.user_detail.user_integrals" clearable></el-input>
                </el-form-item>
                <el-form-item label="会员推荐" :label-width="formLabelWidth">
                    <el-select class="inputtext" v-model="member_value" placeholder="请选择">
                      <el-option
                        v-for="item in member"
                        :value="item.value"
                        :key="item.id"
                        :label="item.label">
                      </el-option>

                    </el-select>
                </el-form-item>
                <el-form-item label="推荐人" :label-width="formLabelWidth">
                    <el-input v-model="editform.user_referrer.referrer" clearable></el-input>
                </el-form-item>
                <el-form-item label="银行账户">
                    <br />
                    <el-form-item label="开户银行" :label-width="formLabelWidth">
                        <el-input v-model="editform.bank.account_type" clearable></el-input>
                    </el-form-item>
                    <br />
                    <el-form-item label="开支银行" :label-width="formLabelWidth">
                        <el-input v-model="editform.bank.account_bank" clearable></el-input>
                    </el-form-item>
                    <br />
                    <el-form-item label="账户银行" :label-width="formLabelWidth">
                        <el-input v-model="editform.bank.account_name" clearable></el-input>
                    </el-form-item>
                    <br />
                    <el-form-item label="银行卡号" :label-width="formLabelWidth">
                        <el-input v-model="editform.bank.account_number" clearable></el-input>
                    </el-form-item>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="editsave">确 定</el-button>
            </div>
        </el-dialog>
        <!--对话框结束-->

    </div>

</template>

<script>
    import https from "../../../api/https.vue"
    import axios from '../../axios.js';
    import Rootpath from "../../../api/index.js"
    export
    default {
        data() {
                return {
                  level_value:'',
                  member:[
                    {
                      label:'允许推荐',
                      value:'1'
                    },
                    {
                      label:'不允许推荐',
                      value:'2'
                    }
                  ],
                  member_value:'',
                    total: 0,
                    currentPage: 1,
                    pagesize: 5,
                    activeName: 'first',
                    user_list: [],
                    // formInline: {
                    // 	user: '',
                    // 	region: '',
                    // 	states: '',
                    // 	times: ''
                    // },
                    //搜索传值
                    searchlist: {
                        name: '',
                        mobile: '',
                        state: '',
                        create_time: ''
                    },
                    clickform: {

                    },
                    //
                    dialogTableVisible: false,
                    dialogFormVisible: false,
                    level:[],
                    user_id:'',
                    editform: {
                      "level": [
                         {
                             "value": 1,
                             "lable": "注册会员",
                             "user_default": true
                         },
                         {
                             "value": 2,
                             "lable": "默认",
                             "user_default": false
                         }
                     ],
                     "user_detail": {
                         "mobile": "18777217771",//电话
                         "user_integrals": 892//积分
                     },
                     "user_referrer": {
                         "allow_yn": 1,// 0允许推荐 1不允许
                         "referrer": null  //推荐人
                     },
                     "bank":
                         {
                             "id": 1,
                             "account_type": 1,
                             "account_bank": "农业银行",
                             "account_name": "农业",
                             "account_number": "1231221"
                         }
                    },
                    formLabelWidth: '120px'
                };
            },
            created() {
                this.getData();
                // this.getEditData();
            },
            methods: {
                    //等级选择
                    shoptypechange(value){
                      console.log(value);
                      this.level_value=value;
                    },
                    //编辑
                    async getEditData(row) {
                      console.log(row.id);
                      this.dialogFormVisible = true;
                      let that = this;
                      that.user_id=row.id;
                      const result = await axios.get(Rootpath.BASE_URL + 'editlist?user_id='+row.id);
                      that.editform=result.data.user_edit;
                      that.editform.bank=result.data.user_edit.bank;
                      that.level=result.data.user_edit.level;
                      console.log(that.editform);
                    },
                    //编辑保存
                    editsave(){
                      let that = this;
                      axios.post(Rootpath.BASE_URL + 'doeditlist', {
                             user_id:that.user_id,
                             user_level_id:that.level_value,
                             mobile:that.editform.user_detail.mobile,
                             account_type:that.editform.bank.account_type,
                             account_bank:that.editform.bank.account_bank,
                             account_name:that.editform.bank.account_name,
                             account_number:that.editform.bank.account_number,
                             allow_yn:that.editform.user_referrer.allow_yn,
                             referrer:that.editform.user_referrer.referrer,
                         })
                         .then(function (response) {
                           console.log(response);
                             that.dialogFormVisible = false;
                             that.getData();
                         })
                         .catch(function (error) {
                             console.log(error);
                         });
                    },
                    toggleSelection(rows) {
                        if (rows) {
                            rows.forEach(row => {
                                this.$refs.multipleTable.toggleRowSelection(row);
                            });
                        } else {
                            this.$refs.multipleTable.clearSelection();
                        }
                    },
                    handleSelectionChange(val) {
                        this.multipleSelection = val;
                    },
                    //获取点击的数据
                    select(val) {
                        this.clickform = val;
                    },
                    //冻结
                    frozen(row) {
                      let that = this;
                        this.$confirm('是否冻结?', '冻结', {
                                confirmButtonText: '确定',
                                cancelButtonText: '取消',
                                type: 'warning'
                            })
                            .then(() => {
                              axios.post(Rootpath.BASE_URL + 'user_freeze', {
                                     user_id:row.id,
                                 })
                                 .then(function (response) {
                                   console.log(response);
                                     that.getData();
                                 })
                                 .catch(function (error) {
                                     console.log(error);
                                 });
                            })
                            .catch(() => {
                                this.$message({
                                    type: 'info',
                                    message: '已取消冻结'
                                });
                            });
                    },
                    //详情
                    dialogVis(row) { 
                      console.log(row);
                      this.$router.push({path:'/form/Members/Detailed',query: {
               				 user_id: row.id,
               			 }});
                    },
                    //分页
                    handleSizeChange(size) {
                        this.pagesize = size
                    },
                    handleCurrentChange(currentPage) {
                        this.currentPage = currentPage
                    },
                    // 获取数据
                    async getData() {
                        const result = await axios.get(Rootpath.BASE_URL + 'userlist');
                        console.log(result);
                        // console.log(session.getSession().setAttribute("company_id", userInfoEntity));
                        this.user_list = result.data.user_list;
                        this.total = result.data.user_list.length;
                    },

                    //搜索
                    async search() {
                        let that = this;
                        axios.get(Rootpath.BASE_URL + 'usersearch', {
                                params: {
                                    name: that.searchlist.name,
                                    mobile: that.searchlist.mobile,
                                    state: that.searchlist.state,
                                    create_time: that.searchlist.create_time
                                }
                            })
                            .then(function (response) {
                                console.log(response);
                                that.user_list = response.data.user_list
                                that.total = response.data.user_list.length
                            })
                            .catch(function (error) {
                                console.log(error);
                            });
                    },
            },


    };
</script>

<style scoped>
    .footer {
        height: 44px;
        text-align: right;
    }
    .right {
        text-align: right;
    }
    p {
        position: relative;
        top: -12px;
    }
    .text {
        display: flex;
        left: 20px;
        position: relative;
        top: 15px;
    }
    h3 {
        color: #436be5;
        border-bottom: solid 2px #436be5;
        margin-left: 20px;
    }
    .text-frame-member {
        width: 100px;
        position: relative;
        top: 10px;
    }
    .text-frame {
        height: 50px;
        width: 100%;
        background-color: #ffffff;
        border-bottom: solid 1px #f0f2f0;
    }
    .select-table {
        margin: auto;
        width: 96%;
        margin-top: 20px;
    }
    .select {
        margin: auto;
        width: 96%;
        background-color: #ffffff;
    }
    /*border: solid 1rpx #007AFF;
*/
    .search {
        height: 70px;
        background-color: #f5f5f5;
    }
    .search-Button {
        margin-left: 20px;
    }
    .block {
        text-align: right;
    }
</style>
