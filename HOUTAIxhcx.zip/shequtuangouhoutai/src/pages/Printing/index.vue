<template>
  <div class="Printing-page">打印配置</div>
</template>
<script>
export default {
  name: 'Printing',
  components: {},
};
</script>
