<template lang="html">
  <div class="Citymanage">
    <div class="ml20">
      <div class="headermsg flex_m">
        <i class="el-icon-info" style="margin-left:15px;margin-right:15px;"></i>
        <span>温馨提示：为了系统的正常运营，您可以在项目城市数量以及团长数量用尽之前联系管理员购买</span>
      </div>
    </div>
    <div class="ml20">
      <el-row :gutter="20">
        <el-col :span="6"><div class="grid-content sitenum bg-purple flex_c_m">城市站点数量：{{top_list.company_sum}}</div></el-col>
        <el-col :span="6"><div class="grid-content sitenum bg-purple flex_c_m">团长数量：{{top_list.leader_sum}}</div></el-col>
        <el-col :span="6"><div class="grid-content sitenum bg-purple flex_c_m" style="visibility:hidden"></div></el-col>
        <el-col :span="6"><div class="grid-content sitenum bg-purple flex_c_m" style="visibility:hidden"></div></el-col>
      </el-row>
    </div>
    <div class="ml20">
      <el-row :gutter="20">
        <el-col :span="6" v-for="(item,index) in company_list">
          <div class="cityinformation">
            <div class="companyname flex_c_m">
              {{item.company_name}}
            </div>
            <div class="flex_c_m">
              <img class="companyimg" :src="item.project_logo" alt="">
            </div>
            <div class="flex_c_m companystatus">
              <div class="">

                <i v-if="item.state=='关闭运营'" class="el-icon-error"></i>
                <i v-if="item.state=='正常运营'" class="el-icon-success"></i>
                <span>{{item.state}}</span>
              </div>
            </div>
            <div class="companybtn flex_lr_ms">
              <el-button type="primary" size="small" @click="geteditData(index,$event)">修改信息</el-button>
              <el-button size="small" @click="close(index,$event)">关闭运营</el-button>
              <el-button size="small" v-if="item.state=='关闭运营'" disabled>关闭运营</el-button>
              <el-button size="small">设置默认城市</el-button>
            </div>
            <div class="companyinformation">
              <p>公司名称：{{item.company_name}}</p>
              <p>联系人：{{item.contacts}}</p>
              <p>联系电话：{{item.contacts_phone}}</p>
              <p>所属城市：{{item.city_origin}}</p>
              <p>地址：{{item.address}}</p>
              <p>团长数量：{{item.max_leader_count}}</p>
            </div>
          </div>
        </el-col>

        <el-col :span="6">
          <div class="cityinformation" @click="addlayout=true">
            <div class="flex_c_m" style="margin-top:50%">
              <i class="el-icon-plus" style="font-size:70px"></i>
            </div>
            <p class="flex_c_m">添加城市</p>
          </div>
        </el-col>
      </el-row>
    </div>
    <!-- 新增弹出框 -->
		<el-dialog title="新增" :model="addinfo" class="layoutbox" width="600px" :visible.sync="addlayout">
      <el-form label-width="100px" class="demo-ruleForm">
				<el-form-item class="leftlabel" label="项目logo：">
          <el-upload
            class="avatar-uploader"
            action="https://jsonplaceholder.typicode.com/posts/"
            :show-file-list="false"
            :on-progress="uploading"
            :on-success="handleAvatarSuccess">
            <img v-if="imageUrl" :src="imageUrl" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
        <el-form-item class="leftlabel" label="项目名称："><el-input v-model="addinfo.company_name" class="inputtext"></el-input></el-form-item>
        <el-form-item class="leftlabel" label="公司名称："><el-input v-model="addinfo.project_name" class="inputtext"></el-input></el-form-item>
        <el-form-item class="leftlabel" label="所在区域：">
          <el-cascader
            v-model="addressvalue"
            :options="addressoptions"
            @change="handleChange">
          </el-cascader>
        </el-form-item>
        <el-form-item class="leftlabel" label="详细地址："><el-input v-model="addinfo.address" class="inputtext"></el-input></el-form-item>
        <el-form-item class="leftlabel" label="联系人："><el-input v-model="addinfo.contacts" class="inputtext"></el-input></el-form-item>
        <el-form-item class="leftlabel" label="联系方式"><el-input v-model="addinfo.contacts_phone" class="inputtext"></el-input></el-form-item>
        <el-form-item class="leftlabel" label="团长数量"><el-input v-model="addinfo.leader_count" class="inputtext"></el-input></el-form-item>
			</el-form>

			<span slot="footer" class="dialog-footer">
				<el-button @click="addlayout = false">取 消</el-button>
				<el-button type="primary" @click="addsave()">确 定</el-button>
			</span>
		</el-dialog>
		<!-- 新增弹出框  结束-->
    <!-- 编辑弹出框 -->
		<el-dialog title="修改" :model="editinfo" class="layoutbox" width="600px" :visible.sync="editlayout">
      <el-form label-width="100px" class="demo-ruleForm">
				<el-form-item class="leftlabel" label="项目logo：">
          <el-upload
            class="avatar-uploader"
            action="https://jsonplaceholder.typicode.com/posts/"
            :show-file-list="false"
            :on-progress="uploading"
            :on-success="handleAvatarSuccess">
            <img v-if="imageUrl" :src="imageUrl" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
        <el-form-item class="leftlabel" label="项目名称："><el-input v-model="editinfo.company_name" class="inputtext"></el-input></el-form-item>
        <el-form-item class="leftlabel" label="公司名称："><el-input v-model="editinfo.project_name" class="inputtext"></el-input></el-form-item>
        <!-- <el-form-item class="leftlabel" label="所在区域：">
          <el-select @change="selectchange(value)" v-model="value" placeholder="请选择" style="width:100%">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item> -->
        <el-form-item class="leftlabel" label="详细地址："><el-input v-model="editinfo.address" class="inputtext"></el-input></el-form-item>
        <el-form-item class="leftlabel" label="联系人："><el-input v-model="editinfo.contacts" class="inputtext"></el-input></el-form-item>
        <el-form-item class="leftlabel" label="联系方式"><el-input v-model="editinfo.contacts_phone" class="inputtext"></el-input></el-form-item>
        <el-form-item class="leftlabel" label="团长数量"><el-input v-model="editinfo.leader_count" class="inputtext"></el-input></el-form-item>
			</el-form>

			<span slot="footer" class="dialog-footer">
				<el-button @click="editlayout = false">取 消</el-button>
				<el-button type="primary" @click="editsave()">确 定</el-button>
			</span>
		</el-dialog>
		<!-- 编辑弹出框  结束-->
  </div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      closeinfo:false,
      addressvalue:[],
      top_list:[],
      addressoptions:[],
      company_list:[],
      addlayout:false,
      editlayout:false,
      imageUrl:'',
      addinfo:{
         province_id: 0,//省
         city_id: 0,//市
         areas_id: 0,//区
         state: 1,//状态 运营状态  -1 关闭  1 开启
         project_logo: "",//图片地址
         project_name: "",
         company_name: "",
         address: "",
         contacts: "",
         contacts_phone: "",
         leader_count:null,//团长数量
      },
      editinfo:{
        province_id: 0,//省
        city_id: 0,//市
        areas_id: 0,//区
        state: 1,//状态 运营状态  -1 关闭  1 开启
        project_logo: "",//图片地址
        project_name: "",
        company_name: "",
        address: "",
        contacts: "",
        contacts_phone: "",
        leader_count:null,//团长数量
      },
      value: '',
      options: [{
          value: '黄金糕',
          label: '黄金糕'
        }, {
          value: '双皮奶',
          label: '双皮奶'
        }, {
          value: '蚵仔煎',
          label: '蚵仔煎'
        }, {
          value: '龙须面',
          label: '龙须面'
        }],

    }
  },
  created() {
    this.getData();
  },
  methods:{
    // 获取数据
    async getData() {
      const result = await axios.get(Rootpath.BASE_URL + 'company_list');
      const json = await axios.get(Rootpath.BASE_URL + 'address_list');
      let that=this;
      that.addressoptions=json.data.linkage;
      that.top_list=result.data.top_list;
      that.company_list=result.data.company_list;
      for (var i = 0; i < that.company_list.length; i++) {
        if (that.company_list[i].state==1) {
          that.company_list[i].state='正常运营'
          console.log(that.company_list[i].state);
        }else {
          that.company_list[i].state='关闭运营'
        }
      }
      console.log(result);
    },
    //点击关闭运营
    async close(index,$event){
      let cid=index;
      let p=this.company_list[cid].id;
      this.closeinfo=this.company_list[cid].state;
      console.log(this.closeinfo);
      const result = await axios.get(Rootpath.BASE_URL + 'company_close?id='+p);


    },
    // 获取修改数据
    async geteditData(index,event) {
      let cid=index;
      let p=this.company_list[cid].id;
      console.log(p);
      this.editlayout=true;
      const result = await axios.get(Rootpath.BASE_URL + 'company_edit?cid='+p);
      console.log(result);
      let that=this;
      that.editinfo=result.data;
    },

    //新增保存
    addsave(){
      let that = this;
      axios.post(Rootpath.BASE_URL + 'company_add', {
        // province_id: that.addinfo.province_id,//省
        // city_id: that.addinfo.city_id,//市
        // areas_id: that.addinfo.areas_id,//区
        addressoptions:that.addressvalue,
        state: that.addinfo.state,//状态 运营状态  -1 关闭  1 开启
        project_logo: that.addinfo.project_logo,//图片地址
        project_name: that.addinfo.project_name,
        company_name: that.addinfo.company_name,
        address: that.addinfo.address,
        contacts: that.addinfo.contacts,
        contacts_phone: that.addinfo.contacts_phone,
        leader_count:that.addinfo.leader_count,//团长数量
        })
        .then(function (response) {
            that.addlayout = false;
            console.log(response);
            that.getData();

        })
        .catch(function (error) {
            console.log(error);
        });
    },
    //修改保存
    editsave(){
      let that = this;
      axios.post(Rootpath.BASE_URL + 'company_doedit', {
        province_id: that.editinfo.province_id,//省
        city_id: that.editinfo.city_id,//市
        areas_id: that.editinfo.areas_id,//区
        state: that.editinfo.state,//状态 运营状态  -1 关闭  1 开启
        //project_logo: that.editinfo.project_logo,//图片地址
        project_name: that.editinfo.project_name,
        company_name: that.editinfo.company_name,
        address: that.editinfo.address,
        contacts: that.editinfo.contacts,
        contacts_phone: that.editinfo.contacts_phone,
        leader_count:that.editinfo.leader_count,//团长数量
        })
        .then(function (response) {
            that.editlayout = false;
            console.log(response);
        })
        .catch(function (error) {
            console.log(error);
        });
    },
    //新增区域选择
    selectchange(value){
      // console.log(value);
      this.value=value;
    },
    handleChange(value) {
        console.log(value);
    },
    handleAvatarSuccess(res, file) {
      this.imageUrl = URL.createObjectURL(file.raw);
    },
    uploading(event, file, fileList){
      axios.post(Rootpath.BASE_URL + 'UpOssImage', {
            img_file:file
        })
        .then(function (response) {
            console.log(response);
            // that.addinfo.project_logo=response.
        })
        .catch(function (error) {
            console.log(error);
        });
    },

  }
}
</script>

<style lang="css">
.avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
.Citymanage{
  background: #ffffff;
  width: 95%;
  margin: 0 auto;
  min-height: 750px;
}
.headermsg{
  background: #A8B7E3;
  width: 750px;
  height: 30px;
}
.sitenum{
  background: #2E5BE2;
  color: #ffffff;
}
.cityinformation{
  height: 600px;
  border: 1px solid #d8d8d8;
}
.companyname{
  font-size: 18px;
  font-weight: bold;
  line-height: 60px;
}
.companyimg{
  width: 110px;
  height: 110px;
}
.companystatus{
  line-height: 80px
}
.companybtn{
  /* width: 55%; */
  margin: 0 auto;
}
.companyinformation{
  margin-left: 8%
}
</style>
