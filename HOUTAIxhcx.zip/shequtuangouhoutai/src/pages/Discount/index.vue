<template>
  <div class="Service-page" style="margin: 20px;">
	  <el-tabs v-model="activeName" @tab-click="handleClick">
	     <el-tab-pane label="优惠卷" name="first">
			 <!-- 优惠卷弹层html -->
		 <div>
<el-dialog
		   title="发放优惠卷"
		   :visible.sync="grant"
		   width="50%"
		   :before-close="grant">
		   <hr />
  <div>
			<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
			<el-form-item label="会员等级" style="margin-top: 20px;">
			 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
				<el-option
				  v-for="item in options"
				  :key="item.value"
				  :label="item.label"
				  :value="item.value">
				</el-option>
			  </el-select>
			</el-form-item>
			<el-form-item label="会员标签" style="margin-top: 20px;">
			 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
				<el-option
				  v-for="item in options"
				  :key="item.value"
				  :label="item.label"
				  :value="item.value">
				</el-option>
			  </el-select>
			</el-form-item>
			<el-form-item label="会员名称" style="margin-top: 20px;">
					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
			</el-form-item>
			<el-form-item>
			<el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">保存</el-button>	
			</el-form-item>
			<el-form-item>
			<div style="padding:20px 0px 0px 115px;"><font></font>已选择:{{Selection_quantity}}<font>可用数量:100</font></div>
			</el-form-item>
			</el-form>
   <el-table
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      @selection-change="handleSelectionChange">
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <el-table-column
        label="会员名称"
        width="120">
        <template slot-scope="scope">{{ scope.row.date }}</template>
      </el-table-column>
      <el-table-column
        prop="name"
        label="联系手机"
        width="120">
      </el-table-column>
      <el-table-column
        prop="address"
        label="会员等级"
        show-overflow-tooltip>
      </el-table-column>
	  <el-table-column
	    prop="address"
	    label="会员标签"
	    show-overflow-tooltip>
	  </el-table-column>
    </el-table>
		</div>
  <div style="padding-left:72%;height: 32px;"><!-- 分页点击栏靠右边 -->
  		<span>1/6页,45条结果</span>
  		<el-input-number size="mini" v-model="num" controls-position="right" @change="handleChange" :min="1" style="width:80px;"></el-input-number>
  		<span class="menu-icon"><i class="el-icon-arrow-left" /></span>
  		<span class="menu-icon"><i class="el-icon-arrow-right" /></span>
  		<el-button size="mini">指定跳转</el-button>
  </div>

	<hr />
   <span slot="footer" class="dialog-footer">
	 <el-button @click="grant = false">取 消</el-button>
	 <el-button type="primary" @click="grant = false">确 定</el-button>
   </span>
</el-dialog>
<!-- 这是主页部分 -->
			</div>
				<div>
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				  <el-form-item label="全部" style="margin-top: 20px;">
					 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
					    <el-option
					      v-for="item in options"
					      :key="item.value"
					      :label="item.label"
					      :value="item.value">
					    </el-option>
					  </el-select>
				  </el-form-item>
				  <el-form-item label="优惠卷名称" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item>
					<el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>		
				  </el-form-item>
				</el-form>
				</div>
				 <el-button type="primary" @click="add()">新增</el-button>
					<div style="margin-top:15px;">
						<el-table
						    :data="tableData"
						    stripe
						    style="width: 100%">
						    <el-table-column
							   prop="name"
							  align="center" 
						      label="优惠卷名称"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center" 
						      prop="name"
						      label="面值/折扣"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center" 
						      prop="address"
						      label="使用条件">
						    </el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="可用数量">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="已领取">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="已使用">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="有效期">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="领取方式">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="状态">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="操作">
							 <template slot-scope="scope">
							 	        <el-button @click="handleClick(scope.row)" type="text" size="small">领取记录</el-button>
							 	        <el-button type="text" size="small"  @click="grant=true">手动发放</el-button>
										 <el-button type="text" size="small" @click="edit()">编辑</el-button>
							 	      </template>
							 	    </el-table-column>
						  </el-table>
					</div>
				<div class="paging">
			  <div style="padding-left:80%;align-items: center;padding-top:9px;" class="flex">
				<span>1/6页,45条结果</span>
				&emsp;
				<el-input-number size="mini" v-model="num" controls-position="right" @change="handleChange" :min="1" style="width:80px;"></el-input-number>
				&emsp;&emsp;
				<span class="menu-icon"><i class="el-icon-arrow-left" /></span>
				&emsp;
				<span class="menu-icon"><i class="el-icon-arrow-right" /></span>
				&emsp;
				<el-button size="mini">指定跳转</el-button>
			</div>
		</div>

		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
export default {
  name: 'first',
  components: {},
   data() {
        return {
			 activeName: 'first',
			 Selection_quantity:'',//存储弹层的选择数量
			 grant:false,
			  num: 1,
			   formInline: {
			            user: '',
			            region: ''
			          },
          tableData: [{
            date: '2016-05-02',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1518 弄'
          }, {
            date: '2016-05-04',
            name: '王小虎',
            address: '上海市普路 1517 弄'
          }, {
            date: '2016-05-01',
            name: '王小虎',
            address: '上海市江路 1519 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀 1516 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市江路'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市江路'
          },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海沙江 弄'
		  }],
		      options: [{
		            value: '选项1',
		            label: '黄金糕'
		          }, {
		            value: '选项2',
		            label: '双皮奶'
		          }, {
		            value: '选项3',
		            label: '蚵仔煎'
		          }, {
		            value: '选项4',
		            label: '龙须面'
		          }, {
		            value: '选项5',
		            label: '北京烤鸭'
		          }],
		          value: ''
		        }
      },
	   methods: {
				  add(){/* 新增 */
					  this.$router.push({path:'/market/Discount/New_discount',query: {id:1}})
				  },
				edit(){
					 /* 编辑 */
					 this.$router.push({path:'/market/Discount/Edit_Coupon',query: {id:1}})
				 }

	      }
};
</script>
<style scoped>
	.text{
	    display: flex;
		align-items: center;
	    left: 20px;
	    position: relative;
	    top: 15px;
	  }
	.search {
	  height: 75px;
	  background-color: #F5F5F5;
	  position: relative;
	  top: 16px;
	}
	.search-frame {
	  width: 100%;
	  height: 100px;
	  margin: auto;
	  background-color: #ffffff;
	}
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px; 
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
