<template>
  <div class="Service-page" style="margin: 20px;">
	  <el-tabs v-model="activeName" @tab-click="handleClick">
			<el-tab-pane label="新增优惠卷" name="first">
						<div style="width:30%;">
						   <el-form ref="form" :model="form" label-width="110px">
						     <el-form-item label="优惠卷名称" required>
						       <el-input v-model="form.name" style="width:220px;"></el-input>
						     </el-form-item>
							 
							 <el-form-item label="优惠类型" required>
							   <el-radio-group v-model="form.resource">
							     <el-radio label="固定面值卷"></el-radio>
							     <el-radio label="打折卷"></el-radio>
							   </el-radio-group>
							 </el-form-item>
							 
							 <el-form-item label="面值" required>
							   <el-input v-model="form.name" style="width:220px;"></el-input>
							 </el-form-item>
							 
							 <el-form-item label="可用数量" required>
							   <el-input v-model="form.name" style="width:220px;"></el-input>
							 </el-form-item>
							 
							 <el-form-item label="有效时间" required>
							   <el-radio-group v-model="form.resource">
							     <el-radio label="指定日期过期"></el-radio>
							     <el-radio label="发放后指定天数过期"></el-radio>
							   </el-radio-group>
							 </el-form-item>
							 
						     <el-form-item label="生效时间：">
						        <el-date-picker
						            v-model="value1"
						            type="datetime"
						            placeholder="选择日期时间">
						          </el-date-picker>
						     </el-form-item>
							 
							 
							 <el-form-item label="过期时间:">
							    <el-date-picker
							        v-model="value1"
							        type="datetime"
							        placeholder="选择日期时间">
							      </el-date-picker>
							 </el-form-item>
							 
							  <el-form-item label="优惠卷描述">
							    <el-input type="textarea" v-model="form.desc"></el-input>
							  </el-form-item>
							  
							  <el-form-item label="有效时间:满" required>
							    <el-input v-model="form.name" style="width:220px;"></el-input>可用
							  </el-form-item>
							  
							  <el-form-item label="可使用商品">
							    <el-radio-group v-model="form.resource">
							      <el-radio label="商城所有商品"></el-radio>
							      <el-radio label="指定商品"></el-radio>
								    <el-radio label="指定不可用商品"></el-radio>
							    </el-radio-group>
							  </el-form-item>
							  
							  <el-form-item label="优惠卷类型" required>
							    <el-radio-group v-model="form.resource">
							      <el-radio label="系统发放"></el-radio>
							      <el-radio label="主动领取"></el-radio>				    
							    </el-radio-group>
							  </el-form-item>
							  
						   </el-form>
						  <div style="margin-left:35px;padding-bottom: 25px;">
							  <el-button type="primary">保存</el-button>
							  <el-button @click="Return()">返回</el-button>
						  </div>
						   		</div>
								 
			</el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
export default {
  name: 'first',
  components: {},
   data() {
        return {
			New_activities:false,
			 activeName: 'first',
			 switchs:'',
			  num: 1,
			   formInline: {
			            user: '',
			            region: ''
			          },
       
		  form: {
		            name: '',
		            region: '',
		            date1: '',
		            date2: '',
		            delivery: false,
		            type: [],
		            resource: '',
		            desc: ''
		          },
				      pickerOptions: {
				            shortcuts: [{
				              text: '今天',
				              onClick(picker) {
				                picker.$emit('pick', new Date());
				              }
				            }, {
				              text: '昨天',
				              onClick(picker) {
				                const date = new Date();
				                date.setTime(date.getTime() - 3600 * 1000 * 24);
				                picker.$emit('pick', date);
				              }
				            }, {
				              text: '一周前',
				              onClick(picker) {
				                const date = new Date();
				                date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
				                picker.$emit('pick', date);
				              }
				            }]
				          },
		        }
      },
	   methods: {
		   Return(){/* 返回界面 */
			    this.$router.push({path:'/market/Discount',query: {id:1}})
		   }
	      }
};
</script>
<style scoped>
</style>
