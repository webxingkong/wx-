<template>
	<div class="select">
		<el-carousel :interval="3000" arrow="always" class="top"><el-carousel-item v-for="item in 2" :key="item"></el-carousel-item></el-carousel>
		<br />
		<br />
		<el-row>
			<el-col :span="8">
				<el-row>
					<el-col :span="6">
						<div class="grid-content flex_m "><img src="../../assets/APPA.png" width="100px" /></div>
					</el-col>
					<el-col :span="12">
						<div class="grid-content">
							<h3>供应商后台</h3>

							允许供应商进入后台，查看采购单详情， 进行分拣操作
							<br />
							<br />
							<el-button size="small" type="primary">进入</el-button>
						</div>
					</el-col>
				</el-row>
			</el-col>
			<el-col :span="8">
				<el-row>
					<el-col :span="6">
						<div class="grid-content flex_m"><img src="../../assets/APPB.png" width="100px" /></div>
					</el-col>
					&emsp;
					<el-col :span="12">
						<div class="grid-content">
							<h3>活动表单</h3>

							允许自定义表单，在商城展示，用于收集 信息，填表入驻等操作
							<br />
							<br />
							<el-button size="small" type="primary">进入</el-button>
						</div>
					</el-col>
				</el-row>
			</el-col>
			<el-col :span="8">
				<el-row>
					<el-col :span="6">
						<div class="grid-content flex_c_m"><img src="../../assets/APPC.png" width="86px" /></div>
					</el-col>
					<el-col :span="12">
						<div class="grid-content">
							<h3>司机配送APP</h3>
							支持司机登录，结合线路自动分配配送单， 实时更新货品状态
							<br />
							<br />
							<el-button size="small" type="primary">进入</el-button>
						</div>
					</el-col>
				</el-row>
			</el-col>
		</el-row>
		<br />
		<br />
		<br />
		<br />
		<div class="select-table flex_c_m">更多应用，敬请期待！</div>
	</div>
</template>

<style scoped>
.el-carousel__item h3 {
	color: #475669;
	font-size: 18px;
	opacity: 0.75;
	line-height: 300px;
	margin: 0;
}

.el-carousel__item:nth-child(2n) {
	background: url(https://fuss10.elemecdn.com/a/3f/3302e58f9a181d2509f3dc0fa68b0jpeg.jpeg) /* no-repeat */;
}

.el-carousel__item:nth-child(2n + 1) {
	background: url(https://fuss10.elemecdn.com/2/11/6535bcfb26e4c79b48ddde44f4b6fjpeg.jpeg) /* no-repeat */;
}
.top {
	margin-top: 30px;
}
.select-table {
	height: 30px;
	width: 98%;
	background-color: #f5f5f5;
	border: solid 1px #cccccc;
	font-size: 8px;
}
.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select {
	margin: auto;
	width: 96%;
	background-color: #ffffff;
}
.grid-content {
	height: 150px;
}
</style>
