<template>
	<div class="select Archives-page">
		<div class="select-table">
			<el-tabs v-model="activeName">
				<!--仓库设置-->
				<el-tab-pane label="仓库设置" name="first"><br />
					<br />

					<div class="right"><el-button size="medium">属地仓库管理</el-button></div>

					<el-table ref="multipleTable" :data="info" tooltip-effect="dark" style="width: 100%">
						<el-table-column prop="company_id" label="序号"></el-table-column>
						<el-table-column prop="warehouse" label="仓库名称"></el-table-column>
						<el-table-column prop="warehouse_number" label="仓库编码"></el-table-column>
						<el-table-column prop="explain" label="说明" show-overflow-tooltip></el-table-column>
						<el-table-column label="操作">
							<template slot-scope="scope">
								<el-button type="text" @click="Warehouserowedit(scope.row)">编辑</el-button>
								<!-- <el-button type="text" @click="open">删除</el-button> -->
							</template>
						</el-table-column>
					</el-table>
				</el-tab-pane>
				<!--库区设置-->
				<el-tab-pane label="库区设置" name="second">

						<el-form :inline="true" :model="formInline">
							  <el-select v-model="value" placeholder="请选择" size="small" style="margin-top: 5px;">
							    <el-option
							      v-for="item in options"
							      :key="item.value"
							      :label="item.label"
							      :value="item.value">
							    </el-option>
							  </el-select>
							&emsp;
							<el-form-item><el-button size="small" type="primary" @click="onSubmit">搜索</el-button></el-form-item>
						</el-form>



					<el-button size="small" type="primary" @click="add">新增</el-button>
					<br />
					<br />
					<el-table ref="multipleTable" :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)" tooltip-effect="dark" style="width: 100%">
						<el-table-column width="55"></el-table-column>
						<el-table-column prop="warehouse_id" label="序号"></el-table-column>
						<el-table-column prop="warehouse_code" label="库区编码"></el-table-column>
						<el-table-column prop="warehouse_name" label="库区名称"></el-table-column>
						<el-table-column prop="explain" label="说明"></el-table-column>
						<el-table-column fixed="right" label="操作">
							<template slot-scope="scope">
								<el-button type="text" size="small" @click="editrow(scope.row)">编辑</el-button>
								<el-button type="text" size="small" @click="deleterow(scope.$index, tableData)">删除</el-button>
							</template>
						</el-table-column>
					</el-table>
					<!--分页-->
					 <el-pagination class="block"
					     background
					     @size-change="handleSizeChange"
					     @current-change="handleCurrentChange"
					     :current-page="currentPage"
					     :page-sizes="[5, 10, 20, 50]"
					     :page-size="pagesize"
					     layout="total, sizes, prev, pager, next, jumper"
					     :total="total">
					   </el-pagination>
				</el-tab-pane>
			</el-tabs>
		</div>
		<!-- 仓库编辑 -->
		<el-dialog title="编辑" :visible.sync="Warehouseeditform" width="550px">
			<el-form :model="Warehouseinfo">
				<el-form-item label="仓库名称:" :label-width="formLabelWidth">
					<el-input placeholder="南宁农贸市场" v-model="Warehouseinfo.warehouse" autocomplete="off"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="Warehouseeditform = false">取 消</el-button>
				<el-button type="primary" @click="Warehouseroweditsave">确 定</el-button>
			</div>
		</el-dialog>
		<!--库区设置新增-->
		<el-dialog title="新增库区" :visible.sync="addform" width="550px">
			<el-form :model="addformrow">
				<el-form-item label="仓库名称" :label-width="formLabelWidth">
					<!-- <el-select v-model="form.region">
						<el-option label="北海农贸市场" value="copper"></el-option>
						<el-option label="南宁农贸市场" value="silver"></el-option>
						<el-option label="农贸市场" value="silve"></el-option>
						<el-option label="广西农贸市场" value="silv"></el-option>
					</el-select> -->
					<el-select v-model="addvalue" placeholder="请选择" style="width:300px">
				    <el-option
				      v-for="item in addoptions"
				      :key="item.value"
				      :label="item.label"
				      :value="item.value">
				    </el-option>
  			</el-select>
					&emsp;&emsp;
				</el-form-item>
				<el-form-item label="库区名称:" :label-width="formLabelWidth"><el-input v-model="addformrow.warehouse_name" style="width:300px" autocomplete="off"></el-input></el-form-item>
				<el-form-item label="库区编码:" :label-width="formLabelWidth"><el-input v-model="addformrow.warehouse_code" style="width:300px" autocomplete="off"></el-input></el-form-item>
				<el-form-item label="说明" :label-width="formLabelWidth">
					<el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4 }" placeholder="请输入内容" style="width:300px" v-model="addformrow.explain"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="addform = false">取 消</el-button>
				<el-button type="primary" @click="addsave">确 定</el-button>
			</div>
		</el-dialog>
		<!--库区设置编辑-->
		<el-dialog title="编辑库区" :visible.sync="editlayout" width="36%">
			<el-form :model="editforms">
				<el-form-item label="仓库名称:" :label-width="formLabelWidth">
					<el-input placeholder="南宁农贸市场" :disabled="true" v-model="editforms.warehouse_id" autocomplete="off"></el-input>
				</el-form-item>

				<el-form-item label="库区名称:" :label-width="formLabelWidth">
					<el-input placeholder="南宁西区" v-model="editforms.warehouse_name" autocomplete="off"></el-input>
				</el-form-item>

				<el-form-item label="库区编码:" :label-width="formLabelWidth"><el-input placeholder="编码" v-model="editforms.warehouse_code" autocomplete="off"></el-input></el-form-item>
				<el-form-item label="说明" :label-width="formLabelWidth">
					<el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4 }" placeholder="请输入内容" v-model="editforms.explain"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="editlayout = false">取 消</el-button>
				<el-button type="primary" @click="editsave">确 定</el-button>
			</div>
		</el-dialog>
	</div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			Warehouseeditform:false,//仓库编辑
			editlayout:false,
			addform: false, //编辑
			editform:false,
			addformrow:{
				warehouse_id: 1,  //仓库表id
    		warehouse_name: "柳州仓库1",//库区名
    		warehouse_code: "001",//库区编码
    		explain: "说明"
			},
			Warehouseinfo:{
				warehouse:'',
				wno:''//仓库编辑数据
			},
			addoptions: [
				{
					value: '选项1',
					label: '南宁农贸市场'
				},
				{
					value: '选项2',
					label: '北海农贸市场'
				},
				{
					value: '选项3',
					label: '北京农贸市场'
				},
			],
			addvalue:'',
			total: 0,
			info:[],
			currentPage: 1,
			pagesize: 5,
			editforms: {
				id: 1,
    		warehouse_id: 1,  //仓库表id
    		warehouse_name: "柳州仓库1",//库区名
    		warehouse_code: "001",//库区编码
    		explain: "说明"
			},
			dialogFormVisible: false, //新增
			form: {
				name: '',
				region: '',
				branch: '',
				DistrictName: '',
				area: ''
			},

			formLabelWidth: '80px',
			activeName: 'first',
			tableData: [],
			formInline: {
				user: '',
				region: '',
				Name: '',
				times: '',
				Mobilephone: '',
				Names: ''
			},
			options: [
				{
					value: '选项1',
					label: '南宁农贸市场'
				},
				{
					value: '选项2',
					label: '北海农贸市场'
				},
				{
					value: '选项3',
					label: '北京农贸市场'
				},
			],
			value: ''

			//
		};
	},
	created() {
			this.getData();
	},
	methods: {
		onSubmit() {
			console.log('submit!');
		},
		deleterow(index, rows) {
			console.log(rows);
			for (var i = 0; i < rows.length; i++) {
				var id=rows[i].id;
			}
        // rows.splice(index, 1);
				axios({
	        url: Rootpath.BASE_URL + 'delWarehouseRegion',
	        method: 'post',
	        data: {
	            id:id
	        },
	        headers: {
	            'Content-Type': 'application/x-www-form-urlencoded'
	        }
	    })
	    .then(respanse => {
	        rows.splice(index, 1	);
	    })
			.catch(function (error) {
	            console.log(error);
	        });
    },
		add(){
			this.addform=true;
			this.addformrow.warehouse_id='',
			this.addformrow.warehouse_name='',
			this.addformrow.warehouse_code='',
			this.addformrow.explain=''
		},
		addsave(){
			axios({
        url: Rootpath.BASE_URL + 'addWarehouseRegion',
        method: 'post',
        data: {
					warehouse_id:this.addvalue,  //仓库表id
					warehouse_name:this.addformrow.warehouse_name,//库区名
					warehouse_code:this.addformrow.warehouse_code,//库区编码
					explain:this.addformrow.explain
        },
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    })
    .then(respanse => {
        // console.log(respanse.data);
				this.addform=false;
    })
		.catch(function (error) {
            console.log(error);
        });
		},
		editrow(row){
			console.log(row);
			this.editlayout=true;
			this.editforms.id=row.id;
			this.editforms.warehouse_id=row.warehouse_id;  //仓库表id
			this.editforms.warehouse_name=row.warehouse_name;//库区名
			this.editforms.warehouse_code=row.warehouse_code;//库区编码
			this.editforms.explain=row.explain
		},
		//编辑保存
		editsave(){
			axios({
        url: Rootpath.BASE_URL + 'editWarehouseRegion',
        method: 'post',
        data: {
            id: this.editforms.id,
						warehouse_id:this.editforms.iwarehouse_idd,
						warehouse_name: this.editforms.warehouse_name,//库区名
    				warehouse_code: this.editforms.warehouse_code,//库区编码
    				explain: this.editforms.explain
        },
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    })
    .then(respanse => {
        // console.log(respanse.data);
				this.editlayout=false;
    })
		.catch(function (error) {
            console.log(error);
        });
		},
		//打开仓库编辑
		Warehouserowedit(row){
			this.Warehouseeditform=true;
			this.Warehouseinfo.warehouse=row.warehouse;
			this.Warehouseinfo.wno=row.warehouse_number;
		},
		//仓库编辑保存
		Warehouseroweditsave(){
			axios({
        url: Rootpath.BASE_URL + 'editWarehouse',
        method: 'post',
        data: {
            warehouse: this.Warehouseinfo.warehouse,
						wno:this.Warehouseinfo.wno
        },
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    })
    .then(respanse => {
        // console.log(respanse.data);
				this.Warehouseeditform=false;
    })
		.catch(function (error) {
            console.log(error);
        });
	},
		// 获取数据
		async getData() {
				const result = await axios.get(Rootpath.BASE_URL + 'warehousePage');
				console.log(result);
				this.info=result.data.info;
				this.tableData=result.data.info[0].warehouse_region;
				this.total = this.tableData.length;
				// console.log(this.tableData);
		},
		open() {
			this.$confirm('您是否确认需要删除该条数据吗？', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			})
				.then(() => {
					this.$message({
						type: 'success',
						message: '删除成功!'
					});
				})
				.catch(() => {
					this.$message({
						type: 'info',
						message: '已取消删除'
					});
				});
		}, //新增弹框
		psks() {
			console.log(0);
		},
		//分页
		handleSizeChange(size) {
		  this.pagesize = size
		},
		handleCurrentChange(currentPage) {
		  this.currentPage = currentPage
		},
	}
};
</script>

<style scoped>
.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select {
	margin: auto;
	width: 96%;
	background-color: #ffffff;
}


.right {
		text-align: right;
		margin-top: -30px;
	}
	.block{
		text-align: right;
	}
</style>
