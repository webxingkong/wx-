<template>
	<div class="select supplyincrease-page">
		<div class="select-table">
			<el-tabs v-model="activeName" @tab-click="handleClick"><el-tab-pane label="新增供应商" name="first"></el-tab-pane></el-tabs>
			<h4>基本信息</h4>
			<div class="  ">
				<el-form :inline="true" :model="info"  label-width="100px" class="fromclass">
					<el-form-item	 label="名称:"><el-input size="small" v-model="info.purchaser_name" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="联系人:"><el-input size="small" v-model="info.contacts" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="联系手机:"><el-input size="small" v-model="info.mobile_phone" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="详细地址:"><el-input size="small" v-model="info.address" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="登录账号:"><el-input size="small" v-model="info.login_account" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="密码:"><el-input size="small" v-model="info.pwd" class="long"></el-input></el-form-item>
					<h4>财务信息</h4>
					<el-form-item label="开户名称:"><el-input size="small" v-model="info.Accountname" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="开户银行:"><el-input size="small" v-model="info.household" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="银行账户:"><el-input size="small" v-model="info.accounts" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="发票抬头:"><el-input size="small" v-model="info.invoice" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="税号:"><el-input size="small" v-model="info.tax" class="long"></el-input></el-form-item>
					<h4>资质信息</h4>
					<p style="color: #999999;">图片上传最多可五张，每张不超过1M</p>

					<div class="  ">
						<el-upload action="https://jsonplaceholder.typicode.com/posts/" list-type="picture-card" :on-preview="handlePictureCardPreview" :on-remove="handleRemove">
							<i class="el-icon-plus"></i>
						</el-upload>
						<el-dialog :visible.sync="dialogVisible"><img width="100%" :src="dialogImageUrl" alt="" /></el-dialog>
					</div>
					<br><br>
					<el-button size="small" type="primary" @click="leaveladd">保存</el-button>
					<el-button size="small" @click="back">取消</el-button>
				</el-form>
			</div>
		</div>
	<br></div>

</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			dialogImageUrl: '',
			dialogVisible: false,
			activeName: 'first',
			info: {
    		company_id: null,
    		purchaseman_name: "",
	    	purchaser_name: "",
    		contacts: "",
  			mobile_phone: "",
    		contacts_phone: "",
    		address: "",
    		login_account: "",
    		pwd: "",
    		msg_info: "url",
				Accountname:'',
				household:'',
				accounts:'',
				invoice:'',
				tax:''
  		}
		};
	},
	methods: {
		handleClick(tab, event) {
			console.log(tab, event);
		},
		handleRemove(file, fileList) {
			 console.log(file, fileList);
		 },
		 handlePictureCardPreview(file) {
			 this.dialogImageUrl = file.url;
			 this.dialogVisible = true;
		 },
		 back(){
			 this.$router.push({path:'/profile/Supplier'});
		 },
		 async leaveladd(index) {
    	let that = this;
    // that.clickrow.id='';
    // that.form.types='';
    // that.form.roce='';
    // that.form.remarks='';
	    axios.post(Rootpath.BASE_URL + 'addSupplierInfo', {
						company_id: 1,
						purchaseman_name: "no111",
						purchaser_name: that.info.purchaser_name,
						contacts: that.info.contacts,
						mobile_phone: that.info.mobile_phone,
						contacts_phone: that.info.contacts_phone,
						address: that.info.address,
						login_account: that.info.login_account,
						pwd: that.info.pwd,
						msg_info: "url",
	                // data:that.form
	      })
	        .then(function (response) {
	            that.back();
	        })
	        .catch(function (error) {
	            console.log(error);
	        });
			},
	}
};
</script>
<style scoped>
.long {
	width: 300px;
}
.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
</style>
