<template>
	<div class="select supplydetails-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="供应商详情" name="first"></el-tab-pane></el-tabs>
			<h4>基本信息</h4>
			<div class="">
				<el-form :inline="true"  label-width="100px" :model="deliveryNoteInfo">
					<el-form-item label="名称:"><el-input size="small" v-model="deliveryNoteInfo.purchaser_name" :disabled="true" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="联系人:"><el-input size="small" v-model="deliveryNoteInfo.contacts" :disabled="true" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="联系手机:"><el-input size="small" v-model="deliveryNoteInfo.mobile_phone" :disabled="true" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="详细地址:"><el-input size="small" v-model="deliveryNoteInfo.address" :disabled="true" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="登录账号:"><el-input size="small" v-model="deliveryNoteInfo.login_account" :disabled="true" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="密码:"><el-input size="small" v-model="deliveryNoteInfo.pwd" :disabled="true" class="long"></el-input></el-form-item>
					<h4>财务信息</h4>
					<el-form-item label="开户名称:"><el-input size="small" v-model="deliveryNoteInfo.Accountname" :disabled="true" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="开户银行:"><el-input size="small" v-model="deliveryNoteInfo.household" :disabled="true" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="银行账户:"><el-input size="small" v-model="deliveryNoteInfo.accounts" :disabled="true" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="发票抬头:"><el-input size="small" v-model="deliveryNoteInfo.invoice" :disabled="true" class="long"></el-input></el-form-item>
					<br />
					<el-form-item label="税号:"><el-input size="small" v-model="deliveryNoteInfo.tax" :disabled="true" class="long"></el-input></el-form-item>
				</el-form>
			</div>
			<el-button size="small" type="primary" @click="returnback">返回</el-button>

		</div>
	<br><br></div>

</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			dialogImageUrl: '',
			dialogVisible: false,
			activeName: 'first',
			deliveryNoteInfo: {
				id: 1,
    		company_id: 1,
    		purchaser_number: "no111",
    		purchaser_name: "公司2222",
    		contacts: "联系人",
    		mobile_phone: "13633333333",
    		contacts_phone: "07715555555",
    		address: "地址",
    		login_account: "登录账号",
    		pwd: "123456",
    		msg_info: null,
				Accountname:'',
				household:'',
				accounts:'',
				invoice:'' ,
				tax:''
			}
		};
	},
	created() {
			this.getData();
	},
	methods: {
		// 获取数据
			async getData() {
			    var purchaser_number = this.$route.query.pn
			    const result = await axios.get(Rootpath.BASE_URL + 'supplierInfo?pn=' + purchaser_number);
			    this.deliveryNoteInfo = result.data.deliveryNoteInfo
			    console.log(result.data.deliveryNoteInfo);
			},
			returnback(){
				this.$router.push({path:'/profile/Supplier'});
			}
	}
};
</script>
<style scoped>
.Centered {
	width: 39%;
	height: 100%;

	text-align: right;
}
.long {
	width: 300px;
}
.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
</style>
