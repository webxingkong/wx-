<template>
    <div class="select Supplier-page">
        <div class="select-table">
            <el-tabs v-model="activeName">
                <el-tab-pane label="供应商" name="first"></el-tab-pane>
            </el-tabs>

            <div class="search">
                <!---->
                <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
                    <el-form-item label="供应商" style="margin-top: 20px;">
                        <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                    </el-form-item>
                    <el-form-item label="联系人" style="margin-top: 20px;">
                        <el-input size="small" v-model="formInline.region" style="width: 120px;"></el-input>
                    </el-form-item>
                    <el-form-item label="采购类型" style="margin-top: 20px;">
                        <el-input size="small" v-model="formInline.states" style="width: 120px;"></el-input>
                    </el-form-item>
                    &emsp;

                    <el-form-item>
                        <el-button size="small" type="primary" style="margin-top: 23px;">搜索</el-button>
                    </el-form-item>
                </el-form>
                <!---->
            </div>
            <br />
            <br />
            <el-button @click="supplyincrease()" size="small" type="primary">新增供应商</el-button>
            <div class="right">
                <el-button size="medium">导出查询结果</el-button>
            </div>

            <br />
            <el-table ref="multipleTable" :data="info.slice((currentPage-1)*pagesize,currentPage*pagesize)" tooltip-effect="dark" style="width: 100%">
                <el-table-column align="center" label="供应商">
                    <template slot-scope="scope">
                        {{ scope.row.purchaser_name }}
                    </template>
                </el-table-column>
                <el-table-column align="center" prop="contacts" label="联系人"></el-table-column>
                <el-table-column align="center" prop="mobile_phone" label="联系方式"></el-table-column>
                <el-table-column align="center" prop="address" label="地址"></el-table-column>
                <el-table-column align="center" label="操作">
                    <template slot-scope="scope">
                        <el-button @click="dialogVi(scope.row)" type="text" size="small">详情</el-button>
                        <el-button @click="supplyedit(scope.row)" type="text" size="small">编辑</el-button>
                        <el-button type="text" size="small">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
						<!--分页-->
						<el-pagination class="pagination"
								background
								@size-change="handleSizeChange"
								@current-change="handleCurrentChange"
								:current-page="currentPage"
								:page-sizes="[5, 10, 20, 50]"
								:page-size="pagesize"
								layout="total, sizes, prev, pager, next, jumper"
								:total="total">
							</el-pagination>
        </div>
    </div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
    export default {
        data() {
					return {
							activeName: 'first',
							total: 0,
						 	currentPage: 1,
						 	pagesize: 5,
							info: [],
							formInline: {
									user: '',
									region: '',
									states: '',
									times: ''
							}
					};
        },
				created() {
						this.getData();
				},
				methods: {
					// 获取数据
					async getData() {
						const result = await axios.get(Rootpath.BASE_URL + 'supplierList?purchaser_name='+'供应商&mobile_phone='+'1333');
						console.log(result);
						this.info = result.data.info;
						this.total = result.data.info.length;
					},
					toggleSelection(rows) {
							if (rows) {
									rows.forEach(row => {
											this.$refs.multipleTable.toggleRowSelection(row);
									});
							} else {
									this.$refs.multipleTable.clearSelection();
							}
					},
					handleSelectionChange(val) {
							this.multipleSelection = val;
					},
					//详情
					dialogVi(row) { 
            //详情商品跳转函数
            this.$router.push({path:'/profile/Supplier/Supplydetails',query: {
             pn: row.purchaser_number,
           }});
					},
					//编辑
					supplyedit(row) { 
							this.$router.push({
									path: '/profile/Supplier/Supplyedit'
							})
					},
					//新增
					supplyincrease(supplyincrease) { 
							this.$router.push({
									path: '/profile/Supplier/Supplyincrease',
									query: {
											id: supplyincrease
									}
							})
					},
					//分页
					handleSizeChange(size) {
							this.pagesize = size
					},
					handleCurrentChange(currentPage) {
							this.currentPage = currentPage
					},
				}
    };
</script>

<style scoped>
    .block {
        text-align: right;
    }
    .footer {
        height: 44px;
        text-align: right;
    }
    .right {
        text-align: right;
    }
    p {
        position: relative;
        top: -12px;
    }
    .text {
        display: flex;
        left: 20px;
        position: relative;
        top: 15px;
    }
    h3 {
        color: #436be5;
        border-bottom: solid 2px #436be5;
        margin-left: 20px;
    }
    .text-frame-member {
        width: 100px;
        position: relative;
        top: 10px;
    }
    .text-frame {
        height: 50px;
        width: 100%;
        background-color: #ffffff;
        border-bottom: solid 1px #f0f2f0;
    }
    .select-table {
        margin: auto;
        width: 96%;
        margin-top: 20px;
    }
    .select {
        margin: auto;
        width: 96%;
        background-color: #ffffff;
    }
    /*border: solid 1rpx #007AFF;
*/
    .search {
        height: 70px;
        background-color: #f5f5f5;
    }
    .search-Button {
        margin-left: 20px;
    }
</style>
