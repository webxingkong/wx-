<template>
  <div class="Summary-page" style="margin: 20px;">
	  <el-tabs v-model="activeName">
	     <el-tab-pane label="配送总汇" name="first">
				   <div><!-- 搜索框 -->
					   <div style="color: #808080;">
					   <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
					     <el-form-item label="采购分类" style="margin-top: 20px;">
					   	<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
					     </el-form-item>
						配送路线
					    <el-select v-model="options.label" placeholder="请选择" style="margin:20px 25px 0px 0px; width:120px;">
					        <el-option
					          v-for="item in options"
					          :value="item.label">
					        </el-option>
					      </el-select>

						  <el-checkbox size="medium">代采购商品</el-checkbox>
						  <el-checkbox size="medium" >计算库存</el-checkbox>
					     <el-form-item>
					   	<el-button  size="small" type="primary" style="margin-top: 23px;margin-left: 15px;">搜索</el-button>
					     </el-form-item>
					   </el-form>

					   </div>
				   </div>
				   <el-button type="primary" @click="dialogVisible = true" style="margin-top: 26px;">生成采购单</el-button>
				   <div class="right">
				   <el-button size="medium">导出查询结果</el-button>
				   </div>
				 <!--  采购单弹层区域 -->
			   <div>
			<el-dialog
			  title="提示"
			  :visible.sync="dialogVisible"
			  width="25%"
			  :before-close="handleClose">
			  <hr />
			  <p>请确定是否转为采购单？</p>
			  <p>共17条记录，按采购单类型拆分为<font style="color: red;">{{Purchasenumer}}</font>条采购单</p>
			    <p>确定后,请相关人员尽快处理采购单</p>
			  <hr />
			  <span slot="footer" class="dialog-footer">
			    <el-button @click="dialogVisible = false">取 消</el-button>
			    <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
			  </span>
			</el-dialog>
			   </div>
					<div>
						 <el-table
						    ref="multipleTable"
						    :data="deliverySummary.slice((currentPage-1)*pagesize,currentPage*pagesize)"
						    tooltip-effect="dark"
						    style="width: 100%"
						    @selection-change="handleSelectionChange">
						    <el-table-column
						      type="selection">
						    </el-table-column>
						    <el-table-column
							align="center"
						      label="商品"
							   prop="goods_name">
						    </el-table-column>
						    <el-table-column
								align="center"
						      prop="unit"
						      label="单位">
						    </el-table-column>
						    <!-- <el-table-column
								align="center"
						      prop="address"
						      label="客户编码"
						      show-overflow-tooltip>
						    </el-table-column> -->
							<el-table-column
                v-for="item in deliverySummary.deliveryInfo"
							  prop="item.type"
							  label="采购类型"
							  show-overflow-tooltip>
							</el-table-column>
							<el-table-column
							  prop="purchaser_name"
							  label="采购员/供应商"
							  show-overflow-tooltip>
							</el-table-column>
							<el-table-column
							  prop="product_number"
							  label="配送单数"
							  show-overflow-tooltip>
							</el-table-column>
              <el-table-column
              v-for="item in deliverySummary.deliveryInfo"
							  prop="item.order_count"
							  label="订单汇总"
							  show-overflow-tooltip>
							</el-table-column>
              <el-table-column
							  prop="stock"
							  label="库存量"
							  show-overflow-tooltip>
							</el-table-column>
              <el-table-column
							  prop="stock_quantity"
							  label="在途库存量"
							  show-overflow-tooltip>
							</el-table-column>
              <el-table-column
              v-for="item in deliverySummary.deliveryInfo"
							  prop="item.purchaser_number"
							  label="待采购量"
							  show-overflow-tooltip>
							</el-table-column>
						  </el-table>
              <!--分页-->
              <el-pagination class="pagination"
                  background
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                  :current-page="currentPage"
                  :page-sizes="[5, 10, 20, 50]"
                  :page-size="pagesize"
                  layout="total, sizes, prev, pager, next, jumper"
                  :total="total">
                </el-pagination>
					</div>

		 </el-tab-pane>

	   </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import Rootpath from "../../../api/index.js"
export default {
  name: 'first',
  components: {},
   data() {
        return {
          total: 0,
          currentPage: 1,
          pagesize: 5,
			   options: [{
			          value: '选项1',
			          label: '小雪'
			        }, {
			          value: '选项2',
			          label: '小雪'
			        }, {
			          value: '选项3',
			          label: '小雪'
			        }, {
			          value: '选项4',
			          label: '小雪'
			        }, {
			          value: '选项5',
			          label: '小雪'
			        }],
			dialogVisible: false,
			Purchasenumer:'',
			 activeName: 'first',
			 formInline: {
			          user: '',
			          region: ''
			        },
			  num: 1,
          deliverySummary: [],
        }
      },
      created() {
        this.getData();
      },
	   methods: {/* 接受选中的采购单进行数量结算 */
	        handleSelectionChange(value) {
				console.log(value.length)
	  this.Purchasenumer=value.length;
	        },
          handleSizeChange(size) {
            this.pagesize = size
          },
          handleCurrentChange(currentPage) {
            this.currentPage = currentPage
          },
			increase(){
				console.log("999999999")
			},
      // 获取数据
        async getData() {
                const result = await axios.get(Rootpath.BASE_URL + 'deliverySummary?delivery_time=2019-10-30&type=1');
                console.log(result);
                this.deliverySummary = result.data.deliverySummary
                this.total = result.data.deliverySummary.length
            },

			handleClose(done) {
			        this.$confirm('确认关闭？')
			          .then(_ => {
			            done();
			          })
			          .catch(_ => {});
			      }

	      }
};
</script>
<style scoped>
	.text{
	    display: flex;
		align-items: center;
	    left: 20px;
	    position: relative;
	    top: 15px;
	  }
	.search {
	  height: 75px;
	  background-color: #F5F5F5;
	  position: relative;
	  top: 16px;
	}
	.search-frame {
	  width: 100%;
	  height: 100px;
	  margin: auto;
	  background-color: #ffffff;
	}
	.el-form{
		height: 60px;
	}
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px;
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
