<template>
	<div class="Role-page">
		<div class="btn flex_m"><el-button size="small ml16" @click="addsort = true">新增分类</el-button></div>
		<el-table
			:data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)"
			border
			row-key="id"
			@row-click="select"
			class="goods_table"
			default-expand-all
			:tree-props="{ children: 'get_product_sort', hasChildren: 'hasChildren' }"
			min-height="100%"
		>
			<el-table-column prop="product_sort_name" label="分类名称" align="center"></el-table-column>
			<el-table-column prop="order" label="排序" align="center">
				<template slot-scope="scope">
					<span v-if="scope.row.order === 0">水果</span>
					<span v-if="scope.row.order === 2">蔬菜</span>
					<span v-if="scope.row.order === 3">生鲜</span>
					<span v-if="scope.row.order === 4">零食</span>
				</template>
				<!-- //商品分类1:水果；2：蔬菜；3：生鲜；4：零食 -->
			</el-table-column>
			<el-table-column prop="is_show" label="是否显示" align="center">
				<template slot-scope="scope">
					<el-switch style="display: block;":active-value="1"
					:inactive-value="0" v-model="scope.row.is_show" active-color="#436BE5" inactive-color="#909399"></el-switch>
				</template>
			</el-table-column>
			<el-table-column label="操作" align="center">
				<template slot-scope="scope">
					<el-button type="text" v-if="scope.row.get_product_sort" @click="subordinateinfo(scope.row)">新增下级</el-button>
					<el-button type="text" @click="geteditinfo(scope.row)">编辑</el-button>
					<el-button type="text" @click="delect(scope.row, scope.row)">删除</el-button>
				</template>
			</el-table-column>
		</el-table>
		<!--分页-->
		<el-pagination
			class="pagination"
			background
			@size-change="handleSizeChange"
			@current-change="handleCurrentChange"
			:current-page="currentPage"
			:page-sizes="[5, 10, 20, 50]"
			:page-size="pagesize"
			layout="total, sizes, prev, pager, next, jumper"
			:total="total"
		></el-pagination>

		<!-- 编辑弹出框 -->
		<el-dialog title="编辑分类" class="layoutbox" :visible.sync="editlayout">
			<el-form label-width="100px" class="demo-ruleForm">
				<el-form-item class="leftlabel" label="分类名称："><el-input class="inputtext" v-model="editinfo.product_sort_name"></el-input></el-form-item>
				<el-form-item class="leftlabel" label="排序号："><el-input style="width:20%" v-model="editinfo.order"></el-input></el-form-item>
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="editlayout = false">取 消</el-button>
				<el-button type="primary" @click="editsure()">确 定</el-button>
			</span>
		</el-dialog>
		<!-- 编辑弹出框  结束-->

		<!-- 新增分类弹出框 -->

		<el-dialog title="新增商品分类" class="layoutbox" :visible.sync="addsort">
			<el-form :model="addkind" :rules="addkind" label-width="100px" class="demo-addruleForm">
				<el-form-item class="leftlabel" label="分类名称："><el-input class="inputtext" v-model="addkind.product_sort_name"></el-input></el-form-item>
				<el-form-item class="leftlabel" label="排序号："><el-input style="width:20%" v-model="addkind.order"></el-input></el-form-item>
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="addsort = false">取 消</el-button>
				<el-button type="primary" @click="saveback(addkind)">确 定</el-button>
			</span>
		</el-dialog>
		<!-- 新增分类弹出框   结束-->
		<!-- 新增商品下级分类弹出框 -->

		<el-dialog title="新增商品下级分类" class="layoutbox" :visible.sync="addSubordinate_classification">
			<el-form :model="addsubordinate" label-width="100px" class="demo-ruleForm">
				<el-form-item class="leftlabel" label="分类名称："><el-input class="inputtext" v-model="addsubordinate.product_sort_name"></el-input></el-form-item>
				<el-form-item class="leftlabel" label="排序号："><el-input style="width:20%" v-model="addsubordinate.order"></el-input></el-form-item>
			</el-form>
			<span slot="footer" class="dialog-footer">
				<el-button @click="addSubordinate_classification = false">取 消</el-button>
				<el-button type="primary" @click="savesubordinate()">确 定</el-button>
			</span>
		</el-dialog>
		<!-- 新增商品下级分类弹出框   结束-->
	</div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
export default {
	data() {
		return {
			addkind:{
				parentid:0,//顶级分类0 分类id
				order:null,//排序
				product_sort_name:""//分类名
			},
			addsubordinate:{
				parentid:0,//顶级分类0 分类id
				order:null,//排序
				product_sort_name:""//分类名
			},
			editinfo:{
				parentid:0,//顶级分类0 分类id
				order:null,//排序
				product_sort_name:""//分类名
			},
			clickrow:[],
			tableData: [],
			total: 0,
			currentPage: 1,
			table_index: 999,
			pagesize: 5,
			user: '',
			goodsnum: '',
			type: false,
			editlayout:false,
			dialogTableVisible: false,
			addsort: false, //新增商品分类
			addSubordinate_classification:false,//新增商品下级分类
			ruleForm: {
				name: '',
				region: '',
				date1: '',
				date2: '',
				delivery: false,
				type: [],
				resource: '',
				desc: ''
			},
			rules: {
				name: [{ required: true, message: '请输入活动名称', trigger: 'blur' }, { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }],
				region: [{ required: true, message: '请选择活动区域', trigger: 'change' }],
				date1: [{ type: 'date', required: true, message: '请选择日期', trigger: 'change' }],
				date2: [{ type: 'date', required: true, message: '请选择时间', trigger: 'change' }],
				type: [{ type: 'array', required: true, message: '请至少选择一个活动性质', trigger: 'change' }],
				resource: [{ required: true, message: '请选择活动资源', trigger: 'change' }],
				desc: [{ required: true, message: '请填写活动形式', trigger: 'blur' }]
			},
			addruleForm: {
				name: '',
				region: '',
				date1: '',
				date2: '',
				delivery: false,
				type: [],
				resource: '',
				desc: ''
			},
			addrules: {
				name: [{ required: true, message: ' ', trigger: 'blur' }],
				region: [{ required: true, message: ' ', trigger: 'change' }],
			}
		};
	},
	components: {},
	created() {
		this.getHomeData();
	},
	methods: {
		handleSizeChange(size) {
			this.pagesize = size;
		},
		//获取点击的数据
		select(val){
			this.clickrow=val;
		},
		handleCurrentChange(currentPage) {
			this.currentPage = currentPage;
		},
		//获取新增下级数据
		subordinateinfo(row){
			this.addSubordinate_classification=true;
			this.addsubordinate.parentid=row.id;
		},
		// 获取数据
		async getHomeData(){
         const result = await axios.get(Rootpath.BASE_URL+'getGoods_list?company_id=1');
         // console.log(result);
				 this.tableData = result.data.tableData
	 			// console.log(this.tableData);
	 			this.total = result.data.tableData.length
      },
		//新增分类保存
		async saveback(){
			// const json = await postHomeCasual(Rootpath.BASE_URL+'sort_add');
			let that=this;
			axios.post(Rootpath.BASE_URL+'sort_add', {
				parentid:0,//顶级分类0 分类id
				order:that.addkind.order,//分类名
				product_sort_name:that.addkind.product_sort_name//排序号
	  })
	  .then(function (response) {
	    console.log(response);
			that.addsort=false;
			that.addkind.product_sort_name='';
			that.addkind.order='';
	  })
	  .catch(function (error) {
	    console.log(error);
	  });
		},
		//新增下级保存
		async savesubordinate(){
			let that=this;
			axios.post(Rootpath.BASE_URL+'sort_add', {
				parentid:that.addsubordinate.parentid,//顶级分类0 分类id
				order:that.addsubordinate.order,//分类名
				product_sort_name:that.addsubordinate.product_sort_name//排序号
	  })
	  .then(function (response) {
	    console.log(response);
			that.addSubordinate_classification=false;
			that.addsubordinate.product_sort_name='';
			that.addsubordinate.order='';
	  })
	  .catch(function (error) {
	    console.log(error);
	  });
		},
		geteditinfo(row){
			this.editlayout=true;
			this.editinfo.parentid=row.id;
			this.editinfo.order=row.order;
			this.editinfo.product_sort_name=row.product_sort_name;
		},
		//修改保存
		async editsure(index){
			let that=this;
			axios.post(Rootpath.BASE_URL+'sort_add', {
				parentid:that.editinfo.parentid,//顶级分类0 分类id
				order:that.editinfo.order,//分类名
				product_sort_name:that.editinfo.product_sort_name//排序号
	  })
	  .then(function (response) {
	    console.log(response);
			that.editlayout=false;
			that.editinfo.product_sort_name='';
			that.editinfo.order='';
	  })
	  .catch(function (error) {
	    console.log(error);
	  });
		},

		// 删除弹窗
		delect(row) {
			// console.log(row);
			// this.tableData.splice(row,1);

			this.$confirm('确定删除该分类？', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			})
				.then(() => {
					// if (row.get_product_sort) {
					// 	this.tableData.splice(row,1);
					// 	// this.tableData.splice(row,row.get_product_sort);
					// 	row.get_product_sort='';
					// }else{
					// 	console.log(row);
					// 	this.tableData.splice(row,1);
					// }
					this.tableData.splice(row,1);
				})
				.catch(() => {

				});
		},
		listCheck() {
			console.log(1);
		}
	}
};
</script>
<style scoped>
.Role-page .el-message-box__message p {
	top: 0;
}
.Role-page {
	background: #ffffff;
}
.Role-page .layoutbox {
	width: 50%;
	margin: 0 auto;
}
.Role-page .el-dialog {
	border-radius: 6px !important;
}
.Role-page .inputtext {
	width: 75%;
}
/* .leftlabel label{
  width: 100px !important;
} */
.Role-page .el-dialog__header {
	border-bottom: 1px solid #d8d8d8;
}
.Role-page .el-dialog__footer {
	border-top: 1px solid #d8d8d8;
}
/* 搜索快 */
.Role-page .searchfrom {
	height: 35px;
	background: #f5f5f5;
}
.Role-page .goods_name_label {
	margin-left: 15px;
	margin-right: 5px;
}
.Role-page .search_btn {
	background: #436be5;
	color: #ffffff;
	margin-left: 15px;
	margin-right: 12px;
}
.Role-page .open {
	color: #436be5;
}
.Role-page i {
	color: #436be5;
}
.Role-page .goodsname {
	width: 167px;
}
.Role-page .open {
	margin-right: 5px;
}
.Role-page .noborder {
	border: none;
	color: #436be5;
}
.Role-page .el-table {
	min-height: 730px;
	overflow: auto;
}
.Role-page .el-table th {
	border: none !important;
}
.Role-page .el-table tr {
	border-bottom: 1px solid #ebeef5;
	border-right: none;
}
.Role-page .el-table--border td {
	border-right: none;
}
.Role-page .has-gutter th {
	background: #f5f5f5;
}
.Role-page .noborder:hover {
	background: #f5f7fa;
	color: #436be5;
	border: none;
}
.Role-page .el-switch__core {
	width: 60px !important;
}
.Role-page .el-switch__label--left {
	position: relative;
	left: 56px;
	color: #fff;
	z-index: -1111;
}
.Role-page .el-switch__label--right {
	position: relative;
	right: 56px;
	color: #fff;
	z-index: -1111;
}
.Role-page .el-switch__label.is-active {
	z-index: 1111;
	color: #fff;
}
/* 按钮 */
.Role-page .btn {
	height: 60px;
}
.Role-page .ml16 {
	margin-left: 16px;
}
.Role-page el-button-group {
	width: 90px;
}
.Role-page .small {
	width: 50% !important;
	height: 15px !important;
}
.Role-page .pagination {
	margin-left: 50%;
}
</style>
