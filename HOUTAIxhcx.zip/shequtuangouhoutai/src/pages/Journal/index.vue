<template>
  <div class="Journal-page">
    <el-tabs v-model="activeName">
<!-- 区域 -->
    <el-tab-pane label="操作日志" name="first">
      <div class="hearsearch">
        <el-form :inline="true" class="flex_m ">
          <el-form-item label="操作主体：" style="margin-left:2%"><el-input size="small" v-model="product_name" style="width: 120px;"></el-input></el-form-item>
          <el-form-item><el-button size="small" @click="search" type="primary">搜索</el-button></el-form-item>
        </el-form>
      </div>
      <div class="addbtn flex_m">
        <!-- <el-button size="mini" name="button" type="primary" @click="addJournal = true">新增</el-button> -->
      </div>

      <el-table
          :data="log_list.slice((currentPage - 1) * pagesize, currentPage * pagesize)"
          stripe
          style="width: 100%;width: 96%;
          margin: 0 auto;">
          <el-table-column
            prop="adm_name"
            align="center"
            label="操作员">
          </el-table-column>
          <el-table-column
            prop="mould"
            align="center"
            label="操作模块">
          </el-table-column>
        <el-table-column
          prop="type"
          align="center"
          label="操作类型">
        </el-table-column>
        <el-table-column
          prop="product_name"
          align="center"
          label="操作主体">
        </el-table-column>
        <el-table-column
          prop="content_change"
          align="center"
          label="变更内容">
        </el-table-column>
        <el-table-column
          prop="prior_change"
          align="center"
          label="变更前">
        </el-table-column>
        <el-table-column
          prop="after_change"
          align="center"
          label="变更后">
        </el-table-column>
        <el-table-column
          prop="operating_ip"
          align="center"
          label="操作IP">
        </el-table-column>
        <el-table-column
          prop="operating_time"
          align="center"
          label="时间">
        </el-table-column>
        </el-table>
        <!--分页-->
    		<el-pagination
    			class="pagination"
    			background
    			@size-change="handleSizeChange"
    			@current-change="handleCurrentChange"
    			:current-page="currentPage"
    			:page-sizes="[5, 10, 20, 50]"
    			:page-size="pagesize"
    			layout="total, sizes, prev, pager, next, jumper"
    			:total="total"
    		></el-pagination>
    </el-tab-pane>

    <!-- 新增弹出框 -->
    <el-dialog title="新增区域" class="layoutbox" :visible.sync="addJournal">
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item class="leftlabel" label="区域名称：" prop="name"><el-input class="inputtext" v-model="ruleForm.name"></el-input></el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="addJournal = false">取 消</el-button>
        <el-button type="primary" @click="addJournal = false">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 新增弹出框  结束-->

    <!-- 编辑弹出框 -->
    <el-dialog title="编辑区域" class="layoutbox" :visible.sync="editJournal">
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item class="leftlabel" label="区域名称：" prop="name"><el-input class="inputtext" v-model="ruleForm.name"></el-input></el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="editJournal = false">取 消</el-button>
        <el-button type="primary" @click="editJournal = false">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 编辑弹出框  结束-->
  </el-tabs>
  </div>
</template>
<script>
import axios from "../../axios.js"
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      activeName: 'first',
      Distributionroute:[],
      addJournal:false,
      editJournal:false,
      log_list:[],
      total:0,
      currentPage: 1,
			table_index: 999,
			pagesize: 5,
      product_name:'',
      form: {
          Journal: '',
        },
        ruleForm: {
  				name: '',
  				Journal: '',
  				date1: '',
  				date2: '',
  				delivery: false,
  				type: [],
  				resource: '',
  				desc: ''
  			},
  			rules: {
  				name: [{ required: true, message: '请输入活动名称', trigger: 'blur' }, { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }],
  				Journal: [{ required: true, message: '请选择活动区域', trigger: 'change' }],
  				date1: [{ type: 'date', required: true, message: '请选择日期', trigger: 'change' }],
  				date2: [{ type: 'date', required: true, message: '请选择时间', trigger: 'change' }],
  				type: [{ type: 'array', required: true, message: '请至少选择一个活动性质', trigger: 'change' }],
  				resource: [{ required: true, message: '请选择活动资源', trigger: 'change' }],
  				desc: [{ required: true, message: '请填写活动形式', trigger: 'blur' }]
  			}

    }
  },
  methods:{
    handleClick(tab, event) {
        console.log(tab, event);
      },
      handleSizeChange(size) {
  			this.pagesize = size;
  		},
  		handleCurrentChange(currentPage) {
  			this.currentPage = currentPage;
  		},
      search(){
        let that = this;
        axios.get(Rootpath.BASE_URL + 'log_list_search', {
                params: {
                    product_name:that.product_name
                }
            })
            .then(function (response) {
                console.log(response);
                if (response=='') {
                  console.log(8);
                }else {
                  that.log_list = response.data.log_list;
                  that.total = response.data.log_list.length;
                }
            })
            .catch(function (error) {
                console.log(error);
            });
      },
      // 获取数据
      async getData() {
        const result = await axios.get(Rootpath.BASE_URL + 'log_list');
        this.log_list = result.data.log_list;
        this.total = result.data.log_list.length;
      },
  },
  created() {
    this.getData();
  },
};
</script>
<style scoped>
.Journal-page{
  background: #ffffff;
  width: 95%;
  margin: 0 auto;
}
.Journal-page .el-tabs__nav{
  margin-left: 20px;
}
.Journal-page .el-tabs__header{
  background: #ffffff;
  margin-top: 50px;
}
.Journal-page .el-form-item{
  margin-bottom: 0 !important;
}
.Journal-page .hearsearch{
    background: #F5F5F5;
    width: 96%;
    margin: 0 auto;
  }
  .Journal-page .hearbtn{
    line-height: 60px;

  }
  .Journal-page .el-form-item__content{
    line-height:0
  }
  .Journal-page .addbtn{
    height: 60px;
    width: 96%;
    margin: 0 auto;
  }
  .Journal-page .layoutbox {
  	width: 50%;
  	margin: 0 auto;
  }
  .Journal-page .el-dialog {
  	border-radius: 6px !important;
  }
  .Journal-page .inputtext {
  	width: 75%;
  }
  .Journal-page .el-table {
  	min-height: 615px;
  	overflow: auto;
  }
  /* .leftlabel label{
    width: 100px !important;
  } */
  .Journal-page .el-dialog__header {
  	border-bottom: 1px solid #d8d8d8;
  }
  .Journal-page .el-dialog__footer {
  	border-top: 1px solid #d8d8d8;
  }
  .Journal-page .el-form-item__label{
    line-height: 60px;
    width: auto !important;
  }
</style>
