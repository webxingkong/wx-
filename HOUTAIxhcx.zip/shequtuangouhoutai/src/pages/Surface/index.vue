<template>
	<div class="select Surface-page">
		<div class="select-table">
			<el-tabs v-model="activeName">
				<!--列表模式-->
				<el-tab-pane label="列表模式" name="first">
					<el-radio-group v-model="tabPosition">
						<el-radio-button label="thisweek">本周</el-radio-button>
						<el-radio-button label="lastweek">上周</el-radio-button>
						<el-radio-button label="thismonth">本月</el-radio-button>
						<el-radio-button label="lastmonth">上月</el-radio-button>
					</el-radio-group>
					<!--时间选择器-->
					&emsp;
					<span class="demonstration">日期：</span>
					<el-date-picker v-model="value1" type="datetime" placeholder="选择日期时间"></el-date-picker>
				&emsp;
				<el-button size="medium" type="primary">搜索</el-button></el-form-item>
				<br /><br />
				<!--布局模块-->
				<el-row :gutter="20">
				  <el-col :span="5">
					  <el-row class="Border flex_m">
					  	<el-col :span="8">
					  		<div class="grid-content flex_c_m"><img src="../../assets/Order.png" width="55px" /></div>
					  	</el-col>
					  	<el-col :span="15">
					  		<div class="grid-content">

					  			<h1>{{top_data.order_count}}</h1>
					  			下单笔数
					  		</div>
					  	</el-col>
					  </el-row>
				  </el-col>
				  <el-col :span="5">
					  <el-row class="Border flex_m">
					  	<el-col :span="8">
					  		<div class="grid-content flex_c_m"><img src="../../assets/pen.png" width="66px" /></div>
					  	</el-col>
					  	<el-col :span="15">
					  		<div class="grid-content">

					  			<h1>{{top_data.refund_su}}</h1>
					  			退货笔数
					  		</div>
					  	</el-col>
					  </el-row>
				  </el-col>
				  <el-col :span="4">
					  <el-row class="Border flex_m">
					  	<el-col :span="8">
					  		<div class="grid-content flex_c_m"><img src="../../assets/single.png" width="55px" /></div>
					  	</el-col>&emsp;
					  	<el-col :span="15">
					  		<div class="grid-content">

					  			<h1>{{top_data.total_money}}</h1>
					  			下单金额
					  		</div>
					  	</el-col>
					  </el-row>
				  </el-col>
				  <el-col :span="5">
					  <el-row class="Border flex_m">
					  	<el-col :span="8">
					  		<div class="grid-content flex_c_m"><img src="../../assets/retreat.png" width="68px" /></div>
					  	</el-col>
					  	<el-col :span="15">
					  		<div class="grid-content">

					  			<h1>{{top_data.after_money}}</h1>
					  			退货金额
					  		</div>
					  	</el-col>
					  </el-row>
				  </el-col>
				  <el-col :span="5">
					  <el-row class="Border flex_m">
					  	<el-col :span="8">
					  		<div class="grid-content flex_c_m"><img src="../../assets/Subtotal.png" width="55px" /></div>
					  	</el-col>
					  	<el-col :span="16">
					  		<div class="grid-content">

					  			<h1>{{top_data.subtotal}}</h1>
					  			小计金额
					  		</div>
					  	</el-col>
					  </el-row>
				  </el-col>
				</el-row>
				<br>
				<br>
				<br>
				<div class="block"><el-button size="medium">导出查询结果</el-button></div><br>
				<!--表格-->
				<el-table :data="order_lsit.slice((currentPage-1)*pagesize,currentPage*pagesize)">
					<el-table-column property="create_times" label="下单日期" width="200"></el-table-column>
					<el-table-column property="order_count" label="订单数" width="200"></el-table-column>
					<el-table-column property="money_sum" label="下单金额" width="200"></el-table-column>
					<el-table-column property="refund_count" label="退货笔数" width="200"></el-table-column>
					<el-table-column property="refund_money" label="退货金额" width="200"></el-table-column>
					<el-table-column property="count_money" label="小计"></el-table-column>
				</el-table>
				<!--分页-->
				 <el-pagination class="block"
						 background
						 @size-change="handleSizeChange"
						 @current-change="handleCurrentChange"
						 :current-page="currentPage"
						 :page-sizes="[5, 10, 20, 50]"
						 :page-size="pagesize"
						 layout="total, sizes, prev, pager, next, jumper"
						 :total="total">
					 </el-pagination>
				</el-tab-pane>

				<!--图表模式-->
				<el-tab-pane label="图表模式" name="second">
					<el-radio-group v-model="tabPosition">
							<el-radio-button label="thisweek">本周</el-radio-button>
							<el-radio-button label="lastweek">上周</el-radio-button>
							<el-radio-button label="thismonth">本月</el-radio-button>
							<el-radio-button label="lastmonth">上月</el-radio-button>
						</el-radio-group>
						<!--时间选择器-->
						&emsp;
						<span class="demonstration">日期：</span>
						<el-date-picker v-model="value1" type="datetime" placeholder="选择日期时间"></el-date-picker>
					&emsp;
					<el-button size="medium" type="primary">搜索</el-button></el-form-item>
					<br /><br />
					<!--布局模块-->
					<el-row :gutter="20">
					  <el-col :span="5">
						  <el-row class="Border flex_m">
						  	<el-col :span="8">
						  		<div class="grid-content flex_c_m"><img src="../../assets/Order.png" width="55px" /></div>
						  	</el-col>
						  	<el-col :span="15">
						  		<div class="grid-content">

						  			<h1>0</h1>
						  			下单笔数
						  		</div>
						  	</el-col>
						  </el-row>
					  </el-col>
					  <el-col :span="5">
						  <el-row class="Border flex_m">
						  	<el-col :span="8">
						  		<div class="grid-content flex_c_m"><img src="../../assets/pen.png" width="65px" /></div>
						  	</el-col>
						  	<el-col :span="15">
						  		<div class="grid-content">

						  			<h1>0</h1>
						  			退货笔数
						  		</div>
						  	</el-col>
						  </el-row>
					  </el-col>
					  <el-col :span="4">
						  <el-row class="Border flex_m">
						  	<el-col :span="8">
						  		<div class="grid-content flex_c_m"><img src="../../assets/single.png" width="55px" /></div>
						  	</el-col>&emsp;
						  	<el-col :span="15">
						  		<div class="grid-content">

						  			<h1>0.00</h1>
						  			下单金额
						  		</div>
						  	</el-col>
						  </el-row>
					  </el-col>
					  <el-col :span="5">
						  <el-row class="Border flex_m">
						  	<el-col :span="8">
						  		<div class="grid-content flex_c_m"><img src="../../assets/retreat.png" width="68px" /></div>
						  	</el-col>
						  	<el-col :span="15">
						  		<div class="grid-content">

						  			<h1>0.00</h1>
						  			退货金额
						  		</div>
						  	</el-col>
						  </el-row>
					  </el-col>
					  <el-col :span="5">
						  <el-row class="Border flex_m">
						  	<el-col :span="8">
						  		<div class="grid-content flex_c_m"><img src="../../assets/Subtotal.png" width="55px"/></div>
						  	</el-col>
						  	<el-col :span="16">
						  		<div class="grid-content">

						  			<h1>0.00</h1>
						  			小计金额
						  		</div>
						  	</el-col>
						  </el-row>
					  </el-col>
					</el-row>
					<br>
					<!--图表-->
	 <el-col :span="24">
		  <div class=" block flex_c">
			  <div>
			  	   <el-button type="primary" size="small" @click="changeType">切换图表样式</el-button>
				   <el-button  size="small"><i class="el-icon-download"></i></el-button>
			    <ve-chart :data="chartData" :settings="chartSettings" width="1000px" height="500px"></ve-chart>
			  </div>
			  </div>
			  </el-col>

			</el-tab-pane>
			</el-tabs>
		</div>
	</div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
import VeLine from 'v-charts/lib/line'

	//测试
export default {
	data() {
		 this.typeArr = ['line', 'histogram', 'pie','bar','waterfall']//
		      this.index = 0//

		return {
			 top_data:{
				 // order_count: 6,//订单数
         // total_money: 93,
         // refund_su: 2,//退单数
         // after_money: 3,
         // subtotal: 90//小计
			 },
			activeName: 'first',
			tabPosition: 'thisweek',
			value1: '',
			value2: '',
			total: 0,
			currentPage: 1,
			pagesize: 5,
			value3: '',
			order_lsit: [],
			 chartData: {
			          columns: ['日期', '订单笔数', '退货笔数', '下单金额','退货金额','小计金额'],
			          rows: [
			            { '日期': '1/1', '订单笔数': 1393, '退货笔数': 1093, '下单金额': 32,'退货金额':520,'小计金额':6565 },
			            { '日期': '1/2', '订单笔数': 3530, '退货笔数': 3230, '下单金额': 26,'退货金额':520,'小计金额':565  },
			            { '日期': '1/3', '订单笔数': 2923, '退货笔数': 2623, '下单金额': 76,'退货金额':520,'小计金额':6565  },
			            { '日期': '1/4', '订单笔数': 1723, '退货笔数': 1423, '下单金额': 49,'退货金额':520,'小计金额':655  },
			            { '日期': '1/5', '订单笔数': 3792, '退货笔数': 3492, '下单金额': 32,'退货金额':520,'小计金额':6565  },
			            { '日期': '1/6', '订单笔数': 4593, '退货笔数': 4293, '下单金额': 78,'退货金额':520,'小计金额':6565  }
			          ]
			        },

					chartSettings: { type: this.typeArr[this.index] }

		};

	},
components: { VeLine },
created() {
		this.getData();
},
	methods: {
		//分页
		handleSizeChange(size) {
			this.pagesize = size
		},
		handleCurrentChange(currentPage) {
			this.currentPage = currentPage
		},
		// 获取数据
		async getData() {
			const result = await axios.get(Rootpath.BASE_URL + 'turnover?type_time='+this.tabPosition);
			console.log(result.data);
				this.top_data = result.data.top_data;
				this.order_lsit = result.data.order_lsit;
				this.total = result.data.order_lsit.length;
		},
		changeType: function () {
		  this.index++
		  if (this.index >= this.typeArr.length) { this.index = 0 }
		  this.chartSettings = { type: this.typeArr[this.index] }
		}


	},

	//

};

</script>


<style scoped>
.grid-content{
height: 60px;
	}
	.Border{
		box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
	}
	h1{
		font-size: 20px;
	}
	.block {
		text-align: right;
	}
	.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
</style>
