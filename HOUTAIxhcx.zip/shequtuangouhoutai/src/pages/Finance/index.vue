<template>
    <div class="Finance-page" style="margin: 20px;">
        <el-tabs v-model="activeName">
            <!-- 时间筛选弹窗 -->
            <div>
                <el-dialog title="提示" :visible.sync="time_Settlement" width="17%">
                    <hr />
                    <p>请按照发货时间筛选订单完成团长结算操作</p>
                    <div id="pinck">
                        <el-date-picker v-model="value1" type="date" placeholder="选择日期">
                        </el-date-picker>
                    </div>
                    <hr />
                    <span slot="footer" class="dialog-footer">
            				 <el-button @click="time_Settlement = false">取 消</el-button>
            				 <el-button type="primary" @click="time_Settlement = false">确 定</el-button>
          			   </span>
                </el-dialog>
            </div>
            <!-- 一键结算 -->

            <!-- 余额明细 -->
            <div class="Balance_window">
                <el-dialog title="" :visible.sync="Detailed" width="50%">
                    <div style="display: flex;">
                        <div style="padding-left:20px">余额明细</div>
                        <div style="padding-left:90px">店铺名称:五菱社区</div>
                        <div style="padding-left:90px">团长名称:李云龙</div>
                    </div>
                    <hr />
                    <div>
                        <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
                            <el-form-item label="状态" style="margin-top: 20px;">
                                <el-select v-model="value" placeholder="请选择" style="width: 120px;" size="small">
                                    <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item label="单号" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                            </el-form-item>
                            <el-form-item>
                                <el-button size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>
                            </el-form-item>
                        </el-form>
                        <el-table :data="tableData" style="width: 100%">
                            <el-table-column prop="date" label="流水号" width="180">
                            </el-table-column>
                            <el-table-column prop="name" label="关联账号" width="180">
                            </el-table-column>
                            <el-table-column prop="name" label="收支类型" width="180">
                            </el-table-column>
                            <el-table-column prop="name" label="金额" width="180">
                            </el-table-column>
                            <el-table-column prop="name" label="变动后余额" width="180">
                            </el-table-column>
                            <el-table-column prop="name" label="操作时间" width="180">
                            </el-table-column>
                            <el-table-column prop="name" label="备注" width="180">
                            </el-table-column>
                        </el-table>
                        <div style="padding-left:72%;height: 32px;">
                            <!-- 分页点击栏靠右边 -->
                            <span>1/6页,45条结果</span>
                            <el-input-number size="mini" v-model="num" controls-position="right" @change="handleChange" :min="1" style="width:80px;"></el-input-number>
                            <span class="menu-icon"><i class="el-icon-arrow-left" /></span>
                            <span class="menu-icon"><i class="el-icon-arrow-right" /></span>
                            <el-button size="mini">指定跳转</el-button>
                        </div>
                    </div>
                    <hr />
                    <span slot="footer" class="dialog-footer">
		 <el-button type="primary" @click="Detailed = false">关闭</el-button>
	   </span>
                </el-dialog>
            </div>



            <!-- 待结算明细 -->
            <div class="Balance_window">
                <el-dialog title="" :visible.sync="Details_settled" width="50%">
                    <div style="display: flex;">
                        <div style="padding-left:20px">待结算佣金明细</div>
                        <div style="padding-left:90px">店铺名称:五菱社区</div>
                        <div style="padding-left:90px">团长名称:李云龙</div>
                    </div>
                    <hr />
                    <div>
                        <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
                            <el-form-item label="类型" style="margin-top: 20px;">
                                <el-select v-model="value" placeholder="请选择" style="width: 120px;" size="small">
                                    <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item label="单号" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                            </el-form-item>
                            <el-form-item>
                                <el-button size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>
                            </el-form-item>
                        </el-form>
                        <el-table :data="tableData" style="width: 100%">
                            <el-table-column prop="date" label="关联单号" width="180">
                            </el-table-column>
                            <el-table-column prop="name" label="类型" width="180">
                            </el-table-column>
                            <el-table-column prop="name" label="金额" width="180">
                            </el-table-column>
                            <el-table-column prop="name" label="团长名称" width="180">
                            </el-table-column>
                            <el-table-column prop="name" label="操作时间" width="180">
                            </el-table-column>
                            <el-table-column prop="name" label="备注" width="180">
                            </el-table-column>
                        </el-table>
                        <div style="padding-left:72%;height: 32px;">
                            <!-- 分页点击栏靠右边 -->
                            <span>1/6页,45条结果</span>
                            <el-input-number size="mini" v-model="num" controls-position="right" @change="handleChange" :min="1" style="width:80px;"></el-input-number>
                            <span class="menu-icon"><i class="el-icon-arrow-left" /></span>
                            <span class="menu-icon"><i class="el-icon-arrow-right" /></span>
                            <el-button size="mini">指定跳转</el-button>
                        </div>
                    </div>
                    <hr />
                    <span slot="footer" class="dialog-footer">
						 <el-button type="primary" @click="Details_settled = false">关闭</el-button>
					   </span>
                </el-dialog>
            </div>
            <el-tab-pane label="团长结算" name="first">
                <div>
                    <el-form :inline="true" :data="searchlist" class="demo-form-inline search-Button">
                        <el-form-item label="团长等级" style="margin-top: 20px;">
                            <el-select v-model="searchlist.gradename" placeholder="请选择" style="width: 120px;" size="small">
                                <el-option v-for="item in Grade" :key="item.value" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="详细地址" style="margin-top: 20px;">
                            <el-select v-model="value" placeholder="请选择" style="width: 120px;" size="small">
                                <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                        <el-form-item label="店铺名称" style="margin-top: 20px;">
                            <el-input size="small" v-model="searchlist.community_name" style="width: 120px;"></el-input>
                        </el-form-item>
                        <el-form-item label="团长名称" style="margin-top: 20px;">
                            <el-input size="small" v-model="searchlist.leader_name" style="width: 120px;"></el-input>
                        </el-form-item>
                        <el-form-item label="团长电话" style="margin-top: 20px;">
                            <el-input size="small" v-model="searchlist.mobile" style="width: 120px;"></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button size="small" type="primary" @click="search" style="margin-top: 23px;">搜索</el-button>
                        </el-form-item>
                    </el-form>
                </div>
                <div style="margin: 15px;">
                    <el-button type="primary" @click="time_Settlement=true">发货时间筛选结算</el-button>
                    <el-button type="primary" @click="clickSettlement">一键结算</el-button>
                </div>
                <div class="right">
                    <el-button size="medium">导出查询结果</el-button>
                </div>
                <div style="margin-top:15px;">
                    <el-table :data="leader_accounts_list.slice((currentPage-1)*pagesize,currentPage*pagesize)" stripe style="width: 100%">
                        <el-table-column prop="mobile" align="center" label="团长电话" width="180">
                        </el-table-column>
                        <el-table-column align="center" prop="community_name" label="店铺名称" width="180">
                        </el-table-column>
                        <el-table-column align="center" prop="leader_name" label="团长名称">
                        </el-table-column>
                        <el-table-column align="center" prop="level_name" label="团长等级">
                        </el-table-column>
                        <el-table-column align="center" prop="commission" label="佣金总额">
                        </el-table-column>
                        <el-table-column align="center" prop="com_on" label="已结算佣金">
                        </el-table-column>
                        <el-table-column align="center" prop="com_off" label="待结算佣金">
                        </el-table-column>
                        <el-table-column align="center" prop="balance" label="账户余额">
                        </el-table-column>
                        <el-table-column align="center" prop="lately_time" label="最近结算时间">
                        </el-table-column>
                        <el-table-column align="center" prop="address" label="操作">
                            <template slot-scope="scope">
                                <el-button @click="Settlement_details(scope.row)" type="text" size="small">详情</el-button>
                                <el-button type="text" size="small" @click="Detailed=true">余额明细</el-button>
                                <el-button type="text" size="small" @click="Details_settled=true">待结算佣金明细</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                    <!--分页-->
                     <el-pagination class="block"
                         background
                         @size-change="handleSizeChange"
                         @current-change="handleCurrentChange"
                         :current-page="currentPage"
                         :page-sizes="[5, 10, 20, 50]"
                         :page-size="pagesize"
                         layout="total, sizes, prev, pager, next, jumper"
                         :total="total">
                       </el-pagination>
                </div>

            </el-tab-pane>
        </el-tabs>
    </div>
</template>
<script>
    import axios from '../../axios.js';
    import https from "../../../api/https.vue"
    import Rootpath from "../../../api/index.js"
    import qs from '../../../node_modules/qs'
    export
    default {
        name: 'first',
        components: {},
        data() {
            return {
              searchlist:{
                gradename:'',
                leader_name: '',
                mobile: '',
                community_name:'',
              },
              total: 0,
        			currentPage: 1,
        			pagesize: 5,
                time_Settlement: false, //时间筛选
                Settlement: false, //筛选
                Detailed: false, //余额明细
                Details_settled: false, //
                activeName: 'first',
                num: 1,
                formInline: {
                    user: '',
                    region: ''
                },
                value1: '',
                tableData:[],
                leader_accounts_list: [],
                Grade:[
                  {
                    value: '全部',
                    label: '全部'
                  },
                  {
                    value: '团长',
                    label: '团长'
                  }
                ],
                options: [{
                    value: '选项1',
                    label: '黄金糕'
                }, {
                    value: '选项2',
                    label: '双皮奶'
                }, {
                    value: '选项3',
                    label: '蚵仔煎'
                }, {
                    value: '选项4',
                    label: '龙须面'
                }, {
                    value: '选项5',
                    label: '北京烤鸭'
                }],
                value: ''
            }
        },
        created() {
            this.getData();
        },
        methods: {
                handleChange(value) {
                    console.log(value);
                },
                //分页
                handleSizeChange(size) {
                  this.pagesize = size
                },
                handleCurrentChange(currentPage) {
                  this.currentPage = currentPage
                },
                clickSettlement(){
                  this.$confirm('是否执行一键结算?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                  }).then(() => {

                  }).catch(() => {

                  });
                },
                // 获取数据
                async getData() {
                    const result = await axios.get(Rootpath.BASE_URL + 'leader_account');
                    console.log(result.data);
                    this.leader_accounts_list = result.data.leader_accounts_list;
                    // // console.log();
                    this.total = result.data.leader_accounts_list.length;
                },
                //搜索
                async search() {
                    let that = this;
                    axios.get(Rootpath.BASE_URL + 'head_sett', {
                            params: {
                                leader_name: that.searchlist.leader_name,
                                mobile: that.searchlist.mobile,
                                community_name:2019-10-24,
                            }
                        })
                        .then(function (response) {
                            console.log(response);
                            that.leader_accounts_list = response.data.leader_accounts_list;
                            // // console.log();
                            that.total = response.data.leader_accounts_list.length;
                        })
                        .catch(function (error) {
                            console.log(error);
                        });
                },
                onSubmit() {
                    console.log('submit!');
                }, //团长结算跳转详情
                Settlement_details(row) { 
                  console.log(row);
                    this.$router.push({
                        path: '/finance/finance/Settlement_details',
                        query: {
                            leader_id: row.id
                        }
                    })
                },

        }
    };
</script>
<style scoped>
    @font-face {
        font-family: 'iconfont';
        /* project id 1395133 */
        src: url('//at.alicdn.com/t/font_1395133_uuiy2tupjun.eot');
        src: url('//at.alicdn.com/t/font_1395133_uuiy2tupjun.eot?#iefix') format('embedded-opentype'), url('//at.alicdn.com/t/font_1395133_uuiy2tupjun.woff2') format('woff2'), url('//at.alicdn.com/t/font_1395133_uuiy2tupjun.woff') format('woff'), url('//at.alicdn.com/t/font_1395133_uuiy2tupjun.ttf') format('truetype'), url('//at.alicdn.com/t/font_1395133_uuiy2tupjun.svg#iconfont') format('svg');
    }
    .iconfont {
        font-family: "iconfont" !important;
        font-size: 16px;
        font-style: normal;
        -webkit-font-smoothing: antialiased;
        -webkit-text-stroke-width: 0.2px;
        -moz-osx-font-smoothing: grayscale;
    }
    .paging {
        position: fixed;
        right: 0px;
        bottom: 0px;
        background: #FAFAFA;
        width: 100%;
        height: 40px;
        float: right;
        line-height: 0px;
        z-index: 999;
        box-shadow: darkgrey 10px 10px 30px 5px;
    }
    #pinck .el-input__inner {
        width: 350px;
    }
    .Balance_window {}
</style>
