<template>
  <div class="Settlement_details-page" style="margin: 20px;">
	  <el-tabs v-model="activeName">
	     <el-tab-pane label="团长结算详情" name="first">
				<div>

				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				  <el-form-item label="状态" style="margin-top: 20px;">
					 <el-select v-model="searchlist.order_sett_state" placeholder="请选择" style="width: 120px;"  size="small">
					    <el-option
					      v-for="item in options"
					      :key="item.value"
					      :label="item.label"
					      :value="item.value">
					    </el-option>
					  </el-select>
				  </el-form-item>

				  <el-form-item label="订单号" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="searchlist.order_number" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item>
					<el-button  size="small" type="primary" @click="search" style="margin-top: 23px;">搜索</el-button>
				  </el-form-item>
				</el-form>
				</div>
				<div class="right">
				<el-button size="medium">导出查询结果</el-button>
				</div>
					<div style="margin-top:15px;">
						<el-table
						    :data="leader_info_sett.slice((currentPage-1)*pagesize,currentPage*pagesize)"
						    stripe
						    style="width: 100%">
						    <el-table-column
							   prop="order_number"
							  align="center"
						      label="订单号"
						      >
							</el-table-column>
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="delivery_date"
						      label="发货日期"
						      >
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="pay_money"
						      label="订单实付">
						    </el-table-column>
							<el-table-column
							  align="center"
							  prop="refund_amount"
							  label="退款金额">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="commission_sett"
							  label="应结佣金">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="order_sett_time"
							  label="结算时间">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="order_sett_state"
							  label="结算状态">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="order_remarks"
							  label="备注">
							</el-table-column>
							<el-table-column
							  align="center"
							  label="操作">
							 <template slot-scope="scope">
							 	        <el-button type="text" @click="Settlement_details(scope.row)" size="small">详情</el-button>
							 	      </template>
							 	    </el-table-column>
						  </el-table>
              <!--分页-->
               <el-pagination class="block"
                   background
                   @size-change="handleSizeChange"
                   @current-change="handleCurrentChange"
                   :current-page="currentPage"
                   :page-sizes="[5, 10, 20, 50]"
                   :page-size="pagesize"
                   layout="total, sizes, prev, pager, next, jumper"
                   :total="total">
                 </el-pagination>
					</div>

		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  name: 'first',
  components: {},
   data() {
        return {
			 activeName: 'first',
			  num: 1,
        total: 0,
        currentPage: 1,
        pagesize: 5,
        searchlist:{
          order_sett_state: '',
          order_number: '',
          delivery_date:''
        },
			   formInline: {
			            user: '',
			            region: ''
			          },
          leader_info_sett: [],
		      options: [{
		            value: '选项1',
		            label: '黄金糕'
		          }, {
		            value: '选项2',
		            label: '双皮奶'
		          }, {
		            value: '选项3',
		            label: '蚵仔煎'
		          }, {
		            value: '选项4',
		            label: '龙须面'
		          }, {
		            value: '选项5',
		            label: '北京烤鸭'
		          }],
		          value: ''
		        }
      },
      created() {
          this.getData();
      },
	   methods: {
       // 获取数据
       async getData() {
           var leader_id = this.$route.query.leader_id
           const result = await axios.get(Rootpath.BASE_URL + 'leader_account_info?leader_id=' + leader_id);
           this.leader_info_sett = result.data.leader_info_sett;
           // // console.log();
           this.total = result.data.leader_info_sett.length;
       },
       //分页
       handleSizeChange(size) {
         this.pagesize = size
       },
       //详情
       Settlement_details(row) { 
         console.log(row);
           this.$router.push({
               path: '/table/basic/Details',
               query: {
                   on:row.order_number
               }
           })
       },
       //搜索
       async search() {
           let that = this;
           axios.get(Rootpath.BASE_URL + 'leader_search_info', {
                   params: {
                       order_sett_state: that.searchlist.order_sett_state,
                       order_number: that.searchlist.order_number,
                       delivery_date:2019-10-24,
                   }
               })
               .then(function (response) {
                   console.log(response);
                   that.leader_info_sett = response.data.leader_info_sett;
                   that.total = response.data.leader_info_sett.length;
               })
               .catch(function (error) {
                   console.log(error);
               });
       },
       handleCurrentChange(currentPage) {
         this.currentPage = currentPage
       },
	        handleChange(value) {
	          console.log(value);
	        },
			onSubmit() {
			        console.log('submit!');
			      },
	      }
};
</script>
<style scoped>
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px;
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
