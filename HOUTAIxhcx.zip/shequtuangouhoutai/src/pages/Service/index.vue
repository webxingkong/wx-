<template>
    <div class="Service-page" style="margin: 20px;">
        <el-tabs v-model="activeName">
            <el-tab-pane label="整单退款" name="1">

                <div class="search-frame">
                    <div class="search">
                        <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
                            <el-form-item label="订单编号：" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.order_number" style="width: 150px;"></el-input>
                            </el-form-item>
                            <el-form-item label="商品名称：" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.product_name" style="width: 150px;"></el-input>
                            </el-form-item>
                            <el-form-item label="注册时间" style="margin-top: 20px;">
                                <!-- <el-input size="small" v-model="formInline.create_time" style="width: 120px;"></el-input> -->
                                <!-- <el-date-picker
                                  v-model="formInline.create_time"
                                  type="datetime"
                                  size="small"
                                  style="width: 150px;"
                                  placeholder="选择日期时间">
                                </el-date-picker> -->
                                <el-date-picker
                                  v-model="formInline.create_time"
                                  type="daterange"
                                  style="width: 150px;"
                                  range-separator="至"
                                  start-placeholder="开始日期"
                                  end-placeholder="结束日期">
                                </el-date-picker>
                            </el-form-item>&emsp;
                            <el-form-item style="margin-top: 20px;">
                                <el-button size="small" type="primary" @click="searcfinfo">搜索</el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                </div>
                <div class="right">
                    <el-button size="medium">导出查询结果</el-button>
                </div>
                <!-- 弹层退款html -->
                <div>
                    <el-dialog title="确认退款" :visible.sync="dialogVisible" width="30%" :data="orderAfterSale">
                        <hr />
                        <div style="display: flex;justify-content: center;">
                            <div style="text-align:right;">
                                <div class="Layertop">售后编号:</div>
                                <div class="Layertop">退款类型:</div>
                                <div class="Layertop">理由:</div>
                                <div class="Layertop">说明:</div>
                                <div class="Layertop">联系人:</div>
                                <div class="Layertop">退款金额:</div>
                                <div class="Layertop">备注:</div>
                            </div>
                            <div style="margin-left:30px;">
                                <div class="Layertop">{{clickrow.after_sale_number}}</div>
                                <div class="Layertop">{{clickrow.audit_state}}</div>
                                <div class="Layertop">{{clickrow.after_sale_reasons}}</div>
                                <div class="Layertop">{{clickrow.audit_state_name}}</div>
                                <div class="Layertop">{{clickrow.wx_name}}</div>
                                <div class="Layertop" style="color: red;">{{clickrow.refund_amount}}</div>
                                <div class="Layertop">
                                    <el-input style="width: 200px;" v-model="clickrow.refund_order_remarks" placeholder="点击输入" size="mini"></el-input>
                                </div>
                            </div>
                        </div>
                        <hr />
                        <span slot="footer" class="dialog-footer">
							 <el-button @click="dialogVisible = false">取 消</el-button>
							 <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
						   </span>
                    </el-dialog>
                </div>
                <!-- 弹层详情html -->
                <div>
                    <el-dialog title="退款详情" :visible.sync="seedialog" width="600px">
                        <hr />
                        <div style="display: flex;justify-content:space-around;">
                            <div>
                                <div class="Layertop">退款单号：{{orderAfterSaleInfo.after_sale_number}}</div>
                                <div class="Layertop">退款类型：{{orderAfterSaleInfo.after_sale_type_name}}</div>
                                <div class="Layertop">退款原因：{{orderAfterSaleInfo.after_sale_reason}}</div>
                                <div class="Layertop">审核状态：{{orderAfterSaleInfo.audit_state}}</div>
                                <div class="Layertop">联系人：{{orderAfterSaleInfo.wx_name}}</div>
                                <div class="Layertop">单据状态：{{orderAfterSaleInfo.audit_state_name}}</div>
                                <div class="Layertop">审核人：{{orderAfterSaleInfo.auditor}}</div>
                                <div class="Layertop">退款账号：{{orderAfterSaleInfo.auditor_name}}</div>
                            </div>
                            <div style="padding-right:30px;">
                                <div class="Layertop">源订单号：{{orderAfterSaleInfo.community_name}}</div>
                                <div class="Layertop">团长：{{orderAfterSaleInfo.community_name}}</div>
                                <div class="Layertop">退货说明：{{orderAfterSaleInfo.after_sale_reason}}</div>
                                <div class="Layertop">审核时间：{{orderAfterSaleInfo.audit_time}}</div>
                                <div class="Layertop">退款金额：{{orderAfterSaleInfo.refund_amount}}</div>
                                <div class="Layertop">审核方式：{{orderAfterSaleInfo.audit_type}}</div>
                                <div class="Layertop">结算人：{{orderAfterSaleInfo.auditor_name}}</div>
                            </div>

                        </div>
                        <div class="imginfo">
                            <el-row :gutter="20">
                                <el-col :span="6">
                                    <div class="grid-content bg-purple flex_m" style="justify-content:center">
                                        <!-- <img src="" alt=""> -->
                                        <img :src="aftergoodsinfo.goods_img" min-width="40" height="40" />
                                    </div>
                                </el-col>
                                <el-col :span="6">
                                    <div class="grid-content bg-purple flex_m" style="justify-content:center">
                                        {{aftergoodsinfo.goods_name}} ￥{{aftergoodsinfo.after_money}}*{{aftergoodsinfo.after_count}}
                                    </div>
                                </el-col>
                                <el-col :span="6">
                                    <div class="grid-content bg-purple flex_m" style="justify-content:center">
                                        退货数量：{{aftergoodsinfo.after_count}}
                                    </div>
                                </el-col>
                                <el-col :span="6">
                                    <div class="grid-content bg-purple flex_m" style="justify-content:center;color:red;">
                                        退货金额：￥{{aftergoodsinfo.after_money}}
                                    </div>
                                </el-col>
                            </el-row>
                        </div>
                        <hr />
                        <span slot="footer" class="dialog-footer">
									 <el-button @click="seedialog = false">取 消</el-button>
									 <el-button type="primary" @click="seedialog = false">确 定</el-button>
								   </span>
                    </el-dialog>
                </div>
                <!-- 表格html -->
                <div>
                    <el-table :data="orderAfterSale.slice((currentPage-1)*pagesize,currentPage*pagesize)" stripe @row-click="select" style="width: 100%">
                        <el-table-column prop="order_number" align="center" label="订单号">
                        </el-table-column>
                        <el-table-column prop="wx_name" align="center" label="团长名称">
                        </el-table-column>
                        <el-table-column prop="goods_name" align="center" label="商品">
                        </el-table-column>
                        <el-table-column prop="ask_date" align="center" label="申请日期">
                        </el-table-column>
                        <el-table-column prop="refund_amount" align="center" label="退款">
                        </el-table-column>
                        <el-table-column prop="after_sale_reasons" align="center" label="退货">
                        </el-table-column>
                        <el-table-column prop="after_sale_reasons" align="center" label="处理状态">
                        </el-table-column>
                        <el-table-column label="操作"  align="center">
                          <template slot-scope="scope">
                            <el-button type="text" @click="dialogVisible = true">处理退款</el-button>
                            <el-button type="text" @click="getorderAfterSaleInfo(scope.row)">查看详情</el-button>
                          </template>
                        </el-table-column>
                    </el-table>
                    <!--分页-->
                    <el-pagination
                    class="pagination"
                    background
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="currentPage"
                    :page-sizes="[5, 10, 20, 50]"
                    :page-size="pagesize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total">
                    </el-pagination>
                </div>

            </el-tab-pane>
            <el-tab-pane label="仅退款" name="2">
              <div class="search-frame">
                  <div class="search">
                      <el-form :inline="true" :model="refund_onlyform" class="demo-form-inline search-Button">
                          <el-form-item label="订单编号：" style="margin-top: 20px;">
                              <el-input size="small" v-model="refund_onlyform.order_number" style="width: 150px;"></el-input>
                          </el-form-item>
                          <el-form-item label="商品名称：" style="margin-top: 20px;">
                              <el-input size="small" v-model="refund_onlyform.product_name" style="width: 150px;"></el-input>
                          </el-form-item>
                          <el-form-item label="注册时间" style="margin-top: 20px;">
                              <!-- <el-input size="small" v-model="formInline.create_time" style="width: 120px;"></el-input> -->
                              <el-date-picker
                                v-model="refund_onlyform.create_time"
                                type="daterange"
                                style="width: 150px;"
                                size="small"
                                range-separator="至"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                              </el-date-picker>
                          </el-form-item>&emsp;
                          <el-form-item style="margin-top: 20px;">
                              <el-button size="small" type="primary" @click="refund_onlysearch">搜索</el-button>
                          </el-form-item>
                      </el-form>
                  </div>
              </div>
              <div class="right">
                  <el-button size="medium">导出查询结果</el-button>
              </div>
              <!-- 弹层退款html -->
              <div>
                  <el-dialog title="确认退款" :visible.sync="refund_onlylayout" width="600px" :data="orderAfterSale">
                      <hr />
                      <div style="display: flex;justify-content: center;">
                          <div style="text-align:right;">
                              <div class="Layertop">售后编号:</div>
                              <div class="Layertop">退款类型:</div>
                              <div class="Layertop">理由:</div>
                              <div class="Layertop">说明:</div>
                              <div class="Layertop">联系人:</div>
                              <div class="Layertop">退款金额:</div>
                              <div class="Layertop">备注:</div>
                          </div>
                          <div style="margin-left:30px;">
                              <div class="Layertop">{{refund_onlyrow.after_sale_number}}</div>
                              <div class="Layertop">{{refund_onlyrow.audit_state}}</div>
                              <div class="Layertop">{{refund_onlyrow.after_sale_reasons}}</div>
                              <div class="Layertop">{{refund_onlyrow.audit_state_name}}</div>
                              <div class="Layertop">{{refund_onlyrow.wx_name}}</div>
                              <div class="Layertop" style="color: red;">{{refund_onlyrow.refund_amount}}</div>
                              <div class="Layertop">
                                  <el-input style="width: 200px;" v-model="refund_onlyrow.refund_order_remarks" placeholder="点击输入" size="mini"></el-input>
                              </div>
                          </div>
                      </div>
                      <hr />
                      <span slot="footer" class="dialog-footer">
             <el-button @click="refund_onlylayout = false">取 消</el-button>
             <el-button type="primary" @click="refund_onlylayout = false">确 定</el-button>
             </span>
                  </el-dialog>
              </div>
              <!-- 弹层详情html -->
              <div>
                  <el-dialog title="退款详情" :visible.sync="seedialog" width="600px">
                      <hr />
                      <div style="display: flex;justify-content:space-around;">
                          <div>
                              <div class="Layertop">退款单号：{{orderAfterSaleInfo.after_sale_number}}</div>
                              <div class="Layertop">退款类型：{{orderAfterSaleInfo.after_sale_type_name}}</div>
                              <div class="Layertop">退款原因：{{orderAfterSaleInfo.after_sale_reason}}</div>
                              <div class="Layertop">审核状态：{{orderAfterSaleInfo.audit_state}}</div>
                              <div class="Layertop">联系人：{{orderAfterSaleInfo.wx_name}}</div>
                              <div class="Layertop">单据状态：{{orderAfterSaleInfo.audit_state_name}}</div>
                              <div class="Layertop">审核人：{{orderAfterSaleInfo.auditor}}</div>
                              <div class="Layertop">退款账号：{{orderAfterSaleInfo.auditor_name}}</div>
                          </div>
                          <div style="padding-right:30px;">
                              <div class="Layertop">源订单号：{{orderAfterSaleInfo.community_name}}</div>
                              <div class="Layertop">团长：{{orderAfterSaleInfo.community_name}}</div>
                              <div class="Layertop">退货说明：{{orderAfterSaleInfo.after_sale_reason}}</div>
                              <div class="Layertop">审核时间：{{orderAfterSaleInfo.audit_time}}</div>
                              <div class="Layertop">退款金额：{{orderAfterSaleInfo.refund_amount}}</div>
                              <div class="Layertop">审核方式：{{orderAfterSaleInfo.audit_type}}</div>
                              <div class="Layertop">结算人：{{orderAfterSaleInfo.auditor_name}}</div>
                          </div>

                      </div>
                      <div class="imginfo">
                          <el-row :gutter="20">
                              <el-col :span="6">
                                  <div class="grid-content bg-purple flex_m" style="justify-content:center">
                                      <!-- <img src="" alt=""> -->
                                      <img :src="aftergoodsinfo.goods_img" min-width="40" height="40" />
                                  </div>
                              </el-col>
                              <el-col :span="6">
                                  <div class="grid-content bg-purple flex_m" style="justify-content:center">
                                      {{aftergoodsinfo.goods_name}} ￥{{aftergoodsinfo.after_money}}*{{aftergoodsinfo.after_count}}
                                  </div>
                              </el-col>
                              <el-col :span="6">
                                  <div class="grid-content bg-purple flex_m" style="justify-content:center">
                                      退货数量：{{aftergoodsinfo.after_count}}
                                  </div>
                              </el-col>
                              <el-col :span="6">
                                  <div class="grid-content bg-purple flex_m" style="justify-content:center;color:red;">
                                      退货金额：￥{{aftergoodsinfo.after_money}}
                                  </div>
                              </el-col>
                          </el-row>
                      </div>
                      <hr />
                      <span slot="footer" class="dialog-footer">
                 <el-button @click="seedialog = false">取 消</el-button>
                 <el-button type="primary" @click="seedialog = false">确 定</el-button>
                 </span>
                  </el-dialog>
              </div>
              <!-- 表格html -->
              <div>
                  <el-table :data="orderAfterSale.slice((currentPage-1)*pagesize,currentPage*pagesize)" stripe @row-click="refund_onlyselect" style="width: 100%">
                      <el-table-column prop="order_number" align="center" label="订单号">
                      </el-table-column>
                      <el-table-column prop="wx_name" align="center" label="团长名称">
                      </el-table-column>
                      <el-table-column prop="goods_name" align="center" label="商品">
                      </el-table-column>
                      <el-table-column prop="ask_date" align="center" label="申请日期">
                      </el-table-column>
                      <el-table-column prop="refund_amount" align="center" label="退款">
                      </el-table-column>
                      <el-table-column prop="after_sale_reasons" align="center" label="退货">
                      </el-table-column>
                      <el-table-column prop="after_sale_reasons" align="center" label="处理状态">
                      </el-table-column>
                      <el-table-column label="操作"  align="center">
                        <template slot-scope="scope">
                          <el-button type="text" @click="refund_onlylayout = true">处理退款</el-button>
                          <el-button type="text" @click="getorderAfterSaleInfo(scope.row)">查看详情</el-button>
                        </template>
                      </el-table-column>
                  </el-table>
                  <!--分页-->
                  <el-pagination
                  class="pagination"
                  background
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                  :current-page="currentPage"
                  :page-sizes="[5, 10, 20, 50]"
                  :page-size="pagesize"
                  layout="total, sizes, prev, pager, next, jumper"
                  :total="total">
                  </el-pagination>
              </div>

            </el-tab-pane>
            <el-tab-pane label="退货退款" name="3"></el-tab-pane>
            <el-tab-pane label="待处理" name="4"></el-tab-pane>
        </el-tabs>
    </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
    export default {
        name: 'first',
        components: {},
        data() {
            return {
                activeName: '1',
                //点击行获取数据
                clickrow: [],
                refund_onlyrow:[],
                //存储后端获取的数据
                orderAfterSale: [],
                //详情数据
                orderAfterSaleInfo: [],
                aftergoodsinfo:[],
                total: 0,
                currentPage: 1,
                table_index: 999,
                pagesize: 5,
                refund_onlylayout:false,
                dialogVisible: false, //控制退款弹层
                seedialog: false, //控制查看弹层
                num: 1,
                //整单退款
                formInline: {
                    create_time: '',
                    product_name: '',
                    order_number:''
                },
                //仅退款
                refund_onlyform: {
                    create_time: '',
                    product_name: '',
                    order_number:''
                },
            }
        },
        created() {
            this.getData();
            // this.getorderAfterSaleInfo();
        },
        methods: {
            handleChange(value) {
                    console.log(value);
                },
                select(val) {
                    this.clickrow = val;
                    console.log(val);
                },
                refund_onlyselect(val) {
                    this.refund_onlyrow = val;
                    console.log(val);
                },
                handleSizeChange(size) {
                    this.pagesize = size
                },
                handleCurrentChange(currentPage) {
                    this.currentPage = currentPage
                },
                //查询
                async searcfinfo() {
                  let that = this;
                  let filedate=that.formInline.create_time;
                  let date1='';
                  for (var i = 0; i < filedate.length; i++) {
                    var d = new Date(filedate[i]);
                    d=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
                    if (date1=="") {
                      date1=d;
                    }else {
                      date1 = date1+' - '+d
                    }
                  }
                  const result = await axios.get(
                    Rootpath.BASE_URL
                    + 'afterSale_search?type='
                    +that.activeName
                    +'&&create_time='+date1+'&&product_name='
                    +that.formInline.product_name
                    +'&&order_number='+that.formInline.order_number);
                  this.orderAfterSale = result.data.orderAfterSale;
                  // console.log(result.data);
                  this.total = result.data.orderAfterSale.length;
                },
                //仅退款查询
                async refund_onlysearch() {
                  let that = this;
                  axios.post(Rootpath.BASE_URL + 'afterSale_search', {
                          type: that.activeName,
                          create_time: that.refund_onlyform.create_time,
                          product_name: that.refund_onlyform.product_name,
                          order_number: that.refund_onlyform.order_number
                      })
                      .then(function (response) {
                          console.log(that.response);
                      })
                      .catch(function (error) {
                          console.log(error);
                      });
                },
                // 获取数据
                async getData() {
                    const result = await axios.get(Rootpath.BASE_URL + 'afterSale?type='+this.activeName);
                    this.orderAfterSale = result.data.orderAfterSale;
                    console.log(result.data);
                    this.total = result.data.orderAfterSale.length;
                },
                // 获取详情数据
                async getorderAfterSaleInfo(row) {
                    this.seedialog = true
                    // const result = await getHomeCasual('afterSaleInfo?after_sale=1', );
                    const result = await axios.get(Rootpath.BASE_URL + 'afterSaleInfo?after_sale='+row.after_sale_number);
                    console.log(result.data.orderAfterSaleInfo);
                    this.orderAfterSaleInfo = result.data.orderAfterSaleInfo;
                    let oa=result.data.orderAfterSaleInfo.goods_info;
                    for (var i = 0; i < oa.length; i++) {
                      console.log(oa[i]);
                      this.aftergoodsinfo=oa[i];
                    }
                    // this.aftergoodsinfo=result.data.orderAfterSaleInfo.aftergoodsinfo;

                    // console.log(result.data.orderAfterSaleInfo.aftergoodsinfo);
                },
        },
    };
</script>
<style scoped>
    /* 操作弹窗类的样式 */
    .search {
        height: 75px;
        background-color: #F5F5F5;
        position: relative;
        top: 16px;
    }
    .search-frame {
        width: 100%;
        height: 100px;
        margin: auto;
        background-color: #ffffff;
    }
    .Layertop {
        font-size: 15px;
        margin-top: 10px;
    }
    /* 底部分页样式 */
    .paging {
        position: fixed;
        right: 0px;
        bottom: 0px;
        background: #FAFAFA;
        width: 100%;
        height: 40px;
        float: right;
        line-height: 0px;
        z-index: 999;
        box-shadow: darkgrey 10px 10px 30px 5px;
    }
</style>
