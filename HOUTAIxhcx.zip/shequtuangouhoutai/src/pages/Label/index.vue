<template>
	<div class="select Lable-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="会员标签" name="first"></el-tab-pane></el-tabs>
			<br />
			<div class="search">
				<!---->
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
					<el-form-item label="标签名称" style="margin-top: 20px;"><el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input></el-form-item>
					&emsp;
					<el-form-item><el-button size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button></el-form-item>
				</el-form>
			</div>
			<br />
			<br />
			<el-button @click="psks" size="small" type="primary">新增</el-button>
			<br />
			<br />
			<el-table :data="user_list" style="width: 100%">
				<el-table-column prop="user_level_id" label="编号" width="150"></el-table-column>
				<el-table-column prop="wx_name" label="名称" ></el-table-column>
				<el-table-column fixed="right" label="操作" width="100">
					<template slot-scope="scope">
						<el-button @click="editinfo(scope.row)" type="text" size="small">编辑</el-button>
						<el-button type="text" @click="open">删除</el-button>
					</template>
				</el-table-column>
			</el-table>
		</div>
	</div>
</template>
<script>
import https from "../../../api/https.vue"
import {getHomeCasual} from "../../../api/index.js"
import axios from '../../axios.js';
import Rootpath from "../../../api/index.js"
export default {
	data() {
		return {
			activeName: 'first',
			user_list: [],
			formInline: {
				user: '',
				region: ''
			}
		};
	},
	created(){
		this.getData();
	},
	methods: {
		onSubmit() {
			console.log('submit!');
		},
		editinfo(){
			console.log(87);
		},
		open() {
			this.$confirm('删除等级后，等级属实会员将移至默认等级，请谨慎操作！', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			})
				.then(() => {
					this.$message({
						type: 'success',
						message: '删除成功!'
					});
				})
				.catch(() => {
					this.$message({
						type: 'info',
						message: '已取消删除'
					});
				});
		}, //新增弹框
		psks() {
			this.$prompt('会员标签', '新增', {
				confirmButtonText: '保存',
				cancelButtonText: '取消'
			})
				.then(({ value }) => {
					this.$message({
						type: 'success',
						message: '保存成功'
					});
				})
				.catch(() => {
					this.$message({
						type: 'info',
						message: '取消保存'
					});
				});
		},

		//获取数据
		async getData(){
				 const result = await axios.get(Rootpath.BASE_URL+'userlist');
				 // console.log(result);
				 this.user_list = result.data.user_list
			},
	}
};
</script>
<style scoped>




	.text {
		display: flex;
		left: 20px;
		position: relative;
		top: 15px;
	}

	.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	} /*border: solid 1rpx #007AFF;
	*/
	.search {
		height: 70px;
		background-color: #f5f5f5;
	}

</style>
