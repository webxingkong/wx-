<template>
	<div class="select">
		<div class="select-table">
			<el-tabs v-model="activeName" @tab-click="handleClick"><el-tab-pane label="充值规则" name="first"></el-tab-pane></el-tabs>
			<br />
			<el-button size="small" type="primary">新增规则</el-button>
			<br />
			<br />
			<el-table :data="tableData" border style="width: 100%">
				<el-table-column fixed prop="date" label="序号" width="50"></el-table-column>
				<el-table-column prop="name" label="方案名称" width="120"></el-table-column>
				<el-table-column prop="province" label="充值金额" width="120"></el-table-column>
				<el-table-column prop="city" label="赠送金额" width="120"></el-table-column>
				<el-table-column prop="address" label="赠送详情"></el-table-column>

				<el-table-column fixed="right" label="操作" width="100">
					<template slot-scope="scope">
						<el-button @click="handleClick(scope.row)" type="text" size="small">编辑</el-button>
						<el-button type="text" size="small">删除</el-button>
					</template>
				</el-table-column>
			</el-table>
			<br />
			<br />

			<el-tabs v-model="activeName" @tab-click="handleClick"><el-tab-pane label="充值活动" name="first"></el-tab-pane></el-tabs>

			<span class="text">图片尺寸宽800px高不限， 大小≤6MB，支持JPG、PNG、JPEG</span>
			<br />
			<br />
			<br />
			<!--上传组件-->
			<div>
				<el-upload action="#" list-type="picture-card" :auto-upload="false" limit="5">
					<i slot="default" class="el-icon-plus"></i>
					<div slot="file" slot-scope="{ file }">
						<img class="el-upload-list__item-thumbnail" :src="file.url" alt="" />
						<span class="el-upload-list__item-actions">
							<span class="el-upload-list__item-preview" @click="handlePictureCardPreview(file)"><i class="el-icon-zoom-in"></i></span>

							<span class="el-upload-list__item-delete" @click="handleRemove(file)"><i class="el-icon-delete"></i></span>
						</span>
					</div>
				</el-upload>
				<el-dialog :visible.sync="dialogVisible"><img width="100%" :src="dialogImageUrl" alt="" /></el-dialog>
			</div>
			<!--上传组件-->
			<br />
			<br />
			<el-button size="small" type="primary">保存</el-button>
			<br />
			<br />
		</div>
	</div>
</template>
<script>
export default {
	methods: {
		handleClick(row) {
			console.log(row);
		}
	},
	handleRemove(file) {
		console.log(file);
	},
	handlePictureCardPreview(file) {
		this.dialogImageUrl = file.url;
		this.dialogVisible = true;
	},
	handleDownload(file) {
		console.log(file);
	},
	data() {
		return {
			activeName: 'first',
			tableData: [
				{
					date: '01',
					name: '充值100.00',
					province: '￥100',
					city: '不赠送',
					address: '1'
				},
				{
					date: '02',
					name: '充值100.00',
					province: '￥100',
					city: '不赠送',
					address: '1'
				},
				{
					date: '03',
					name: '充值100.00',
					province: '￥100',
					city: '不赠送',
					address: '1'
				},
				{
					date: '04',
					name: '充值100.00',
					province: '￥100',
					city: '不赠送',
					address: '1'
				}
			],

			dialogImageUrl: '',
			dialogVisible: false,
			disabled: false
		};
	}
};
</script>
<style scoped>
.activity {
	width: 100px;
	height: 20px;
	color: #436be5;
}
.text {
	color: #666666;
	font-size: 13px;
	margin-top: -15px;
	
}
	


.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select {
	margin: auto;
	width: 96%;
	background-color: #ffffff;
} /*border: solid 1rpx #007AFF;
*/

</style>
