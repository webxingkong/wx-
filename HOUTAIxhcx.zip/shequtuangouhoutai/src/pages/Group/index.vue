<template>
  <div class="Group-page" style="margin: 20px;">
	  <el-tabs v-model="activeName">
	     <el-tab-pane label="团长提现" name="first">
				<div>
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				  <el-form-item label="团长等级" style="margin-top: 20px;">
					 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
					    <el-option
					      v-for="item in options"
					      :key="item.value"
					      :label="item.label"
					      :value="item.value">
					    </el-option>
					  </el-select>
				  </el-form-item>
				  <el-form-item label="详细地址" style="margin-top: 20px;">
				  					 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
				  					    <el-option
				  					      v-for="item in options"
				  					      :key="item.value"
				  					      :label="item.label"
				  					      :value="item.value">
				  					    </el-option>
				  					  </el-select>
				  </el-form-item>
				  <el-form-item label="店铺名称" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="团长名称" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="团长电话" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item style="margin-top: 20px;">
					<el-button  size="small" type="primary" @click="onSubmit">搜索</el-button>
				  </el-form-item>
				</el-form>
				</div>
				<div class="right">
				<el-button size="medium">导出查询结果</el-button>
				</div>
					<div style="margin-top:15px;">
						<el-table
						    :data="cash_list.slice((currentPage-1)*pagesize,currentPage*pagesize)"
                @row-click="rowclick"
						    stripe
						    style="width: 100%">
						    <el-table-column
							   prop="cash_num"
							  align="center"
						      label="提货单号"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="leader_number"
						      label="团长账号"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="community_name"
						      label="店铺名称">
						    </el-table-column>
							<el-table-column
							  align="center"
							  prop="leader_name"
							  label="团长名称">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="level_name"
							  label="团长等级">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="cash_with"
							  label="提货金额">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="tr_time"
							  label="审核时间">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="tr_state"
							  label="状态">
                <template slot-scope="scope">
                  <span v-if="scope.row.tr_state==='0'">未审核</span>
                  <span v-if="scope.row.tr_state==='1'">已审核</span>
                </template>
                <!-- 审核状态 0未审核 1已审核 -->
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="account_type"
							  label="付款方式">
                <template slot-scope="scope">
                  <span v-if="scope.row.account_type===1">银行卡</span>
                  <span v-if="scope.row.account_type===2">支付宝</span>
                  <span v-if="scope.row.account_type===3">微信</span>
                </template>
							</el-table-column>
							<el-table-column
							  align="center"
							  label="操作">
							 <template slot-scope="scope">
							 	        <el-button @click="time_Settlement=true" type="text" size="small">详情</el-button>
							 	        <el-button type="text" v-if="scope.row.tr_state==='0'" size="small" @click="detailform=true">审核</el-button>
							 	      </template>
							 	    </el-table-column>
						  </el-table>
              <!--分页-->
               <el-pagination class="block"
                   background
                   @size-change="handleSizeChange"
                   @current-change="handleCurrentChange"
                   :current-page="currentPage"
                   :page-sizes="[5, 10, 20, 50]"
                   :page-size="pagesize"
                   layout="total, sizes, prev, pager, next, jumper"
                   :total="total">
                 </el-pagination>
					</div>
          <div>
              <el-dialog title="提现单详情" :visible.sync="time_Settlement" width="700px">
                  <ul>
                    <li class="detailse_li flex_m"><p>提现单号：</p>{{detailsform.cash_num}}</li>
                    <li class="detailse_li flex_m"><p>提现金额：</p>{{detailsform.cash_with}}</li>
                    <li class="detailse_li flex_m"><p>团长：</p>{{detailsform.leader_name}}</li>
                    <li class="detailse_li flex_m"><p>团长等级：</p>{{detailsform.level_name}}</li>
                    <li class="detailse_li flex_m"><p>社区店：</p>{{detailsform.community_name}}</li>
                    <li class="detailse_li flex_m"><p>联系方式：</p>{{detailsform.mobile}}</li>
                    <!-- <li class="detailse_li flex_m">详细地址：{{detailsform.cash_num}}</li> -->
                    <li class="detailse_li flex_m"><p>开户银行：</p>{{detailsform.open_bank}}</li>
                    <li class="detailse_li flex_m"><p>账户名称：</p>{{detailsform.account_name}}</li>
                    <li class="detailse_li flex_m"><p>账户账号：</p>{{detailsform.account_number}}</li>
                    <li class="detailse_li flex_m"><p>付款方式：</p>{{detailsform.account_type}}</li>
                  </ul>
                  <div slot="footer" class="dialog-footer">
                    <el-button @click="time_Settlement = false">关闭</el-button>
                  </div>
              </el-dialog>
          </div>
          <div>
              <el-dialog title="提现单详情" :visible.sync="detailform" width="700px">
                  <ul>
                    <li class="detailse_li flex_m"><p>提现单号：</p>{{detailsform.cash_num}}</li>
                    <li class="detailse_li flex_m"><p>提现金额：</p>{{detailsform.cash_with}}</li>
                    <li class="detailse_li flex_m"><p>团长：</p>{{detailsform.leader_name}}</li>
                    <li class="detailse_li flex_m"><p>团长等级：</p>{{detailsform.level_name}}</li>
                    <li class="detailse_li flex_m"><p>社区店：</p>{{detailsform.community_name}}</li>
                    <li class="detailse_li flex_m"><p>联系方式：</p>{{detailsform.mobile}}</li>
                    <li class="detailse_li flex_m">详细地址：{{detailsform.detail_address}}</li>
                    <li class="detailse_li flex_m"><p>开户银行：</p>{{detailsform.open_bank}}</li>
                    <li class="detailse_li flex_m"><p>账户名称：</p>{{detailsform.account_name}}</li>
                    <li class="detailse_li flex_m"><p>账户账号：</p>{{detailsform.account_number}}</li>
                    <li class="detailse_li flex_m"><p>付款方式：</p>
                      <el-radio-group v-model="radio">
                        <el-radio :label="3">备选项</el-radio>
                        <el-radio :label="6">备选项</el-radio>
                        <el-radio :label="9">备选项</el-radio>
                      </el-radio-group>
                    </li>
                  </ul>
                  <div slot="footer" class="dialog-footer">
                    <el-button @click="detailform = false">关闭</el-button>
                    <el-button @click="detailform = false">拒绝</el-button>
                    <el-button type="primary" @click="detailform = false">通过</el-button>
                  </div>
              </el-dialog>
          </div>
		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  name: 'first',
  components: {},
   data() {
        return {
			 activeName: 'first',
       time_Settlement:false,
       detailform:false,
       radio:3,
			  num: 1,
        total: 0,
        currentPage: 1,
        pagesize: 5,
        rowclickinfo:[],
        detailsform:{},
			   formInline: {
			            user: '',
			            region: ''
			          },
          cash_list: [],
		      options: [{
		            value: '选项1',
		            label: '黄金糕'
		          }, {
		            value: '选项2',
		            label: '双皮奶'
		          }, {
		            value: '选项3',
		            label: '蚵仔煎'
		          }, {
		            value: '选项4',
		            label: '龙须面'
		          }, {
		            value: '选项5',
		            label: '北京烤鸭'
		          }],
		          value: ''
		        }
      },
      created() {
          this.getData();
      },
	   methods: {
	        handleChange(value) {
	          console.log(value);
	        },
          rowclick(row){
            this.rowclickinfo=row;
          },
          //分页
          handleSizeChange(size) {
            this.pagesize = size
          },
          handleCurrentChange(currentPage) {
            this.currentPage = currentPage
          },
          // 获取数据
          async getData() {
            const result = await axios.get(Rootpath.BASE_URL + 'leader_cash');
            // console.log(result.data);
            this.cash_list = result.data.cash_list;
            // console.log();
            this.total = result.data.cash_list.length;
            const json = await axios.get(Rootpath.BASE_URL + 'leader_cash_info?cash_id='+this.rowclickinfo.id);
            this.detailsform=json.data;
            // 账号类型 1银行 2支付宝 3微信
            if (this.detailsform.account_type==1) {
              this.detailsform.account_type='银行';
            }else if (this.detailsform.account_type==2) {
              this.detailsform.account_type='支付宝';
            }else{
              this.detailsform.account_type='微信';
            }
          },
			onSubmit() {
			        console.log('submit!');
			      },//跳转新增页面
				  increase(){
				  		 this.$router.push({path:'/market/Seckill/Spike_added',query: {id:1}})
				  },//跳转详情页面
				  details(){
					  this.$router.push({path:'/market/Seckill/details',query: {id:1}})
				  },//跳转复制活动页面
				  copy(){
					   this.$router.push({path:'/market/Seckill/copy',query: {id:1}})
				  },
	      }
};
</script>
<style scoped>
  .detailse_li p{
    width: 100px;
    text-align: right;
  }
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px;
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
