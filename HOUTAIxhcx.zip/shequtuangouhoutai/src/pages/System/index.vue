<template>
  <div class="System-page">
    <el-tabs v-model="activeName">
<!-- 商城设置 -->
    <el-tab-pane label="商城设置" name="first">
      <el-form ref="form" :model="form" label-width="170px">
        <el-form-item label="订单自动关闭时间：">
          <el-input size="small" class="inputword" v-model="shopset.order_auto_close_time"></el-input>
          <el-tooltip class="item" visible-arrow="false" content="下单超过设置时间没有支付，则订单自动关闭" placement="right">
            <i class="el-icon-question"></i>
          </el-tooltip>
        </el-form-item>
        <el-form-item label="订单自动完成时间：">
          <el-input size="small" class="inputword" v-model="shopset.order_tuto_success_time"></el-input>
          <el-tooltip class="item" visible-arrow="false" content="下单超过设置时间没有支付，则订单自动关闭" placement="right">
            <i class="el-icon-question"></i>
          </el-tooltip>
        </el-form-item>
        <el-form-item label="订单可申请售后时间：">
          <el-input size="small" class="inputword" v-model="shopset.order_sale_time"></el-input>
          <el-tooltip class="item" visible-arrow="false" content="下单超过设置时间没有支付，则订单自动关闭" placement="right">
            <i class="el-icon-question"></i>
          </el-tooltip>
        </el-form-item>
        <el-form-item label="订单结算周期：">
          <el-input size="small" class="inputword" v-model="shopset.order_settlement"></el-input>
          <el-tooltip class="item" visible-arrow="false" content="下单超过设置时间没有支付，则订单自动关闭" placement="right">
            <i class="el-icon-question"></i>
          </el-tooltip>
        </el-form-item>
        <el-form-item label="送货日期设置：">
          <el-select v-model="shopset.delivery_data" class="inputword" size="small" placeholder="请选择活动区域">
            <el-option label="区域一" value="shanghai"></el-option>
            <el-option label="区域二" value="beijing"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="截至下单时间：">
          <el-col :span="11">
            <el-time-picker type="fixed-time" placeholder="选择时间" size="small" class="inputword" v-model="shopset.end_order_time"></el-time-picker>
          </el-col>
        </el-form-item>
        <el-form-item label="分类展示规则：">
          <el-select v-model="shopset.display_rule" class="inputword" size="small" placeholder="请选择活动区域">
            <el-option label="区域一" value="shanghai"></el-option>
            <el-option label="区域二" value="beijing"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="隐藏团长号码：">
          <el-switch
          v-model="shopset.hide_phone_number"
          active-color="#13ce66"
          inactive-color="#ff4949">
          </el-switch>
        </el-form-item>
        <el-form-item label="开启团长待收货：">
          <el-switch
          v-model="shopset.open_leader_due"
          active-color="#13ce66"
          inactive-color="#ff4949">
          </el-switch>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="save" size="small">保存</el-button>
        </el-form-item>
      </el-form>
    </el-tab-pane>

<!-- 业务配置 -->
    <el-tab-pane label="业务配置" name="second">
      <el-form ref="business" :model="business" label-width="140px">
        <el-form-item label="售卖库存预警值：">
          <el-input size="small" class="inputword" v-model="business.alert" style="width:300px"></el-input>
          <el-tooltip class="item" visible-arrow="false" content="填写值，低于该值则出发预警" placement="right">
            <i class="el-icon-question"></i>
          </el-tooltip>
        </el-form-item>
        <el-form-item label="入库模式：">
          <el-radio-group v-model="business.storage_mode">
            <el-radio label="直接入库"></el-radio>
            <el-radio label="审核入库"></el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="允许切换团长：">
          <el-switch
          v-model="business.allow_replace_rc"
          active-color="#13ce66"
          inactive-color="#ff4949">
          </el-switch>
        </el-form-item>
        <el-form-item label="允许团长审核售后：">
          <el-switch
          v-model="business.allow_rc_examine"
          active-color="#13ce66"
          inactive-color="#ff4949">
          </el-switch>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="businesssave" size="small">保存</el-button>
        </el-form-item>
      </el-form>
    </el-tab-pane>
<!-- 推送信息 -->
    <el-tab-pane label="推送信息" name="Third">
      <div class="">
        <!-- 1 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">sad</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">sad</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">服务通知</span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">短信通知</span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 2 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">订单相关：</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">下单成功</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">
                <el-switch
                v-model="Orderservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="OrderSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 3 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">sad</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">订单到货</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">
                <el-switch
                v-model="Arrivalservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="ArriveSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 4 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">sad</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">退款</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Refundservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="RefundSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 5 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">sad</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">订单取消失败</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Cancel_failureservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Cancel_failureSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 6 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">sad</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">订单关闭</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Closeorderservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="CloseorderSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 7 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">会员相关：</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">取货成功</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Successful_purchaseservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Successful_purchaseSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 8 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">sad</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">积分兑换成功</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Integral_exchangeservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Integral_exchangeSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 9 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">团长相关：</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">入驻申请</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Settled_inservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Settled_inSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 10 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">sad</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">推荐登记成功</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Recommended_registrationservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Recommended_registrationSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 11 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">sad</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">配送单发货</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Deliveryservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="DeliverySMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 12 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">生活服务：</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">下单成功</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Checkout_successservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Checkout_successSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 13 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">sad</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">订单关闭</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Close_checkoutservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Close_checkoutSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 14 -->
      	<el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">sad</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">核销成功</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Write_offservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Write_offSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 15 -->
        <el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">其他：</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">提现</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Cash_outservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m">
              <span class="layoutcontent">
                <el-switch
                v-model="Cash_outSMS"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
        <!-- 16 -->
        <el-row :gutter="12">
        	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m">
          		<span class="layoutcontent">
                <el-button size="small" @click="leaveladd" type="primary">保存</el-button>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
          		<span class="layoutcontent">提现</span>
          	</div>
          	</el-col>
          	<el-col :span="3">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
              <span class="layoutcontent">
                <el-switch
                v-model="Orderservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
          	</el-col>
          	<el-col :span="6">
          	<div class="grid-content bg-purple flex_c_m" style="visibility:hidden">
              <span class="layoutcontent">
                <el-switch
                v-model="Orderservice"
                active-color="#13ce66"
                inactive-color="#ff4949">
                </el-switch>
              </span>
          	</div>
        	</el-col>
      	</el-row>
      </div>
    </el-tab-pane>


  </el-tabs>
  </div>
</template>
<script>
import axios from "../../axios.js"
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      activeName: 'first',
      Distributionroute:[],
      addRegion:false,
      editRegion:false,
      Orderservice:null,//下单服务通知
      OrderSMS:null,//下单短信通知
      Arrivalservice:null,//订单到货服务通知
      ArriveSMS:null,//订单到货短信通知
      Refundservice:null,//退款服务通知
      RefundSMS:null,//退款短信通知
      Cancel_failureservice:null,//订单取消失败服务通知
      Cancel_failureSMS:null,//订单取消失败短信通知
      Closeorderservice:null,//订单取消服务通知
      CloseorderSMS:null,//订单取消短信通知
      Successful_purchaseservice:null,//取货成功服务
      Successful_purchaseSMS:null,//取货成功短信
      Integral_exchangeservice:null,//积分兑换服务
      Integral_exchangeSMS:null,//积分兑换短信
      Settled_inservice:null,//入驻服务
      Settled_inSMS:null,//入驻短信
      Recommended_registrationservice:null,//推荐登记服务
      Recommended_registrationSMS:null,//推荐登记短信
      Deliveryservice:null,//发货服务
      DeliverySMS:null,//发货短信
      Checkout_successservice:null,//下单成功服务
      Checkout_successSMS:null,//下单成功短信
      Close_checkoutservice:null,//关闭订单服务
      Close_checkoutSMS:null,//关闭订单短信
      Write_offservice:null,//核销成功服务
      Write_offSMS:null,//核销成功短信
      Cash_outservice:null,//提现服务
      Cash_outSMS:null,//提现短信
      shopset:{},
      business:{},
      push:{},
      form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        tableData6: []
    }
  },
  methods:{
    // 获取数据
    async getData() {
      //商城设置
      const result = await axios.get(Rootpath.BASE_URL + 'shop_set');
      this.shopset = result.data;
      this.shopset.hide_phone_number==0?this.shopset.hide_phone_number=false:this.shopset.hide_phone_number=true;
      this.shopset.open_leader_due==0?this.shopset.open_leader_due=false:this.shopset.open_leader_due=true;
      //业务配置
      const info = await axios.get(Rootpath.BASE_URL + 'business_set');
      this.business=info.data;
      this.business.storage_mode==0?this.business.storage_mode='直接入库':this.business.storage_mode='审核入库';
      this.business.allow_replace_rc==0?this.business.allow_replace_rc=true:this.business.allow_replace_rc=false;
      this.business.allow_rc_examine==0?this.business.allow_rc_examine=true:this.business.allow_rc_examine=false;
      //推送消息
      const json = await axios.get(Rootpath.BASE_URL + 'push_set');
      this.push=json.data;
      //下单成功
      this.Orderservice=this.push.order_success.service;
      this.OrderSMS=this.push.order_success.message;
      this.Orderservice==0?this.Orderservice=false:this.Orderservice=true;
      this.OrderSMS==0?this.OrderSMS=false:this.OrderSMS=true;
      //订单到货
      this.Arrivalservice=this.push.order_arrival.service;
      this.ArriveSMS=this.push.order_arrival.message;
      this.Arrivalservice==0?this.Arrivalservice=false:this.Arrivalservice=true;
      this.ArriveSMS==0?this.ArriveSMS=false:this.ArriveSMS=true;
      //退款
      this.Refundservice=this.push.order_refund.service;
      this.RefundSMS=this.push.order_refund.message;
      this.Refundservice==0?this.Refundservice=false:this.Refundservice=true;
      this.RefundSMS==0?this.RefundSMS=false:this.RefundSMS=true;
      //订单取消失败
      this.Cancel_failureservice=this.push.order_cancel_fail.service;
      this.Cancel_failureSMS=this.push.order_cancel_fail.message;
      this.Cancel_failureservice==0?this.Cancel_failureservice=false:this.Cancel_failureservice=true;
      this.Cancel_failureSMS==0?this.Cancel_failureSMS=false:this.Cancel_failureSMS=true;
      //订单关闭
      this.Closeorderservice=this.push.order_close.service;
      this.CloseorderSMS=this.push.order_close.message;
      this.Closeorderservice==0?this.Closeorderservice=false:this.Closeorderservice=true;
      this.CloseorderSMS==0?this.CloseorderSMS=false:this.CloseorderSMS=true;
      //取货成功
      this.Successful_purchaseservice=this.push.receive_success.service;
      this.Successful_purchaseSMS=this.push.receive_success.message;
      this.Successful_purchaseservice==0?this.Successful_purchaseservice=false:this.Successful_purchaseservice=true;
      this.Successful_purchaseSMS==0?this.Successful_purchaseSMS=false:this.Successful_purchaseSMS=true;
      //积分兑换成功
      this.Integral_exchangeservice=this.push.exchange_success.service;
      this.Integral_exchangeSMS=this.push.exchange_success.message;
      this.Integral_exchangeservice==0?this.Integral_exchangeservice=false:this.Integral_exchangeservice=true;
      this.Integral_exchangeSMS==0?this.Integral_exchangeSMS=false:this.Integral_exchangeSMS=true;
      //入驻申请
      this.Settled_inservice=this.push.checkin.service;
      this.Settled_inSMS=this.push.checkin.message;
      this.Settled_inservice==0?this.Settled_inservice=false:this.Settled_inservice=true;
      this.Settled_inSMS==0?this.Settled_inSMS=false:this.Settled_inSMS=true;
      //推荐登记成功
      this.Recommended_registrationservice=this.push.recommend_success.service;
      this.Recommended_registrationSMS=this.push.recommend_success.message;
      this.Recommended_registrationservice==0?this.Recommended_registrationservice=false:this.Recommended_registrationservice=true;
      this.Recommended_registrationSMS==0?this.Recommended_registrationSMS=false:this.Recommended_registrationSMS=true;
      //配送单发货
      this.Deliveryservice=this.push.deliver.service;
      this.DeliverySMS=this.push.deliver.message;
      this.Deliveryservice==0?this.Deliveryservice=false:this.Deliveryservice=true;
      this.DeliverySMS==0?this.DeliverySMS=false:this.DeliverySMS=true;
      //下单成功
      this.Checkout_successservice=this.push.purchase_success.service;
      this.Checkout_successSMS=this.push.purchase_success.message;
      this.Checkout_successservice==0?this.Checkout_successservice=false:this.Checkout_successservice=true;
      this.Checkout_successSMS==0?this.Checkout_successSMS=false:this.Checkout_successSMS=true;
      //订单关闭
      this.Close_checkoutservice=this.push.closing_order.service;
      this.Close_checkoutSMS=this.push.closing_order.message;
      this.Close_checkoutservice==0?this.Close_checkoutservice=false:this.Close_checkoutservice=true;
      this.Close_checkoutSMS==0?this.Close_checkoutSMS=false:this.Close_checkoutSMS=true;
      //核销成功
      this.Write_offservice=this.push.checking_success.service;
      this.Write_offSMS=this.push.checking_success.message;
      this.Write_offservice==0?this.Write_offservice=false:this.Write_offservice=true;
      this.Write_offSMS==0?this.Write_offSMS=false:this.Write_offSMS=true;
      //提现
      this.Cash_outservice=this.push.cash_out.service;
      this.Cash_outSMS=this.push.cash_out.message;
      this.Cash_outservice==0?this.Cash_outservice=false:this.Cash_outservice=true;
      this.Cash_outSMS==0?this.Cash_outSMS=false:this.Cash_outSMS=true;
    },
    //商城设置保存
    save() {
    let that = this;
    axios.post(Rootpath.BASE_URL + 'shop_edit', {
          id: that.shopset.id,
          company_id: that.shopset.company_id,
          order_auto_close_time: that.shopset.order_auto_close_time,//订单自动关闭时间 小时
          order_tuto_success_time: that.shopset.order_tuto_success_time,//订单自动完成时间 小时
          order_sale_time: that.shopset.order_sale_time,//订单可申请售后时间 天
          order_settlement: that.shopset.order_settlement,//订单结算周期 天
          delivery_data: that.shopset.delivery_data,//送货日期设置 天
          end_order_time: that.shopset.end_order_time,//截止下单时间
          display_rule: that.shopset.display_rule,//分类规则 0 显示全部商品 1 仅显示非活动商品
          hide_phone_number: that.shopset.hide_phone_number,//隐藏团长号码 0隐藏 1显示
          open_leader_due: that.shopset.open_leader_due//开启团长待收货 0开启 1关闭
        })
        .then(function (response) {
          that.$confirm('保存成功', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'success'
          })
            .then(() => {
            })
            .catch(() => {
            });
        })
        .catch(function (error) {
            console.log(error);
        });

    },
    //业务配置保存
    businesssave() {
      let that = this;
      axios.post(Rootpath.BASE_URL + 'shop_edit', {
            alert:that.business.alert,
            storage_mode:that.business.storage_mode,
            allow_replace_rc:that.business.allow_replace_rc,
            allow_rc_examine:that.business.allow_rc_examine,
            company_id:that.business.company_id,
          })
          .then(function (response) {
            that.$confirm('保存成功', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'success'
            })
              .then(() => {
              })
              .catch(() => {
              });
          })
          .catch(function (error) {
              console.log(error);
          });
    },
    async leaveladd(index) {
      let data={
        id: this.push.id,
        Orderservice:this.Orderservice,//下单服务通知
        OrderSMS:this.OrderSMS,//下单短信通知
        Arrivalservice:this.Arrivalservice,//订单到货服务通知
        ArriveSMS:this.ArriveSMS,//订单到货短信通知
        Refundservice:this.Refundservice,//退款服务通知
        RefundSMS:this.RefundSMS,//退款短信通知
        Cancel_failureservice:this.Cancel_failureservice,//订单取消失败服务通知
        Cancel_failureSMS:this.Cancel_failureSMS,//订单取消失败短信通知
        Closeorderservice:this.Closeorderservice,//订单取消服务通知
        CloseorderSMS:this.CloseorderSMS,//订单取消短信通知
        Successful_purchaseservice:this.Successful_purchaseservice,//取货成功服务
        Successful_purchaseSMS:this.Successful_purchaseSMS,//取货成功短信
        Integral_exchangeservice:this.Integral_exchangeservice,//积分兑换服务
        Integral_exchangeSMS:this.Integral_exchangeSMS,//积分兑换短信
        Settled_inservice:this.Settled_inservice,//入驻服务
        Settled_inSMS:this.Settled_inSMS,//入驻短信
        Recommended_registrationservice:this.Recommended_registrationservice,//推荐登记服务
        Recommended_registrationSMS:this.Recommended_registrationSMS,//推荐登记短信
        Deliveryservice:this.Deliveryservice,//发货服务
        DeliverySMS:this.DeliverySMS,//发货短信
        Checkout_successservice:this.Checkout_successservice,//下单成功服务
        Checkout_successSMS:this.Checkout_successSMS,//下单成功短信
        Close_checkoutservice:this.Close_checkoutservice,//关闭订单服务
        Close_checkoutSMS:this.Close_checkoutSMS,//关闭订单短信
        Write_offservice:this.Write_offservice,//核销成功服务
        Write_offSMS:this.Write_offSMS,//核销成功短信
        Cash_outservice:this.Cash_outservice,//提现服务
        Cash_outSMS:this.Cash_outSMS,//提现短信
      }

      axios.post(Rootpath.BASE_URL + 'push_edit', {
              data
                  // data:that.form
          })
          .then(function (response) {
              // that.dialogFormVisible = false;
              console.log(response);
          })
          .catch(function (error) {
              console.log(error);
          });
    },

  },
  created() {
    this.getData();
    const listUrl = 'http://yhxapi.me/mock/24/admin/path/Push_information'
    axios.get(listUrl).then((response) => {
      console.log(response);
      // this.tableData = response.data.tableData
      // this.total = response.data.tableData.length
    })
  },

};
</script>
<style scoped>
.System-page{
  background: #ffffff;
  width: 95%;
  margin: 0 auto;
}
.System-page .el-tabs__nav{
  margin-left: 20px;
}
.System-page .el-tabs__header{
  background: #ffffff;
  margin-top: 50px;
}
.System-page .el-form-item{
  margin-bottom: 0 !important;
}
.System-page .hearsearch{
    background: #F5F5F5;
    width: 96%;
    margin: 0 auto;
  }
  .System-page .hearbtn{
    line-height: 60px;

  }
  .System-page .el-form-item__content{
    line-height:60px
  }
  .System-page .addbtn{
    height: 60px;
    width: 96%;
    margin: 0 auto;
  }
  .System-page .el-form-item__label{
    line-height: 60px;
  }
  .System-page .el-form-item__content{
    margin-left: 300px !important;
  }
  .el-form-item__label{
    width: 300px !important;
  }
  .inputword{
    width: 320px;
  }
  .el-row {
    margin-bottom: 20px;
    &:last-child {
      margin-bottom: 0;
    }
  }
  .System-page .grid-content{
    height: 20px;
  }

</style>
