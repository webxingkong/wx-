<template>
  <div class="Delivery-page" style="margin: 20px;">
	  <el-tabs v-model="activeName">
	     <el-tab-pane label="配送单" name="first">
				<div>
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				  <el-form-item label="店铺名称" style="margin-top: 20px;">
					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="配送单号" style="margin-top: 20px;">
					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="团长姓名" style="margin-top: 20px;">
					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>&emsp;
				  <el-form-item label="发货日期" style="margin-top: 20px;">
					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>&emsp;
				  <el-form-item>
					<el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>
				  </el-form-item>
				</el-form>
				</div>
					 <div class="right">
					 <el-button size="medium">导出查询结果</el-button>
					 </div>
					<div>
						<el-table
						    :data="deliveryNotes.slice((currentPage-1)*pagesize,currentPage*pagesize)"
						    stripe
						    style="width: 100%">
						    <el-table-column
							  align="center"
						      label="配送单号"
                  prop="delivery_number">
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="community_name"
						      label="店铺名称">
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="leader_name"
						      label="团长名称">
						    </el-table-column>
							<el-table-column
							  align="center"
							  prop="shortagePrice"
							  label="缺货金额">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="pay_money"
							  label="发货金额">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="delivery_date"
							  label="发货时间">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="status"
							  label="状态">
							</el-table-column>
							<el-table-column
							  align="center"
							  label="操作">
                <template slot-scope="scope">
                  <el-button type="text" @click="details(scope.row)">详情</el-button>
                  <el-button type="text" @click="dialogVisible = true">打印</el-button>
							  </template>
							</el-table-column>
						  </el-table>
              <!--分页-->
        			<el-pagination class="pagination"
        					background
        					@size-change="handleSizeChange"
        					@current-change="handleCurrentChange"
        					:current-page="currentPage"
        					:page-sizes="[5, 10, 20, 50]"
        					:page-size="pagesize"
        					layout="total, sizes, prev, pager, next, jumper"
        					:total="total">
        				</el-pagination>
					</div>

		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  name: 'first',
  components: {},
   data() {
        return {
			 activeName: 'first',
       total: 0,
       currentPage: 1,
       table_index: 999,
       pagesize: 5,
       parentrow:[],
			  num: 1,
			   formInline: {
			            user: '',
			            region: ''
			          },
          deliveryNotes: [],
        }
      },
      created() {
          this.getData();
          // this.integrlist();
      },
	   methods: {
       handleSizeChange(size) {
         this.pagesize = size
       },
       handleCurrentChange(currentPage) {
         this.currentPage = currentPage
       },
	        handleChange(value) {
	          console.log(value);
	        },
			onSubmit() {
			        console.log('submit!');
			      },
				  details(row){
            console.log(row);
					  //详情商品跳转函数
					  this.$router.push({path:'/charts/bar/Distribution_details',query: {
             delivery_number: row.delivery_number,
           }});

         },
         // 获取数据
     async getData() {
         const result = await axios.get(Rootpath.BASE_URL + 'deliveryNote');
         console.log(result);
         this.deliveryNotes=result.data.deliveryNotes
         this.total = result.data.deliveryNotes.length
         // this.grade_list = result.data.grade_list
         // this.total = result.data.grade_list.length
     },
	      }
};
</script>
<style scoped>
	.text{
	    display: flex;
		align-items: center;
	    left: 20px;
	    position: relative;
	    top: 15px;
	  }
	.search {
	  height: 75px;
	  background-color: #F5F5F5;
	  position: relative;
	  top: 16px;
	}
	.search-frame {
	  width: 100%;
	  height: 100px;
	  margin: auto;
	  background-color: #ffffff;
	}
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px;
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
