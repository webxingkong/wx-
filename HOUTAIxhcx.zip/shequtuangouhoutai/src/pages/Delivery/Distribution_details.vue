<template>
	<div class="Distribution_details" style="margin: 19px;">
		<el-tabs v-model="activeName">
			<div class="flex_lr_m headertitle" style="">
				<p style="margin-left:20px">基本信息</p>
				<div class="" style="margin-right:20px">
					<el-button type="primary" icon="el-icon-printer" size="mini">打印</el-button>
					<el-button type="primary" icon="el-icon-s-promotion" size="mini">导出</el-button>
				</div>
			</div>
			<div class="flex_lr">
				<div class="" style="width:50%">
					<ul>
						<li>配送单号：{{deliveryNoteInfo.delivery_number}}</li>
						<li>单据状态：{{deliveryNoteInfo.status}}</li>
						<li>签收时间：{{deliveryNoteInfo.sign_time}}</li>
						<li>发货日期：{{deliveryNoteInfo.deliver_goods_time}}</li>
					</ul>
				</div>
				<div class="" style="width:50%">
					<ul>
						<li>创建时间：{{deliveryNoteInfo.delivery_create_time}}</li>
						<li>店铺名称：{{deliveryNoteInfo.community_name}}</li>
						<li>发货时间：{{deliveryNoteInfo.deliver_goods_time}}</li>
						<li>收货地址：{{deliveryNoteInfo.community_address}}</li>
					</ul>
				</div>
			</div>
		 <el-tab-pane label="用户管理" name="second" style="margin-top:10px">
			 <el-table
	             ref="multipleTable"
	             :data="goods_info"
	             border
	             stripe
	             class="goods_table"
	             min-height="100%">
	             <el-table-column
	               prop="img_url"
	               label="商品图片"
	               align="center">
	               <!-- 图片的显示 -->
	                  <template   slot-scope="scope">
	                     <img :src="scope.row.img_url"  min-width="40" height="40" />
	                  </template>
	             </el-table-column>
	             <el-table-column
	               prop="goods_name"
	               label="商品名称"
	               align="center">
	             </el-table-column>
	             <el-table-column
	               prop="goods_desc"
	               label="描述"
	               align="center">
	             </el-table-column>
	             <el-table-column
	               prop="unit"
	               label="单位"
	               align="center">
	             </el-table-column>
	             <el-table-column
	               prop="stock_quantity"
	               label="预定数量"
	               align="center">
	             </el-table-column>
	             <el-table-column
	               prop="reserve_price"
	               label="预定单价"
	               align="center">
	             </el-table-column>
							 <el-table-column
	               prop="reserve_money"
	               label="预定金额"
	               align="center">
	             </el-table-column>
							 <el-table-column
	               prop="reserve_money"
	               label="缺货数量"
	               align="center">
	             </el-table-column>
							 <el-table-column
	               prop="reserve_money"
	               label="补货数量"
	               align="center">
	             </el-table-column>
							 <el-table-column
	               prop="reserve_money"
	               label="退货总量"
	               align="center">
	             </el-table-column>
	           </el-table>
						 <el-row :gutter="20">
  					 	<el-col :span="4">
								<div class="grid-content bg-purple flex_c_m">
									订单总价：<span></span>
								</div>
							</el-col>
							<el-col :span="4">
								<div class="grid-content bg-purple flex_c_m">
									商品金额：<span></span>
								</div>
							</el-col>
							<el-col :span="4">
								<div class="grid-content bg-purple flex_c_m">
									优惠金额：<span></span>
								</div>
							</el-col>
							<el-col :span="4">
								<div class="grid-content bg-purple flex_c_m">
									配送费：<span></span>
								</div>
							</el-col>
							<el-col :span="4">
								<div class="grid-content bg-purple flex_c_m">
									实付金额：<span></span>
								</div>
							</el-col>
							<el-col :span="4">
								<div class="grid-content bg-purple flex_c_m">
									退款金额：<span></span>
								</div>
							</el-col>
						</el-row>
						<div class="flex_lr_m headertitle" style="margin-bottom:30px">
							<p style="margin-left:20px">收获历史</p>
						</div>
						<el-table
		 	             ref="multipleTable"
		 	             :data="record"
		 	             border
		 	             stripe
		 	             class="goods_table"
		 	             min-height="100%">
		 	             <el-table-column
		 	               prop="operator"
		 	               label="操作人"
		 	               align="center">
		 	             </el-table-column>
		 	             <el-table-column
		 	               prop="operator_time"
		 	               label="时间"
		 	               align="center">
		 	             </el-table-column>
		 	             <el-table-column
		 	               prop="operator_type"
		 	               label="类型"
		 	               align="center">
		 	             </el-table-column>
		 	             <el-table-column
		 	               prop="operator_Record"
		 	               label="日志"
		 	               align="center">
		 	             </el-table-column>
		 	           </el-table>
		 </el-tab-pane>
		</el-tabs>
 </div>
</template>
<script>
    import axios from '../../axios.js';
    import https from "../../../api/https.vue"
    import Rootpath from "../../../api/index.js"
    import qs from '../../../node_modules/qs'
    export
    default {
        data() {
                return {
                    activeName: 'second',
                    deliveryNoteInfo: [],
										goods_info:[],
										record:[],
                };
            },
            mounted: function () {

            },
            created() {
                this.getData();
            },
            methods: {
                // 获取数据
                async getData() {
                    var routerParams = this.$route.query.delivery_number
                    const result = await axios.get(Rootpath.BASE_URL + 'deliveryNoteInfo?dn=' + routerParams);
                    this.deliveryNoteInfo = result.data.deliveryNoteInfo
										this.goods_info = result.data.deliveryNoteInfo.goods_info
										this.record=result.data.deliveryNoteInfo.record
                    console.log(result);
                },
            },
    };
</script>

<style scoped>
.Distribution_details{
	background: #ffffff;
}
.Distribution_details li{
	list-style: none;
	line-height: 40px
}
.Distribution_details .headertitle{
	height:30px;link-height:30px;background:#f5f5f5;width:95;margin:0 auto;

}
	.margin14{
		font-size:15px;
		margin-top:20px;
	}
</style>
