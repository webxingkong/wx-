<template>
  <div class="DistributionRoute-page">
    <el-tabs v-model="activeName">
<!-- 线路 -->
    <el-tab-pane label="线路" name="first">
      <div class="hearsearch">
        <el-form :inline="true" :model="formInline" class="flex_m hearbtn">
          <el-form-item label="时间" style="margin-left:2%"><el-input size="small" v-model="formInline.Name" style="width: 120px;"></el-input></el-form-item>
          <el-form-item><el-button size="small" type="primary">搜索</el-button></el-form-item>
        </el-form>
      </div>
      <div class="addbtn flex_m">
        <el-button size="mini" name="button" type="primary">新增</el-button>
      </div>

      <el-table
          :data="Distributionroute"
          stripe
          style="width: 100%;width: 96%;
          margin: 0 auto;">
          <el-table-column
            prop="id"
            align="center"
            label="线路ID">
          </el-table-column>
          <el-table-column
            prop="linename"
            align="center"
            label="线路名称">
          </el-table-column>
          <el-table-column
            prop="ordernumber"
            align="center"
            label="订单数">
          </el-table-column>
        <el-table-column
          prop="orderprice"
          align="center"
          label="订单金额">
        </el-table-column>
        <el-table-column
          prop="drivername"
          align="center"
          label="司机">
        </el-table-column>
        <el-table-column
          prop="driverphone"
          align="center"
          label="司机号码">
        </el-table-column>
        <el-table-column
          prop="regionnumber"
          align="center"
          label="区域数量">
        </el-table-column>
        <el-table-column
          prop="opentime"
          align="center"
          label="开通时间">
        </el-table-column>
        <el-table-column
          prop="address"
          align="center"
          label="操作">
          <el-button type="text" @click="dialogTableVisible = true">修改</el-button>
          <el-button type="text" @click="seedialog = true">区域管理</el-button>
           <el-button type="text" @click="delect ">删除</el-button>
        </el-table-column>
        </el-table>
    </el-tab-pane>

<!-- 线路订单列表 -->
    <el-tab-pane label="线路订单" name="second">
      <div class="hearsearch">
        <el-form :inline="true" :model="formInline" class="flex_m hearbtn">
          <el-form-item label="时间" style="margin-left:2%"><el-input size="small" v-model="formInline.Name" style="width: 120px;"></el-input></el-form-item>
          <el-form-item label="线路">
            <el-select v-model="form.region" size="small" class="flex_m hearbtn" placeholder="请选择活动区域">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item><el-button size="small" type="primary">搜索</el-button></el-form-item>
        </el-form>
      </div>
      <div class="addbtn flex_m">
        <el-button size="mini" name="button" type="primary">批量打印</el-button>
      </div>
      <el-table
          :data="Distributionroute"
          stripe
          style="width: 100%;width: 96%;
          margin: 0 auto;">
          <el-table-column
            prop="id"
            align="center"
            label="线路ID">
          </el-table-column>
          <el-table-column
            prop="linename"
            align="center"
            label="线路名称">
          </el-table-column>
          <el-table-column
            prop="ordernumber"
            align="center"
            label="订单数">
          </el-table-column>
        <el-table-column
          prop="orderprice"
          align="center"
          label="订单金额">
        </el-table-column>
        <el-table-column
          prop="drivername"
          align="center"
          label="司机">
        </el-table-column>
        <el-table-column
          prop="driverphone"
          align="center"
          label="司机号码">
        </el-table-column>
        <el-table-column
          prop="regionnumber"
          align="center"
          label="区域数量">
        </el-table-column>
        <el-table-column
          prop="opentime"
          align="center"
          label="开通时间">
        </el-table-column>
        <el-table-column
          prop="address"
          align="center"
          label="操作">
          <el-button type="text"  @click="dialogVisible = true">修改</el-button>
          <el-button type="text" @click="seedialog = true">区域管理</el-button>
           <el-button type="text" @click="seedialog = true">删除</el-button>
        </el-table-column>
        </el-table>

    </el-tab-pane>

    <!-- 编辑弹出框 -->
    <el-dialog title="编辑区域" class="layoutbox" :visible.sync="dialogTableVisible">
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item class="leftlabel" label="区域名称：" prop="name"><el-input class="inputtext" v-model="ruleForm.name"></el-input></el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogTableVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogTableVisible = false">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 编辑弹出框  结束-->
  </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      activeName: 'first',
      Distributionroute:[],
      dialogTableVisible:false,
      formInline: {
				user: '',
				region: '',
				Name: '',
				times: '',
				Mobilephone: '',
				Names: ''
			},
      form: {
          region: '',
        },
        ruleForm: {
  				name: '',
  				region: '',
  				date1: '',
  				date2: '',
  				delivery: false,
  				type: [],
  				resource: '',
  				desc: ''
  			},
  			rules: {
  				name: [{ required: true, message: '请输入活动名称', trigger: 'blur' }, { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }],
  				region: [{ required: true, message: '请选择活动区域', trigger: 'change' }],
  				date1: [{ type: 'date', required: true, message: '请选择日期', trigger: 'change' }],
  				date2: [{ type: 'date', required: true, message: '请选择时间', trigger: 'change' }],
  				type: [{ type: 'array', required: true, message: '请至少选择一个活动性质', trigger: 'change' }],
  				resource: [{ required: true, message: '请选择活动资源', trigger: 'change' }],
  				desc: [{ required: true, message: '请填写活动形式', trigger: 'blur' }]
  			}

    }
  },
  methods:{
    handleClick(tab, event) {
        console.log(tab, event);
      },
      edit(index,row){
        console.log("??");
      },
      async getData() {
  				const result = await axios.get(Rootpath.BASE_URL + 'path/DistributionRoute');
  				console.log(result);
          this.Distributionroute = result.data.Distributionroute;
          this.total = result.data.Distributionroute.length;
  		},
      delect(index,row){
        this.$confirm('确认删除本条记录?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });
      }
  },
  created() {
    this.getData();
  },
};
</script>
<style scoped>
.DistributionRoute-page{
  background: #ffffff;
  width: 95%;
  margin: 0 auto;
}
.DistributionRoute-page .el-tabs__nav{
  left: 20px;
}
.DistributionRoute-page .el-tabs__header{
  background: #ffffff;
  margin-top: 50px;
}
.DistributionRoute-page .el-form-item{
  margin-bottom: 0 !important;
}
.DistributionRoute-page .hearsearch{
    background: #F5F5F5;
    width: 96%;
    margin: 0 auto;
  }
  .DistributionRoute-page .hearbtn{
    line-height: 60px
  }
  .DistributionRoute-page .el-form-item__content{
    line-height:60px
  }
  .DistributionRoute-page .addbtn{
    height: 60px;
    width: 96%;
    margin: 0 auto;
  }

  .DistributionRoute-page .layoutbox {
  	width: 50%;
  	margin: 0 auto;
  }
  .DistributionRoute-page .el-dialog {
  	border-radius: 6px !important;
  }
  .DistributionRoute-page .inputtext {
  	width: 75%;
  }
  /* .leftlabel label{
    width: 100px !important;
  } */
  .DistributionRoute-page .el-dialog__header {
  	border-bottom: 1px solid #d8d8d8;
  }
  .DistributionRoute-page .el-dialog__footer {
  	border-top: 1px solid #d8d8d8;
  }

</style>
