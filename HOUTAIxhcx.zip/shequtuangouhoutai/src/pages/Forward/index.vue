<template>
	<div class="select">
		<div class="select-table">
			<el-tabs v-model="activeName" @tab-click="handleClick">
				<!--每日精选-->
				<el-tab-pane label="每日精选" name="first">
					<br />
					<el-col :span="24">
						<div class="grid">
							<span class=" text1">每日精选海报分享功能：</span>
							<el-switch v-model="value" active-color="#436BE5" inactive-color="#CCCCCC"></el-switch>
							&emsp;
							<div class="block"><el-button size="small" type="primary" class="block">更新海报</el-button></div>
						</div>
					</el-col>

					<br />
					<br />
					<el-button size="small" type="primary" @click="dialogTableVisible = true">选择商品</el-button>
					<br />
					<el-table :data="tableData" style="width: 100%">
						<el-table-column prop="date" label="序号"></el-table-column>
						<el-table-column prop="name" label="商品名称"></el-table-column>
						<el-table-column prop="Company" label="单位"></el-table-column>
						<el-table-column prop="address" label="划线价"></el-table-column>
						<el-table-column prop="address" label="售价"></el-table-column>
						<el-table-column fixed="right" label="操作" width="120">
							<template slot-scope="scope">
								<el-button type="text" size="small">上移</el-button>
								<el-button type="text" size="small">下移</el-button>
								<el-button type="text" size="small">编辑</el-button>
							</template>
						</el-table-column>
					</el-table>
					<br />
					<br />
					<el-button size="small">取消</el-button>
					<el-button size="small" type="primary">保存</el-button>
					<br><br>
				</el-tab-pane>
				<!--分享订单-->
				<el-tab-pane label="分享订单" name="second">
					<div class="frame">
						分享订单:
						<el-input v-model="input" placeholder="请输入内容" style="width: 240px;"></el-input>
						<br />
						<br />
						转发分享图片：
						<el-radio v-model="radio" label="1">商品主图</el-radio>
						<el-radio v-model="radio" label="2">自定义图片</el-radio>
						<br />
						<br />
						<br />
						<div><img src="https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg" width="240px" height="240px" /></div>
						<br />
						<br />
					</div>
					<el-button size="small" type="primary">保存</el-button>
					<br />
					<br />
				</el-tab-pane>
			</el-tabs>
		</div>
		<!--选择商品弹窗-->
		<el-dialog title="请选择商品" :visible.sync="dialogTableVisible" width="60%">
			<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				<el-form-item label="状态">
					<el-select size="small" v-model="values" placeholder="请选择" style=" width: 120px;">
						<el-option v-for="item in options" :key="item.values" :label="item.label" :value="item.values"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="商品名称"><el-input size="small" v-model="formInline.goodsname" style="width: 120px;"></el-input></el-form-item>
				<el-form-item label="编码"><el-input size="small" v-model="formInline.goodscode" style="width: 120px;"></el-input></el-form-item>
				<el-form-item label="分类"><el-input size="small" v-model="formInline.goodscode" style="width: 120px;"></el-input></el-form-item>

				<el-form-item><el-button size="small" type="primary">搜索</el-button></el-form-item>
			</el-form>
			<!--表单-->
			<el-table ref="multipleTable" :data="gridData" tooltip-effect="dark" style="width: 100%">
				<el-table-column type="selection" width="55"></el-table-column>
				<el-table-column prop="name" label="商品图片" ></el-table-column>
				<el-table-column prop="code" label="商品名称" ></el-table-column>
				<el-table-column prop="Company" label="单位" ></el-table-column>
				<el-table-column prop="url" label="商城价" ></el-table-column>

				<el-table-column fixed="right" label="操作" width="60">
					<template slot-scope="scope">
						<el-button type="text" size="small">添加</el-button>
					</template>
				</el-table-column>
			</el-table>
			<br />
			<br />
			<!--分页-->
			<el-pagination
				class="block"
				background
				@size-change="handleSizeChange"
				@current-change="handleCurrentChange"
				:current-page="currentPage"
				:page-sizes="[5, 10, 20, 50]"
				:page-size="pagesize"
				layout="total, sizes, prev, pager, next, jumper"
				:total="total"
			></el-pagination>
			<br />
			<div style="text-align: right;"><el-button size="small" type="primary">选择</el-button></div>
		</el-dialog>
	</div>
</template>

<script>
export default {
	data() {
		return {
			activeName: 'first',
			value: true,
			radio: '1',
			input: '',
			tableData: [
				{
					date: '02',
					name: '',
					Company: '500g',
					
				},
				{
					date: '04',
					name: '九煲粥',
					Company: '500g'
				},
				{
					date: '01',
					name: '黑米粥',
					Company: '500g'
				},
				{
					date: '03',
					name: '白米粥',
					Company: '500g'
				}
			],
			gridData: [
				{
					name: '八宝粥',
					code: 'SFS65986',
					Company: '盒',
					class: '饮品',
					Warehouse: '默认',
					Price: '￥12.0',
					Stock: '500'
				},
				{
					name: '八宝粥',
					code: 'SFS65986',
					Company: '盒',
					class: '饮品',
					Warehouse: '默认',
					Price: '￥12.0',
					Stock: '500'
				},
				{
					name: '八宝粥',
					code: 'SFS65986',
					Company: '盒',
					class: '饮品',
					Warehouse: '默认',
					Price: '￥12.0',
					Stock: '500'
				},
				{
					name: '八宝粥',
					code: 'SFS65986',
					Company: '盒',
					class: '饮品',
					Warehouse: '默认',
					Price: '￥12.0',
					Stock: '500'
				}
			],
			dialogTableVisible: false,
			formInline: {
				user: '',
				region: '',
				Name: '',
				times: '',
				Mobilephone: '',
				Names: '',
				states: '',
				state: ''
			},
			options: [
				{
					values: '选项1',
					label: '黄金糕'
				},
				{
					values: '选项2',
					label: '双皮奶'
				},
				{
					values: '选项3',
					label: '蚵仔煎'
				},
				{
					values: '选项4',
					label: '龙须面'
				},
				{
					values: '选项5',
					label: '北京烤鸭'
				}
			],
			values: ''
		};
	},
	methods: {
		handleClick(tab, event) {
			console.log(tab, event);
		},
		//分页
		handleSizeChange(size) {
			this.pagesize = size;
		},
		handleCurrentChange(currentPage) {
			this.currentPage = currentPage;
		}
	}
};
</script>

<style scoped>
.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select {
	margin: auto;
	width: 96%;
	background-color: #ffffff;
}
.text1 {
	font-size: 13px;
}
.block {
	text-align: right;
	margin-top: -15px;
}
.frame {
	width: 400px;
	height: 100%;
	text-align: right;
}
</style>
