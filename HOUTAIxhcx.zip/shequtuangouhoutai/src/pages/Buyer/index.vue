<template>
	<div class="select Buyer-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="采购员" name="first"></el-tab-pane></el-tabs>

			<div class="search">
				<!---->
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
					<el-form-item label="采购员" style="margin-top: 20px;"><el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input></el-form-item>
					<el-form-item label="编号" style="margin-top: 20px;"><el-input size="small" v-model="formInline.region" style="width: 120px;"></el-input></el-form-item>
					<el-form-item label="联系方式" style="margin-top: 20px;"><el-input size="small" v-model="formInline.states" style="width: 120px;"></el-input></el-form-item>
					&emsp;

					<el-form-item><el-button size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button></el-form-item>
				</el-form>
				<!---->
			</div>
			<br />
			<br />
			<el-button @click="addfrom = true" size="small" type="primary">新增采购员</el-button>
			<br /><div class="right"><el-button size="medium">导出查询结果</el-button></div>

			<br />
			<el-table ref="multipleTable" :data="purchaseman_list.slice((currentPage-1)*pagesize,currentPage*pagesize)" tooltip-effect="dark" style="width: 100%">
				<el-table-column type="selection" width="55"></el-table-column>
				<el-table-column label="编号" width="240">
					<template slot-scope="scope">
						{{ scope.row.purchaser_number }}
					</template>
				</el-table-column>
				<el-table-column prop="purchaseman_name" label="采购员" width="200"></el-table-column>
				<el-table-column prop="mobile_phone" label="联系方式" ></el-table-column>

				<el-table-column fixed="right" label="操作" width="135">
					<template slot-scope="scope">
						<el-button @click="getdetails(scope.row)" type="text" size="small">详情</el-button>
						<el-button @click="editinforow(scope.row)" type="text" size="small">编辑</el-button>
						<el-button type="text" size="small" @click="deleterow(scope.$index, purchaseman_list)">删除</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!--分页-->
			<el-pagination class="pagination"
					background
					@size-change="handleSizeChange"
					@current-change="handleCurrentChange"
					:current-page="currentPage"
					:page-sizes="[5, 10, 20, 50]"
					:page-size="pagesize"
					layout="total, sizes, prev, pager, next, jumper"
					:total="total">
				</el-pagination>
			<br />
		</div>
		<!--新增-->
		<el-dialog title="新增采购员" :visible.sync="addfrom" width="36%">
			<el-form>
				<el-form-item label="采购员名称:" :label-width="formLabelWidth"><el-input v-model="addinfo.purchaseman_name" autocomplete="off"></el-input></el-form-item>
			<el-form-item label="联系 手机:" :label-width="formLabelWidth"><el-input v-model="addinfo.mobile_phone" autocomplete="off"></el-input></el-form-item>
			<el-form-item label="密码:" :label-width="formLabelWidth"><el-input v-model="addinfo.pwd" autocomplete="off"></el-input></el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="addfrom = false">取消</el-button>
				<el-button type="primary" @click="addrowinfo">保存</el-button>
			</div>
		</el-dialog>
		<!--编辑-->
		<el-dialog title="采购员编辑" :visible.sync="editfrom" width="36%">
			<el-form>
				<el-form-item label="采购员名称:" :label-width="formLabelWidth"><el-input v-model="editinfo.purchaseman_name" autocomplete="off"></el-input></el-form-item>
			<el-form-item label="联系 手机:" :label-width="formLabelWidth"><el-input v-model="editinfo.mobile_phone" autocomplete="off"></el-input></el-form-item>
			<el-form-item label="密码:" :label-width="formLabelWidth"><el-input v-model="editinfo.pwd" autocomplete="off"></el-input></el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="editfrom = false">取消</el-button>
				<el-button type="primary" @click="editrowinfo">保存</el-button>
			</div>
		</el-dialog>
		<!--详情-->
		<el-dialog title="采购员详情" :visible.sync="detailsfrom" width="36%">
			<el-form>
				<el-form-item label="采购员名称:" :label-width="formLabelWidth"><el-input :disabled="true" v-model="detailsinfo.purchaseman_name" autocomplete="off"></el-input></el-form-item>
			<el-form-item label="联系 手机:" :label-width="formLabelWidth"><el-input :disabled="true" v-model="detailsinfo.mobile_phone" autocomplete="off"></el-input></el-form-item>
			<el-form-item label="密码:" :label-width="formLabelWidth"><el-input :disabled="true" v-model="detailsinfo.pwd" autocomplete="off"></el-input></el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">

				<el-button type="primary" @click="detailsfrom = false">返回</el-button>
			</div>
		</el-dialog>
	</div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			dialogTableVisible: false,
			addfrom: false,
			editfrom: false,
			detailsfrom: false,
			detailsinfo:[],
			addinfo:{
				company_id: null,
				purchaseman_name:'',
				mobile_phone:'',
				pwd:''
			},
			editinfo:{
				company_id: null,
				purchaseman_name:'',
				mobile_phone:'',
				pwd:''
			},
			total: 0,
			currentPage: 1,
			pagesize: 5,
			formLabelWidth: '150px',
			activeName: 'first',
			purchaseman_list: [],
			formInline: {
				user: '',
				region: '',
				states: '',
				times: ''
			},


		};
	},
	created() {
			this.getData();
			// this.integrlist();
	},
methods: {
			onSubmit() {
					console.log('submit!');
				},
				toggleSelection(rows) {
					if (rows) {
						rows.forEach(row => {
							this.$refs.multipleTable.toggleRowSelection(row);
						});
					} else {
						this.$refs.multipleTable.clearSelection();
					}
				},
					//分页
					handleSizeChange(size) {
					  this.pagesize = size;
					},
					handleCurrentChange(currentPage) {
					  this.currentPage = currentPage;
					},
					// 获取数据
		      async getData() {
		          const result = await axios.get(Rootpath.BASE_URL + 'purchasemanList');
		          console.log(result);
							this.purchaseman_list=result.data.purchaseman_list;
		          this.total = result.data.purchaseman_list.length;
		      },
					//新增
					async addrowinfo() {

						let that=this;
						that.addfrom = true;
						axios.post(Rootpath.BASE_URL + 'addpurchasemanInfo', {
            company_id: 1,
            purchaseman_name: that.addinfo.purchaseman_name,
            mobile_phone: that.addinfo.mobile_phone,
            pwd: that.addinfo.pwd
        })
        .then(function (response) {
            that.addfrom = false
        })
        .catch(function (error) {
            console.log(error);
        });
		      },
					//编辑
					async editrowinfo(row) {

						let that=this;
						that.editfrom = true;
						axios.post(Rootpath.BASE_URL + 'editpurchasemanInfo', {
            company_id: 1,
            purchaseman_name: that.editinfo.purchaseman_name,
            mobile_phone: that.editinfo.mobile_phone,
            pwd: that.editinfo.pwd
        })
        .then(function (response) {
            that.editfrom = false
        })
        .catch(function (error) {
            console.log(error);
        });
		      },
					//详情
					async getdetails(row) {
						this.detailsfrom = true
						const result = await axios.get(Rootpath.BASE_URL + 'purchasemanInfo?pn='+row.purchaser_number);
						this.detailsinfo=result.data;
		      },
					//详情
					async editinforow(row) {
						console.log(row);
						this.editfrom = true;
						this.editinfo.purchaseman_name=row.purchaseman_name;
            this.editinfo.mobile_phone=row.mobile_phone;
            this.editinfo.pwd=row.pwd;
		      },
					//删除
					deleterow(index,row){
						row.splice(index, 1);
					},
			}
	//冻结
};
</script>

<style scoped>
	.block{
		text-align: right;
	}
.footer {
	height: 44px;
	text-align: right;
}
.right {
	text-align: right;
	margin-top: -33px;
}

p {
	position: relative;
	top: -12px;
}
.text {
	display: flex;
	left: 20px;
	position: relative;
	top: 15px;
}

h3 {
	color: #436be5;
	border-bottom: solid 2px #436be5;
	margin-left: 20px;
}
.text-frame-member {
	width: 100px;
	position: relative;
	top: 10px;
}
.text-frame {
	height: 50px;
	width: 100%;
	background-color: #ffffff;
	border-bottom: solid 1px #f0f2f0;
}

.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select {
	margin: auto;
	width: 96%;
	background-color: #ffffff;
} /*border: solid 1rpx #007AFF;
*/
.search {
	height: 70px;
	background-color: #f5f5f5;
}
.search-Button {
	margin-left: 20px;
}
</style>
