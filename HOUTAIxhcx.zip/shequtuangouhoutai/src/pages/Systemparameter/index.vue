<template lang="html">
  <div class="Systemparameter">
    <el-tabs v-model="activeName">
<!-- 区域 -->
    <el-tab-pane label="小程序配置" name="first">
      <div class="flex" style="margin-left:20px;line-height:40px">
        <span style="font-weight:bold;">总平台配置</span>
        <span style="margin-left:100px;font-size:14px">企业转账至团长微信
          <el-switch
            v-model="carryswitch">
          </el-switch>
        </span>
      </div>
      <div class="">
        <el-col :span="12" style="height:550px" class="">
          <div class="fromtitle" style="border-bottom:1px solid #f0f2f0;font-weight:bold;">
            商城端小程序配置
          </div>
          <div class="fromblock">
            <el-form label-width="150px" ref="shopping" :model="shopping" class="demo-ruleForm">
              <el-form-item label="团长小程序名称：" class="leftlabeltext">
                <el-input v-model="shopping.ports_name"></el-input>
              </el-form-item>
              <el-form-item label="小程序appid：" class="leftlabeltext">
                <el-input :disabled="true"  v-model="shopping.appid"></el-input>
              </el-form-item>
              <el-form-item label="小程序appsecret：" class="leftlabeltext">
                <el-input v-model="shopping.appsecret"></el-input>
              </el-form-item>
              <el-form-item label="小程序商户号：" class="leftlabeltext">
                <el-input :disabled="true"  v-model="shopping.merchant_number"></el-input>
              </el-form-item>
              <el-form-item label="小程序密匙：" class="leftlabeltext">
                <el-input v-model="shopping.secret_key"></el-input>
              </el-form-item>
            </el-form>
          </div>
        </el-col>
        <el-col :span="12" style="height:350px" class="">
          <div class="fromtitle" style="border-bottom:1px solid #f0f2f0;font-weight:bold;">
            团长端小程序配置
          </div>
          <div class="fromblock">
            <el-form label-width="150px" ref="commander" :model="commander" class="demo-ruleForm">
              <el-form-item label="商城小程序名称：" class="leftlabeltext">
                <el-input v-model="commander.ports_name"></el-input>
              </el-form-item>
              <el-form-item label="小程序appid：" class="leftlabeltext">
                <el-input :disabled="true"  v-model="commander.appid"></el-input>
              </el-form-item>
              <el-form-item label="小程序appsecret：" class="leftlabeltext">
                <el-input v-model="commander.appsecret"></el-input>
              </el-form-item>
              <el-form-item label="小程序商户号："  v-if="carryswitch==true" class="leftlabeltext">
                <el-input :disabled="true"  v-model="commander.merchant_number"></el-input>
              </el-form-item>
              <el-form-item label="小程序密匙：" v-if="carryswitch==true" class="leftlabeltext">
                <el-input v-model="commander.secret_key"></el-input>
              </el-form-item>
            </el-form>
          </div>
        </el-col>
        <el-button type="primary" size="small" name="button" @click="save">保存</el-button>
      </div>
    </el-tab-pane>


  </el-tabs>
  </div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      activeName: 'first',
      carryswitch:false,
      shopping:{},
      commander:{},
      update:[],
      program_list:[],
    }
  },
  created() {
    this.getData();
  },
  methods:{
    // 获取数据
    async getData() {
      const result = await axios.get(Rootpath.BASE_URL + 'small_program');
      this.program_list=result.data.program_list;
      this.shopping=result.data.program_list[0];
      this.commander=result.data.program_list[1];
    },
    save() {
      let that = this;
      axios.post(Rootpath.BASE_URL + 'program_edit', {
              update: that.program_list,
          })
          .then(function (response) {
              console.log(response);
          })
          .catch(function (error) {
              console.log(error);
          });

    },
  }
}
</script>

<style lang="css">
.Systemparameter{
  background: #ffffff;
  width: 96%;
  margin: 0 auto;
  min-height: 800px;
  margin-top: 30px;
}
.el-tabs__nav{
  margin-left: 20px;
}
.leftlabeltext input{
  width: 50%;
}
.fromtitle{
  margin-left: 20px;
  margin-top: 20px;
}
.fromblock{
  margin-top: 30px;
  margin-left:80px;
}
</style>
