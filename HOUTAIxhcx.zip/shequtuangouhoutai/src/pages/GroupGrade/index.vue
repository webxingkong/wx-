<template>
  <div class="GroupGrade-page" style="margin: 20px;">
	  <el-tabs v-model="activeName">
	     <el-tab-pane label="团长等级" name="first">
			 <el-button size="small" type="primary" @click="addlayout = true">新增</el-button>
					<div class="right">
					<el-button size="medium">导出查询结果</el-button>
					</div>
					<div><!-- 弹层 -->
									 <el-dialog
									   title="新增等级"
									   :visible.sync="addlayout"
									   width="600px">
									 <div> 等级名称:<el-input style="width:80%;padding-left: 10px;" v-model="addfrom.level_name"></el-input></div>
									 <div> 升级条件：销售额累计达到<el-input v-model="addfrom.upgrade" style="width:45%;margin: 15px 0px;padding-left: 10px;"></el-input>元可以自动升级</div>
									  <div>佣金比例：<el-input placeholder="%"  style="width:80%;padding-left: 10px;" v-model="addfrom.commission"></el-input></div>
									  <span slot="footer" class="dialog-footer">
									    <el-button @click="addlayout = false">取 消</el-button>
									    <el-button type="primary" @click="addsave()">确 定</el-button>
									  </span>
									 </el-dialog>
					</div>

          <el-dialog
            title="编辑等级"
            :visible.sync="editlayout"
            width="600px">
          <div> 等级名称:<el-input style="width:80%;padding-left: 10px;" v-model="editfrom.level_name"></el-input></div>
          <div> 升级条件：销售额累计达到<el-input v-model="editfrom.upgrade" style="width:45%;margin: 15px 0px;padding-left: 10px;"></el-input>元可以自动升级</div>
           <div>佣金比例：<el-input placeholder="%"  style="width:80%;padding-left: 10px;" v-model="editfrom.commission"></el-input></div>
           <span slot="footer" class="dialog-footer">
             <el-button @click="editlayout = false">取 消</el-button>
             <el-button type="primary" @click="editsave()">确 定</el-button>
           </span>
          </el-dialog>
					<div>
						<el-table
						    :data="grade_list.slice((currentPage-1)*pagesize,currentPage*pagesize)"
						    stripe
						    style="width:100%">
						    <el-table-column
							align="center"
						      prop="level_name"
						      label="团长等级">
						    </el-table-column>
						    <el-table-column
							align="center"
						      prop="commission"
						      label="佣金比例">
						    </el-table-column>
							<el-table-column
							align="center"
							  prop="address"
							  label="操作">
							  <template slot-scope="scope">
							  	        <el-button @click="editrow(scope.row)" type="text" size="small">编辑</el-button>
							  	        <el-button type="text" size="small" @click="deletedata(scope.$index)">删除</el-button>
							  	      </template>
							  	    </el-table-column>
							  </el-table>
							</el-table-column>
						  </el-table>
              <!--分页-->
        			<el-pagination class="pagination"
        					background
        					@size-change="handleSizeChange"
        					@current-change="handleCurrentChange"
        					:current-page="currentPage"
        					:page-sizes="[5, 10, 20, 50]"
        					:page-size="pagesize"
        					layout="total, sizes, prev, pager, next, jumper"
        					:total="total">
        				</el-pagination>
					</div>
		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  name: 'first',
  components: {},
   data() {
        return {
			 activeName: 'first',
       total: 0,
 			currentPage: 1,
 			table_index: 999,
 			pagesize: 5,
			 addlayout: false,
       editlayout:false,
       addfrom:{
         company_id:'',
         level_name:'',
         upgrade:'',
         commission:''
       },
       editfrom:{
         id:null,
         level_name:'',
         upgrade:'',
         commission:''
       },
			 el_inputname:'',
			 el_inputCommission:'',
			  formInline: {
			           user: '',
			           region: ''
			         },
			  num: 1,
          grade_list: [],
        }
      },
      created() {
          this.getData();
          // this.integrlist();
      },
	   methods: {
	        handleChange(value) {
	          console.log(value);
	        },
          handleSizeChange(size) {
            this.pagesize = size
          },
          handleCurrentChange(currentPage) {
            this.currentPage = currentPage
          },
          //添加
          async addsave(index) {
            let that = this;
            let data = {
              company_id: 1,
              level_name: 2,
              upgrade: 3,
              commission : 4
            };
            axios.post(Rootpath.BASE_URL + 'rank_add',data)
            .then(res=>{
              console.log('res=>',res);
            })
            // axios.post(Rootpath.BASE_URL + 'rank_add', {
            //         company_id: that.addfrom.company_id,
            //         level_name: that.addfrom.level_name,
            //         upgrade: that.addfrom.upgrade,
            //         commission: that.addfrom.commission
            //             // data:that.form
            //     })
            //     .then(function (response) {
            //         that.addlayout = false;
            //         console.log(company_id);
            //     })
            //     .catch(function (error) {
            //         console.log(error);
            //     });
    },
    //修改
      editsave(){
        let that = this;
        let data = {
          id: that.editfrom.id,
          level_name: that.editfrom.level_name,
          upgrade:that.editfrom.upgrade,
          commission:that.editfrom.commission
        };
        axios.post(Rootpath.BASE_URL + 'rank_doedit?id='+that.editfrom.id+'&level_name='+that.editfrom.level_name+'&upgrade='+that.editfrom.upgrade+'&commission='+that.editfrom.commission)
        .then(res => {
            console.log(res);
            // that.editlayout=false;
        })
        .catch(err => {
            console.log(err);
        })
      },
      //获取点击修改数据
      editrow(row) {
  			console.log(row);
        this.editlayout=true;
        let that = this;
        that.editfrom.id=row.id;
        axios.get(Rootpath.BASE_URL + 'rank_edit', {
                params: {
                    id: row.id
                }
            })
            .then(function (response) {
                that.editfrom.level_name=response.data.level_name;
                that.editfrom.upgrade=response.data.upgrade;
                that.editfrom.commission=response.data.commission;
            })
            .catch(function (error) {
                console.log(error);
            });
  		},
			 onSubmit() {
			     console.log('submit!');
			 },//删除下标操作,index接受的是删除的下标
			deletedata(index){
					  this.grade_list.splice(index,1);
			},
          // 获取数据
      async getData() {
          const result = await axios.get(Rootpath.BASE_URL + 'rank_list');
          console.log(result);
          this.grade_list = result.data.grade_list
        	this.total = result.data.grade_list.length
      },
	      }
};
</script>
<style scoped>
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px;
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
