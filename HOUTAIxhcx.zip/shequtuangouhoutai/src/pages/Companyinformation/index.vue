<template lang="html">
  <div class="Companyinformation">
    <div class="">
      <el-form label-width="180px" class="demo-ruleForm">
        <el-form-item label="平台名称：" class="leftlabeltext"  style="padding-top:30px">
          <el-input style="width:50%"></el-input>
          <el-button type="primary" name="button" size="small" style="float:right;margin-right:50px">重新生成二维码</el-button>
        </el-form-item>
        <el-form-item label="客服电话：" class="leftlabeltext">
          <el-input style="width:50%"></el-input>
        </el-form-item>
        <el-form-item label="商城LOGO：" class="leftlabeltext">
          <el-col :span="6">
            <el-upload
              class="avatar-uploader"
              action="https://jsonplaceholder.typicode.com/posts/"
              :show-file-list="false"
              :on-progress="uploading"
              :on-success="handleAvatarSuccess">
              <img v-if="imageUrl" :src="imageUrl" class="avatar">
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-col>
          <el-col :span="8" style="height:150px" class="flex_m">
            <el-button type="primary" icon="el-icon-upload" size="small" style="">上传</el-button>
            <span style="margin-left:20px">建议尺寸(300*300px)</span>
          </el-col>


        </el-form-item>
        <el-form-item label="后台系统LOGO：" class="leftlabeltext">
          <el-col :span="6">
            <el-upload
              class="avatar-uploader"
              action="https://jsonplaceholder.typicode.com/posts/"
              :show-file-list="false"
              :on-progress="uploading"
              :on-success="handleAvatarSuccess">
              <img v-if="imageUrl" :src="imageUrl" class="avatar">
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-col>
          <el-col :span="8" style="height:150px" class="flex_m">
            <el-button type="primary" icon="el-icon-upload" size="small" style="">上传</el-button>
            <span style="margin-left:20px">建议尺寸(300*300px)</span>
          </el-col>
        </el-form-item>
        <el-form-item class="leftlabeltext">
          <el-button type="primary" @click="" size="small">保存</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
export default {
  data(){
    return{
      imageUrl:'',
    }
  },
  created() {
    this.getData();
  },
  methods:{
    uploading(event, file, fileList){
      // let this=that;
      axios.post(Rootpath.BASE_URL + 'UpOssImage', {
            img_file:file
        })
        .then(function (response) {
            console.log(response);
            // that.addinfo.project_logo=response.
        })
        .catch(function (error) {
            console.log(error);
        });
    },
    handleAvatarSuccess(res, file) {
      this.imageUrl = URL.createObjectURL(file.raw);
    },
  }
}
</script>

<style lang="css">
.Companyinformation{
  background: #ffffff;
  width: 96%;
  margin: 0 auto;
  min-height: 800px;
  margin-top: 30px;
}
</style>
