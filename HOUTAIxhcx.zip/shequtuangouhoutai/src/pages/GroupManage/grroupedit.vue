<template>
    <div class="grroupedit-page" style="margin: 20px;">
        <el-tabs v-model="activeName">


            <el-tab-pane label="团长管理" class="eltabpane" name="second">
                <!-- 自定义地图弹层 -->
                <el-form ref="fromdata" :model="fromdata" label-width="180px" style="height:100% !important">
                    <div class="title_text" style="width:97%;margin:0 auto;background:#f5f5f5;line-height:40px">
                        <span>基本信息</span>
                    </div>
                    <el-form-item label="团长账号：" style="margin-top:15px;">
                        <el-input v-model="leader_info.leader_number" size="mini"></el-input>
                    </el-form-item>
                    <el-form-item label="店铺名称：" style="margin-top:15px;">
                        <el-input v-model="leader_info.community_name" size="mini"></el-input>
                    </el-form-item>
                    <el-form-item label="团长编码：" style="margin-top:15px;">
                        <el-input v-model="leader_info.leader_coding" size="mini"></el-input>
                    </el-form-item>
                    <el-form-item label="团长等级：" style="margin-top:15px;">
                        <!-- <el-input v-model="form.name" size="mini"></el-input> -->
                        <el-select size="mini" v-model="leader_info.level_name" placeholder="请选择">
                            <el-option v-for="item in leader_info" :key="item.level_names" :label="item.level_name" :value="item.level_name">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <!-- <el-form-item label="销售员：" style="margin-top:15px;">
            <el-input v-model="fromdata.name" size="mini"></el-input>
          </el-form-item>
          <el-form-item label="推荐人：" style="margin-top:15px;">
            <el-input v-model="fromdata.name" size="mini"></el-input>
          </el-form-item> -->
                    <div class="title_text" style="width:97%;margin:0 auto;background:#f5f5f5;line-height:40px">
                        <span>财务信息</span>
                    </div>
                    <el-form-item label="开户银行：" style="margin-top:15px;">
                        <el-input v-model="bank_info.open_bank" size="mini"></el-input>
                    </el-form-item>
                    <el-form-item label="账户名称：" style="margin-top:15px;">
                        <el-input v-model="bank_info.account_name" size="mini"></el-input>
                    </el-form-item>
                    <el-form-item label="账户账号：" style="margin-top:15px;">
                        <el-input v-model="bank_info.account_number" size="mini"></el-input>
                    </el-form-item>
                    <el-form-item label="汇付账号：" style="margin-top:15px;">
                        <el-input v-model="bank_info.account_remit" size="mini"></el-input>
                    </el-form-item>
                    <div class="title_text" style="width:97%;margin:0 auto;background:#f5f5f5;line-height:40px">
                        <span>收货信息</span>
                    </div>
                    <el-form-item label="团长名称：" style="margin-top:15px;">
                        <el-input v-model="leader_info.leader_name" size="mini"></el-input>
                    </el-form-item>
                    <el-form-item label="团长手机：" style="margin-top:15px;">
                        <el-input v-model="leader_info.mobile" size="mini"></el-input>
                    </el-form-item>
                    <el-form-item label="社区店地址：" size="mini" style="margin-top:15px;">
                        <!-- <el-input v-model="form.name" size="mini"></el-input> -->
                        <el-cascader :options="selectedlist" v-model="selectedOptions" @change="handleChange">
                        </el-cascader>
                    </el-form-item>
                    <el-form-item label="详细地址：" style="margin-top:15px;">
                        <!-- <el-input v-model="form.name" size="mini"></el-input> -->
                        <el-input v-model="postition" size="mini" id="leadeaddresss"></el-input>
                        <el-button type="primary" @click="alertpostiton()" size="mini" style="margin-left:10px">设置经纬度</el-button>
                    </el-form-item>
                    <el-form-item label="区域：" style="margin-top:15px;">
                        <!-- <el-input v-model="form.name" size="mini"></el-input> -->
                        <el-select v-model="value" size="mini" placeholder="请选择">
                            <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="配送方式：" style="margin-top:15px;">
                        <el-radio-group v-model="erdiolabel">
                          <el-radio label="1">跟随全局设定</el-radio>
                          <el-radio label="2">单独设定配送方式</el-radio>
                        </el-radio-group>
                    </el-form-item>

                    <el-form-item label="" style="margin-top:15px;">
                        <!-- <el-input v-model="bank_info.account_number" size="mini"></el-input> -->
                        <el-button type="primary" size="mini" @click="saveback">保存</el-button>
                        <el-button size="mini" @click="determines()">取消</el-button>
                    </el-form-item>

                </el-form>
                <div class="layertopostition" v-show="ifshow">
                    <div>
                        <hr />
                        <input id="tipinput" placeholder="请输入搜索地址" />
                        <!--搜索输入框-->
                        <div id="container" class="map"></div>
                        <!--地图-->
                        <hr />
                        <el-input id='lnglat' type="text" value='116.39,39.9' style="width:170px;padding-right:5px;"></el-input>
                        <!--经纬度输入框-->
                        <font style="color:#5a5b5d">当前选择地址:</font>
                        <el-input id='address' type="text" style="width:400px;padding-right:50px;" v-model="postition" placeholder="请选择位置"></el-input>
                        <!--详细地址输入框-->
                        <el-button @click="ifshow = false">取 消</el-button>
                        <el-button type="primary" @click="determines()">确 定</el-button>
                    </div>
                </div>


            </el-tab-pane>

        </el-tabs>
    </div>
    </div>
</template>
<script>
    import axios from '../../axios.js';
    import https from "../../../api/https.vue"
    import Rootpath from "../../../api/index.js"
    export
    default {


        data() {
                return {
                    erdiolabel: '1',
                    selectedlist: [{
                        value: 'zhinan',
                        label: '指南',
                        children: [{
                            value: 'shejiyuanze',
                            label: '设计原则',
                            children: [{
                                value: 'kekong',
                                label: '可控'
                            }]
                        }]
                    }, {
                        value: 'zujian',
                        label: '组件',
                        children: [{
                            value: 'basic',
                            label: 'Basic',
                            children: [{
                                value: 'button',
                                label: 'Button 按钮'
                            }]
                        }, ]
                    }],
                    selectedOptions: [],
                    activeName: 'second',
                    postition: '',
                    leader_info: [],
                    fromdata: [],
                    bank_info: [],
                    ifshow: false, //经纬度弹层
                    City: [],
                    /* 存储返回的城市地址 */
                    value: '',
                    dynamicValidateForm: {
                        domains: [{
                            value: ''
                        }],
                        email: ''
                    },
                    Grade: [{
                        value: '选项1',
                        label: '黄金糕'
                    }, {
                        value: '选项2',
                        label: '双皮奶'
                    }, {
                        value: '选项3',
                        label: '蚵仔煎'
                    }, {
                        value: '选项4',
                        label: '龙须面'
                    }, {
                        value: '选项5',
                        label: '北京烤鸭'
                    }],
                    xze: '',
                    //店铺店址选择数据
                    options: [{
                        value: '1',
                        label: '广西省',

                    }, {
                        value: '2',
                        label: '双皮奶',
                        labe: '广东省',

                    }, {
                        value: '3',
                        label: '蚵仔煎',
                        labe: '四川省',

                    }, {
                        value: '4',
                        label: '龙须面',
                        labe: '江西省',

                    }, {
                        value: '5',
                        label: 'hha',
                        labe: '北京烤鸭',
                    }],
                    value1: '',
                    value2: '',
                    value3: '',
                    value4: '',

                }
            },
            created() {
                this.getHomeData();
            },
            methods: {
                save() {
                        console.log(88);
                    },
                    handleChange(value) {
                        console.log(value);
                    },
                    position() {
                        var THis = this;
                        var City = THis.City;

                        //地图加载
                        var map = new AMap.Map("container", {
                            resizeEnable: true,
                            zoom: 15, //初始地图级别
                        });
                        //输入提示
                        var autoOptions = {
                            input: "tipinput"
                        };
                        var auto = new AMap.Autocomplete(autoOptions);
                        var placeSearch = new AMap.PlaceSearch({
                            map: map
                        }); //构造地点查询类

                        AMap.event.addListener(auto, "select", select); //注册监听，当选中某条记录时会触发
                        function select(e) {
                            let _this = this;
                            document.getElementById('address').value = e.poi.district + e.poi.address + e.poi.name; //接受当前搜索地址，添加到地址栏显示
                            placeSearch.setCity(e.poi.adcode);
                            placeSearch.search(e.poi.name); //关键字查询查询
                        }
                        AMap.plugin('AMap.Geolocation', function () {
                            var geolocation = new AMap.Geolocation({
                                enableHighAccuracy: true, //是否使用高精度定位，默认:true
                                timeout: 10000, //超过10秒后停止定位，默认：5s
                                buttonPosition: 'RB', //定位按钮的停靠位置
                                buttonOffset: new AMap.Pixel(10, 20), //定位按钮与设置的停靠位置的偏移量，默认：Pixel(10, 20)
                                zoomToAccuracy: true, //定位成功后是否自动调整地图视野到定位点
                            });
                            map.addControl(geolocation);

                            AMap.event.addListener(geolocation, 'complete', onComplete); // 返回定位信息
                        });
                        var geocoder = new AMap.Geocoder({
                            city: "020", //城市设为北京，默认：“全国”
                            radius: 500 //范围，默认：500
                        });

                        function onComplete(obj) {
                            document.getElementById('address').value = obj.formattedAddress; /* 接受详细地址，当用户点击定位的时候将定位地址返回选择地址栏 */
                        }
                        var marker = new AMap.Marker();; //添加水滴标识
                        function regeoCode() {

                            var lnglat = document.getElementById('lnglat').value.split(',');
                            map.add(marker);
                            marker.setPosition(lnglat);
                            geocoder.getAddress(lnglat, function (status, result) {
                                if (status === 'complete' && result.regeocode) {
                                    var address = result.regeocode.formattedAddress;
                                    document.getElementById('address').value = address;
                                    document.getElementById('leadeaddresss').value = address;
                                    THis.City = result.regeocode.formattedAddress;
                                } else {
                                    log.error('根据经纬度查询地址失败')
                                }
                            });
                        }

                        map.on('click', function (e) { //抓取地图页面获取经纬度数据
                            document.getElementById('lnglat').value = e.lnglat;
                            regeoCode();
                        })
                        document.getElementById('lnglat').onkeydown = function (e) {
                            if (e.keyCode === 13) {
                                regeoCode();
                                return false;
                            }
                            return true;
                        };
                    },
                    /* 地图层用户点击的时候push地址数据到选择栏,然后关闭布尔值控制 */
                    determines() {
                        var City = this.City;
                        document.getElementById('Citys').value = City; //将获取到的数据添加到详细地址里面
                        this.ifshow = false;

                    },
                    /* swith经纬度的自定义弹层 */
                    alertpostiton() {
                        this.position();
                        this.ifshow = true;
                    },
                    async getHomeData() {
                        var xid = this.$route.query.id;
                        const result = await axios.get(Rootpath.BASE_URL + 'leader_edit?id=' + xid);
                        const res = await axios.get(Rootpath.BASE_URL + 'rank_list');
                        console.log(res);
                        this.fromdata = result.data;
                        this.bank_info = result.data.bank_info[0];
                        // console.log(this.tableData);
                        this.leader_info = result.data.leader_info[0];
                    },
                    async saveback(){
                      let _this=this;
                			axios.post(Rootpath.BASE_URL+'leader_doedit', {
                	    id: _this.leader_info.id,
                	    leader_number: _this.leader_info.leader_number,
                			community_name:_this.leader_info.community_name,
                			leader_coding:_this.leader_info.leader_coding,
                      leader_level_id:_this.leader_info.leader_level_id,
                      state:_this.leader_info.state,
                      leader_name:_this.leader_info.leader_name,
                      community_address:_this.leader_info.community_address,
                      delivery_type:_this.leader_info.delivery_type,
                      leader_id:_this.bank_info.leader_id,
                      open_bank:_this.bank_info.open_bank,
                      account_name:_this.bank_info.account_name,
                      account_number:_this.bank_info.account_number,
                      account_remit:_this.bank_info.account_remit
                	  })
                	  .then(function (response) {
                	    console.log(response);
                	  })
                	  .catch(function (error) {
                	    // console.log(error);
                      console.log(this.id);
                	  });
                		},
            },
            //    页面更新的时候调用地图一次
            beforeUpdate() {
                this.position();
            },
    };
</script>
<style scoped>
    .grroupedit-page {
        background: #ffffff;
    }
    .el-form {
        height: 60px;
    }
    .grroupedit-page .el-input {
        width: 200px
    }
    /* 分页样式 */
    .paging {
        position: fixed;
        right: 0px;
        bottom: 0px;
        background: #FAFAFA;
        width: 100%;
        height: 40px;
        float: right;
        line-height: 0px;
        z-index: 999;
        box-shadow: darkgrey 10px 10px 30px 5px;
    }
    /* 信息输入框的宽度 */
    .inputheith {
        width: 217px;
    }
    .Layertop {
        font-size: 15px;
        margin-top: 25px;
    }
    .Layerto {
        margin-top: 17px;
    }
    .map {
        margin-top: 0%;
        left: 2%;
        height: 550px;
        width: 860px;
        border-radius: 5px;
    }
    .eltabpane {
        position: relative;
    }
    /* 地图弹层的样式 */
    .layertopostition {
        background: rgb(210, 211, 214);
        width: 890px;
        position: absolute;
        top: 20%;
        z-index: 19;
        left: 30%;
        box-shadow: darkgrey 10px 10px 30px 3px;
    }
    .dialog-footer {
        margin-bottom: 100px;
        margin-left: 80%;
    }
    /*   *重要标点的样式   */
    .Important_punctuation {
        color: red;
        line-height: 20px;
    }
    /* 地图搜索框的样式，因为有提示输入所于置于元素最上层 */
    #tipinput {
        position: absolute;
        top: 20px;
        left: 30px;
        z-index: 999999;
        height: 30px;
        width: 200px;
    }
</style>
