<template>
    <div class="GroupManage-page" style="margin: 20px;">
        <el-tabs v-model="activeName">
            <el-tab-pane label="团长管理" name="first">
                <div>
                    <!-- 链接弹层 -->
                    <el-dialog title="店铺链接" :visible.sync="dialogVisible" width="13%">
                        <div style="display: flex;justify-content: center;flex-direction: column; align-items: center;">
                            <div>
                                <img src="https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1303103597,1525305900&fm=26&gp=0.jpg" style="height: 161px; width: 161px;" />
                            </div>
                            <div style="padding-top:30px;">
                                <el-button round style="width:200px;">下载二维码</el-button>
                            </div>
                        </div>
                        <span slot="footer" class="dialog-footer">
				     <el-button @click="dialogVisible = false">取 消</el-button>
				     <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
				   </span>
                    </el-dialog>
                </div>
                <!-- 冻结弹层详情html -->
                <div>
                    <el-dialog title="冻结" :visible.sync="Frozen" width="15%">
                        <hr />
                        <div style="text-align: center;margin: 20px;">
                            <img src="../../assets/logo.png" style="height:16px; width: 16px;" /><font style="line-height: 16px;">账号124515465,是否冻结？</font>
                        </div>
                        <hr />
                        <span slot="footer" class="dialog-footer">
						 <el-button @click="Frozen = false">取 消</el-button>
						 <el-button type="primary" @click="Frozen = false">确 定</el-button>
					   </span>
                    </el-dialog>
                </div>

                <div>
                    <!-- 搜索框 -->
                    <div>
                        <el-form :inline="true" :model="formInline">
                            <el-form-item label="店铺名称" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                            </el-form-item>
                            <el-form-item label="团长名称" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                            </el-form-item>
                            <el-form-item label="联系方式" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                            </el-form-item>&emsp;
                            <el-form-item>
                                <el-button size="small" type="primary" style="margin-top: 23px;">搜索</el-button>
                            </el-form-item>
                        </el-form>
                        <div style="display: flex;padding:15px 0px;">
                            <div style="line-height:40px; color:#606266;;padding-right:10px;  font-size:14px;">店铺区域</div>
                            <div style="width:100px;">
                                <!-- <el-select v-model="leader_list.community_address" multiple placeholder="请选择">
                                    <el-option v-for="item in leader_list" v-model="item.community_address">
                                    </el-option>
                                </el-select> -->
                                <el-select v-model="leader_list.community_address" placeholder="请选择">
                                  <el-option
                                    v-for="item in leader_list"
                                    :value="item.community_address">
                                  </el-option>
                                </el-select>
                            </div>
                        </div>
                    </div>
                </div>
                <el-button type="primary" size="small" @click="increase()">新增</el-button>
                <div class="right">
                    <el-button size="medium">导出查询结果</el-button>
                </div>
                <div>
                </div>
                <div>
                    <el-table :header-cell-style="{background:'#eef1f6',color:'#606266'}" :data="leader_list.slice((currentPage-1)*pagesize,currentPage*pagesize)" stripe style="width: 100%">
                        <el-table-column prop="leader_name" label="团长名称" width="180">
                        </el-table-column>
                        <el-table-column prop="mobile" label="联系方式" width="180">
                        </el-table-column>
                        <el-table-column prop="community_name" label="店铺名称">
                        </el-table-column>
                        <el-table-column prop="community_address" label="提货地址">
                        </el-table-column>
                        <el-table-column prop="state" label="状态">
                        </el-table-column>
                        <el-table-column label="操作">
                            <template slot-scope="scope">
                                <el-button type="text" @click="editrow(scope.row)">编辑</el-button>
                                <el-button type="text" @click="dialogVisible = true">链接</el-button>
                                <el-button type="text" @click="Frozen = true">冻结</el-button>
                            </template>
                        </el-table-column>

                    </el-table>
                    <!--分页-->
                		<el-pagination
                			class="pagination"
                			background
                			@size-change="handleSizeChange"
                			@current-change="handleCurrentChange"
                			:current-page="currentPage"
                			:page-sizes="[5, 10, 20, 50]"
                			:page-size="pagesize"
                			layout="total, sizes, prev, pager, next, jumper"
                			:total="total"
                		></el-pagination>
                </div>
            </el-tab-pane>
            <!-- tab冻结团长部分 -->
            <el-tab-pane label="已冻结团长" name="firsts">

                <div>
                    <!-- 搜索框 -->
                    <div>
                        <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
                            <el-form-item label="店铺名称" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                            </el-form-item>
                            <el-form-item label="团长名称" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                            </el-form-item>
                            <el-form-item label="联系方式" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                            </el-form-item>&emsp;
                            <el-form-item>
                                <el-button size="small" type="primary" style="margin-top: 23px;">搜索</el-button>
                            </el-form-item>
                        </el-form>
                        <div style="display: flex;padding:15px 0px;">
                            <div style="line-height:40px; color: #808080;padding-right:10px; font-size:13px;">店铺区域</div>
                            <div style="width:100px;">
                                <!-- <el-select v-model="value" multiple placeholder="请选择">
                                    <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select> -->
                                <el-select v-model="frozenleader_list.community_address" placeholder="请选择">
                                  <el-option
                                    v-for="item in frozenleader_list"
                                    :value="item.community_address">
                                  </el-option>
                                </el-select>
                            </div>
                            <!-- <div style="width:100px; padding-left: 15px;">
                                <el-select v-model="value" multiple placeholder="请选择">
                                    <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </div>
                            <div style="width:100px; padding-left: 15px;">
                                <el-select v-model="value" multiple placeholder="请选择">
                                    <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </div>
                            <div style="width:100px; padding-left: 15px;">
                                <el-select v-model="value" multiple placeholder="请选择">
                                    <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </div> -->
                        </div>
                    </div>
                </div>
                <el-button type="primary" @click="increase()">新增</el-button>
                <div class="right">
                    <el-button size="medium">导出查询结果</el-button>
                </div>
                <div>
                </div>
                <div>
                    <el-table :header-cell-style="{background:'#eef1f6',color:'#606266'}" :data="frozenleader_list" stripe empty-text="没有找到符合条件的团长" style="width: 100%">
                        <el-table-column prop="leader_name" label="团长名称" width="180">
                        </el-table-column>
                        <el-table-column prop="mobile" label="联系方式" width="180">
                        </el-table-column>
                        <el-table-column prop="community_name" label="店铺名称">
                        </el-table-column>
                        <el-table-column prop="community_address" label="提货地址">
                        </el-table-column>
                        <el-table-column prop="state" label="状态">
                        </el-table-column>
                    </el-table>
                    <!--分页-->
                		<el-pagination
                			class="pagination"
                			background
                			@size-change="frozenhandleSizeChange"
                			@current-change="frozenhandleCurrentChange"
                			:current-page="frozencurrentPage"
                			:page-sizes="[5, 10, 20, 50]"
                			:page-size="frozenpagesize"
                			layout="total, sizes, prev, pager, next, jumper"
                			:total="frozentotal"
                		></el-pagination>
                </div>
            </el-tab-pane>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>
<script>
    import axios from '../../axios.js';
    import Rootpath from "../../../api/index.js"
    export
    default {
        name: 'first',
        components: {},
        data() {
            return {
                Frozen: false,
                total: 0,
          			currentPage: 1,
          			pagesize: 5,
                frozenleader_list:[],
                frozentotal:0,
                frozencurrentPage: 1,
          			frozenpagesize: 5,
                options: [{
                    value: '选项1',
                    label: '小雪'
                }, {
                    value: '选项2',
                    label: '小雪'
                }, {
                    value: '选项3',
                    label: '小雪'
                }, {
                    value: '选项4',
                    label: '小雪'
                }, {
                    value: '选项5',
                    label: '小雪'
                }],
                dialogVisible: false,
                activeName: 'first',
                formInline: {
                    user: '',
                    region: ''
                },
                num: 1,
                leader_list: [],
            }
        },
        created() {
            this.getData();
            this.getfrozenData();
            // this.integrlist();
        },
        methods: {
          handleSizeChange(size) {
            this.pagesize = size;
          },
          handleCurrentChange(currentPage) {
            this.currentPage = currentPage;
          },
          frozenhandleSizeChange(frozensize) {
            this.frozenpagesize = frozensize;
          },
          frozenhandleCurrentChange(frozencurrentPage) {
            this.frozencurrentPage = frozencurrentPage;
          },
                editrow(row) {
                  this.$router.push({path:'/charts/line/Grroupedit',query: {id:row.id}})
                },
                // 获取数据
                async getData() {
                    const result = await axios.get(Rootpath.BASE_URL + 'leader_list');
                    console.log(result);
                    this.leader_list = result.data.leader_list
                    this.total = result.data.leader_list.length
                },
                // 获取冻结团长数据
                async getfrozenData() {
                    const result = await axios.get(Rootpath.BASE_URL + 'leader_frozen');
                    console.log(result);
                    this.frozenleader_list = result.data.leader_list
                    this.frozentotal = result.data.leader_list.length
                },

        }
    };
</script>
<style scoped>
    /* 选择输入框的长度 */
    .el-form {
        height: 60px;
    }
    /* 底部分页 */
    .paging {
        position: fixed;
        right: 0px;
        bottom: 0px;
        background: #FAFAFA;
        width: 100%;
        height: 40px;
        float: right;
        line-height: 0px;
        z-index: 999;
        box-shadow: darkgrey 10px 10px 30px 5px;
    }
</style>
