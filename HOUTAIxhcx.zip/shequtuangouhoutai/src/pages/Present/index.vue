<template>
  <div class="Service-page" style="margin: 20px;">
	  <el-tabs v-model="activeName" @tab-click="handleClick">
	     <el-tab-pane label="团长提现" name="first">
				<div>
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				  <el-form-item label="团长等级" style="margin-top: 20px;">
					 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
					    <el-option
					      v-for="item in options"
					      :key="item.value"
					      :label="item.label"
					      :value="item.value">
					    </el-option>
					  </el-select>
				  </el-form-item>
				  <el-form-item label="详细地址" style="margin-top: 20px;">
				  					 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
				  					    <el-option
				  					      v-for="item in options"
				  					      :key="item.value"
				  					      :label="item.label"
				  					      :value="item.value">
				  					    </el-option>
				  					  </el-select>
				  </el-form-item>
				  <el-form-item label="店铺名称" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="团长名称" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="团长电话" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item>
					<el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>		
				  </el-form-item>
				</el-form>
				</div>
				<div class="right">
				<el-button size="medium">导出查询结果</el-button>
				</div>
					<div style="margin-top:15px;">
						<el-table
						    :data="tableData"
						    stripe
						    style="width: 100%">
						    <el-table-column
							   prop="name"
							  align="center" 
						      label="提货单号"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center" 
						      prop="name"
						      label="团长账号"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center" 
						      prop="address"
						      label="店铺名称">
						    </el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="团长名称">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="团长等级">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="提货金额">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="审核时间">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="状态">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="付款方式">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="操作">
							 <template slot-scope="scope">
							 	        <el-button @click="details()" type="text" size="small">详情</el-button>
							 	        <el-button type="text" size="small" @click="copy()">余额明细</el-button>
										<el-button type="text" size="small" @click="copy()">待结算佣金明细</el-button>
							 	      </template>
							 	    </el-table-column>
						  </el-table>
					</div>
				<div class="paging">
			  <div style="padding-left:80%;align-items: center;padding-top:9px;" class="flex">
				<span>1/6页,45条结果</span>
				&emsp;
				<el-input-number size="mini" v-model="num" controls-position="right" @change="handleChange" :min="1" style="width:80px;"></el-input-number>
				&emsp;&emsp;
				<span class="menu-icon"><i class="el-icon-arrow-left" /></span>
				&emsp;
				<span class="menu-icon"><i class="el-icon-arrow-right" /></span>
				&emsp;
				<el-button size="mini">指定跳转</el-button>
			</div>
		</div>

		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
export default {
  name: 'first',
  components: {},
   data() {
        return {
			 activeName: 'first',
			  num: 1,
			   formInline: {
			            user: '',
			            region: ''
			          },
          tableData: [{
            date: '2016-05-02',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1518 弄'
          }, {
            date: '2016-05-04',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1517 弄'
          }, {
            date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  }],
		      options: [{
		            value: '选项1',
		            label: '黄金糕'
		          }, {
		            value: '选项2',
		            label: '双皮奶'
		          }, {
		            value: '选项3',
		            label: '蚵仔煎'
		          }, {
		            value: '选项4',
		            label: '龙须面'
		          }, {
		            value: '选项5',
		            label: '北京烤鸭'
		          }],
		          value: ''
		        }
      },
	   methods: {
	        handleChange(value) {
	          console.log(value);
	        },
			onSubmit() {
			        console.log('submit!');
			      },//跳转新增页面
				  increase(){
				  		 this.$router.push({path:'/market/Seckill/Spike_added',query: {id:1}})
				  },//跳转详情页面
				  details(){
					  this.$router.push({path:'/market/Seckill/details',query: {id:1}})
				  },//跳转复制活动页面
				  copy(){
					   this.$router.push({path:'/market/Seckill/copy',query: {id:1}})
				  },
	      }
};
</script>
<style scoped>
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px; 
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
