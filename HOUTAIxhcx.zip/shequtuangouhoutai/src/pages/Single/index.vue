<template>
	<div class="select Single-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="采购单" name="first"></el-tab-pane></el-tabs>

			<div class="search">
				<!---->
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
					<el-form-item label="供应商" style="margin-top: 20px;"><el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input></el-form-item>
					<el-form-item label="采购单" style="margin-top: 20px;"><el-input size="small" v-model="formInline.region" style="width: 120px;"></el-input></el-form-item>
					<el-form-item label="采购类型" style="margin-top: 20px;"><el-input size="small" v-model="formInline.states" style="width: 120px;"></el-input></el-form-item>
					&emsp;

					<el-form-item><el-button size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button></el-form-item>
				</el-form>
				<!---->
			</div>
			<br />
			<br />
			<div class="flex_fcs">
				<el-button  @click="dialogV()" size="small"  type="primary">新增采购单</el-button>
				<el-button size="medium" >导出查询结果</el-button>
			</div>

			<br />
			<el-table ref="multipleTable" :data="purchaseBillList.slice((currentPage-1)*pagesize,currentPage*pagesize)" tooltip-effect="dark" style="width: 100%">
				<el-table-column type="selection" width="55"></el-table-column>
				<el-table-column label="采购单号" align="center" prop="purchase_bill">
				</el-table-column>

				<el-table-column prop="purchase_type" align="center" label="采购类型"></el-table-column>
				<el-table-column prop="purchaser_name" align="center" label="供应商"></el-table-column>
				<el-table-column prop="purchase_sum" align="center" label="收货金额"></el-table-column>
				<el-table-column prop="producer" align="center" label="制单人"></el-table-column>
				<el-table-column prop="bill_state" align="center" label="状态"></el-table-column>
				<el-table-column prop="purchase_date" align="center" label="计划交货日期"></el-table-column>
				<!-- <el-table-column prop="purchase_date" label="采购时间" width="200"></el-table-column> -->
				<el-table-column prop="purchaseSum" align="center" label="总采购项"></el-table-column>
				<el-table-column prop="alreadyPurchase" align="center" label="已采购项"></el-table-column>
				<el-table-column fixed="right" align="center" label="操作">
					<template slot-scope="scope">
						<el-button type="text" @click="dialogVi(scope.row)">详情</el-button>
						<el-button type="text">收货</el-button>
						<el-button type="text">打印</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!--分页-->
			<el-pagination class="pagination"
					background
					@size-change="handleSizeChange"
					@current-change="handleCurrentChange"
					:current-page="currentPage"
					:page-sizes="[5, 10, 20, 50]"
					:page-size="pagesize"
					layout="total, sizes, prev, pager, next, jumper"
					:total="total">
				</el-pagination>
		</div>
	</div>
</template>

<script>
import axios from '../../axios.js';
import Rootpath from "../../../api/index.js"
export default {
	data() {
		return {
			activeName: 'first',
			total: 0,
			currentPage: 1,
			pagesize: 5,
			purchaseBillList: [],
			formInline: {
				user: '',
				region: '',
				states: '',
				times: ''
			},



		};
	},
		created() {
			this.getData();
		},
		methods: {
				onSubmit() {
					console.log('submit!');
				},
				// 获取数据
				async getData() {
        	const result = await axios.get(Rootpath.BASE_URL + 'purchaseList?cid=1');
        	console.log(result);
        	this.purchaseBillList = result.data.purchaseBillList
        	this.total = result.data.purchaseBillList.length
    		},
				toggleSelection(rows) {
					if (rows) {
						rows.forEach(row => {
							this.$refs.multipleTable.toggleRowSelection(row);
						});
					} else {
						this.$refs.multipleTable.clearSelection();
					}
				},
				handleSelectionChange(val) {
					this.multipleSelection = val;
				},
				//新增
				dialogV(buymor){
				 this.$router.push({path:'/profile/success/buymore',query: {id:buymor}})
				},
				//详情
				dialogVi(row){
			  this.$router.push({path:'/profile/success/Buydetails',query: {
				 pno: row.purchase_bill,
			 }});
				},
				//分页
				handleSizeChange(size) {
					this.pagesize = size
				},
				handleCurrentChange(currentPage) {
					this.currentPage = currentPage
				},
			},

};
</script>

<style scoped>
.footer {
	height: 44px;
	text-align: right;
}
.right {
	text-align: right;
	margin-top: -33px;
}

p {
	position: relative;
	top: -12px;
}
.text {
	display: flex;
	left: 20px;
	position: relative;
	top: 15px;
}

h3 {
	color: #436be5;
	border-bottom: solid 2px #436be5;
	margin-left: 20px;
}
.text-frame-member {
	width: 100px;
	position: relative;
	top: 10px;
}
.text-frame {
	height: 50px;
	width: 100%;
	background-color: #ffffff;
	border-bottom: solid 1px #f0f2f0;
}

.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select {
	margin: auto;
	width: 96%;
	background-color: #ffffff;
} /*border: solid 1rpx #007AFF;
*/
.search {
	height: 70px;
	background-color: #f5f5f5;
}
.search-Button {
	margin-left: 20px;
}
.block{
	text-align: right;
}
</style>
