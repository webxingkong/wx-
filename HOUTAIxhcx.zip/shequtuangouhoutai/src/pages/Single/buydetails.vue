<template>
	<div class="select buydetails-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="采购单详情" name="first"></el-tab-pane></el-tabs>
			<h4>基本信息</h4>
			<el-row>
				<!--类型-->
				<el-col :span="8">
					<div class="">
						<ul>
							<li class="flex ">
								<div class="labeltext">
									单号：
								</div>
								<div class="labeltext">
									{{purchaseBillInfo.purchase_bill}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									已收种数：
								</div>
								<div class="labeltext">
									{{purchaseBillInfo.purchaseSum}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									采购员/供应商：
								</div>
								<div class="labeltext">
									{{purchaseBillInfo.purchaser_name}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									计划交货日期：
								</div>
								<div class="labeltext">
									{{purchaseBillInfo.delivery_date}}
								</div>
							</li>
						</ul>
					</div>
				</el-col>
				<!--仓库-->
				<el-col :span="8">
					<div class="">
						<ul>
							<li class="flex ">
								<div class="labeltext">
									仓库：
								</div>
								<div class="labeltext">
									{{purchaseBillInfo.warehouse_name}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									单据状态：
								</div>
								<div class="labeltext">
									{{purchaseBillInfo.bill_state_name}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									单据来源：
								</div>
								<div class="labeltext">
									{{purchaseBillInfo.bill_source_name}}
								</div>
							</li>
						</ul>
					</div>
				</el-col>
				<!--交货日期-->
				<el-col :span="8">
					<div class="bg-purple">
						<ul>
							<li class="flex ">
								<div class="labeltext">
									采购商品种数：
								</div>
								<div class="labeltext">
									{{purchaseBillInfo.alreadyPurchase}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									采购类型：
								</div>
								<div class="labeltext">
									{{purchaseBillInfo.purchase_type_name}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									计划采购时间：
								</div>
								<div class="labeltext">
									{{purchaseBillInfo.purchase_date}}
								</div>
							</li>
						</ul>
					</div>
				</el-col>
			</el-row>
			<el-table ref="multipleTable" :data="goodsList" tooltip-effect="dark" :summary-method="total" show-summary style="width: 100%">
				<!-- <el-table-column width="55"></el-table-column> -->
				<el-table-column prop="goods_name" align="center" label="商品名称">
				</el-table-column>
				<el-table-column prop="goods_unit" align="center" label="单位"></el-table-column>
				<!-- <el-table-column prop="state" label="状态" width="180"></el-table-column> -->
				<el-table-column prop="goods_price" align="center" label="进货均价"></el-table-column>
				<el-table-column prop="purchase_count" align="center" label="代采购量"></el-table-column>
				<el-table-column prop="received_count" align="center" label="已收数"></el-table-column>
				<el-table-column prop="uncollected" align="center" label="未收数"></el-table-column>
				<el-table-column prop="received_sum" align="center" label="收货总金额"></el-table-column>
			</el-table>
			<div class="flex_m" style="min-height:40px;">
				<span>备注：</span>
				<span style="color: #436BE5">{{purchaseBillInfo.remarks}}</span>
			</div>
			<br />
			<h4>单据操作历史</h4>
			<el-table ref="multipleTable" :data="record" tooltip-effect="dark" style="width: 100%" >
				<el-table-column prop="order" label="序号"></el-table-column>
				<el-table-column prop="operator" label="操作人"></el-table-column>
				<el-table-column prop="operator_time" label="时间"></el-table-column>
				<el-table-column prop="operator_Record" label="操作历史"></el-table-column>
			</el-table>
			<br><br>
			<el-button size="small" @click="returnback" type="primary">返回</el-button>
		</div>
	</div>
</template>

<script>
import axios from '../../axios.js';
import Rootpath from "../../../api/index.js"
export default {
	data() {
		return {
			activeName: 'first',
			purchaseBillInfo:[],
			goodsList:[],
			record:[],
		};
	},
	created() {
		this.getData();
	},
	methods: {
		onSubmit() {
			console.log('submit!');
		},
		//合计
		total(param){
			const { columns, data } = param
      const sums = []
      columns.forEach((column, index) => {
        if (index === 0) {
          sums[index] = '合计：'
        } else if (index === 6) {
          const values = data.map(item => Number(item[column.property]))
          if (!values.every(value => isNaN(value))) {
            sums[index] = values.reduce((prev, curr) => {
              const value = Number(curr)
              if (!isNaN(value)) {
                return prev + curr

              } else {
                return prev
              }
            }, 0)
          } else {
            sums[index] = 'N/A'
          }
        } else {
          sums[index] = ''
        }
      })
      return sums
		},
		//详情
		deleteRow(index, rows) {
			rows.splice(index, 1);
		},
		returnback(){
			this.$router.push({ path: '/profile/success' });
		},
		// 获取数据
			async getData() {
				var purchase_bill = this.$route.query.pno
				const result = await axios.get(Rootpath.BASE_URL + 'purchaseInfo?pno=' + purchase_bill);
							// const result = await axios.get(Rootpath.BASE_URL + 'purchaseInfo');
							console.log(result);
							this.purchaseBillInfo = result.data.purchaseBillInfo
							this.goodsList=result.data.purchaseBillInfo.goodsList
							this.record=result.data.purchaseBillInfo.record
							// this.total = result.data.purchaseBillInfo.length
					},

	}
};
</script>

<style scoped>
.buydetails-page{
	background: #ffffff;
}
.buydetails-page h4{
	background: #f5f5f5;
	line-height: 30px
}
.labeltext{
	font-size: 14px;
	line-height: 30px
}
.grid-content {
	height: 160px;
	font-size: 8px;
}
.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select {
	margin: auto;
	width: 96%;
	background-color: #ffffff;
} /*border: solid 1rpx #007AFF;
*/
.footer{
	text-align: right;
}

</style>
