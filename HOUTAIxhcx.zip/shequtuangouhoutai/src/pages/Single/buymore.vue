<template>
    <div class="select">
        <div class="select-table">
            <el-tabs v-model="activeName">
                <el-tab-pane label="新增采购单" name="first"></el-tab-pane>
            </el-tabs>
            <h4>基本信息</h4>
            <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
                <el-row>
                    <!--类型-->
                    <el-col :span="8">
                        <div>
                            <el-form-item label="类型:" style="margin-top: 20px;">
                                <!-- <el-select v-model="purchaser.type_name" placeholder="请选择" size="small" style="width: 200px;">
									<el-option v-for="item in purchaser" :value="item.type_name" :disabled="item.disabled"></el-option>
								</el-select> -->
                                <el-cascader v-model="value" :options="purchaser">
                                </el-cascader>
                            </el-form-item>
                        </div>
                    </el-col>
                    <!--仓库-->
                    <el-col :span="8">
                        <div>
                            <el-form-item label="仓库:" style="margin-top: 20px;">
                                <el-select v-model="warehouse.warehouse" placeholder="请选择" size="small" style="width: 200px;">
                                    <el-option v-for="item in warehouse" :value="item.warehouse" :disabled="item.disabled"></el-option>
                                </el-select>
                            </el-form-item>
                        </div>
                    </el-col>
                    <!--交货日期-->
                    <el-col :span="8">
                        <div>
                            <span class="demonstration">计划交货日期 ：</span>
                            <el-date-picker v-model="value1" type="datetime" placeholder="选择日期时间" style="margin-top: 20px;"></el-date-picker>
                        </div>
                    </el-col>
                </el-row>
            </el-form>

            <h4>采购商品清单</h4>
            <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
                <el-row>
                    <el-col :span="8">
                        <div>
                            <el-form-item label="商品" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.states" placeholder="商品名称/编码" style="width: 200px;"></el-input>
                            </el-form-item>
                        </div>
                    </el-col>

                    <el-col :span="8">
                        <div>
                            <el-form-item label="数量" style="margin-top: 20px;">
                                <el-input size="small" v-model="formInline.state" placeholder="请输入数字" style="width: 200px;"></el-input>
                                &emsp;
                                <el-button size="small" type="primary" @click="open">添加</el-button>
                            </el-form-item>
                        </div>
                    </el-col>
                </el-row>
            </el-form>
            <!--表单-->
            <div>
                <el-table :data="goodsList" :summary-method="total" show-summary style="width: 100%" max-height="250">
                    <el-table-column prop="product_name" align="center" label="商品名称"></el-table-column>
                    <el-table-column prop="details" align="center" label="描述"></el-table-column>
                    <el-table-column prop="unit" align="center" label="单位"></el-table-column>
                    <el-table-column prop="consult_price" align="center" label="参考价格(近一次采购价/询价)"></el-table-column>
                    <el-table-column prop="purchase_price" align="center" label="采购价">
                        <template slot-scope="scope">
                            <el-input v-model="scope.row.purchase_price" @input="pricechange(scope.row)" size="mini" style="width:100px"></el-input>
                        </template>
                    </el-table-column>
                    <el-table-column prop="purchase_count" align="center" label="待采购量">
                        <template slot-scope="scope">
                            <el-input v-model="scope.row.purchase_count" @input="countchange(scope.row)" size="mini" style="width:100px"></el-input>
                        </template>
                    </el-table-column>
                    <el-table-column prop="purchase_sum" align="center" label="采购金额">
                        <template slot-scope="scope">
                            <el-input v-model="scope.row.purchase_sum" size="mini" style="width:100px" readonly></el-input>
                        </template>
                    </el-table-column>
                    <el-table-column fixed="right" align="center" label="操作">
                        <template slot-scope="scope">
                            <el-button @click.native.prevent="deleteRow(scope.$index, goodsList)" type="text" size="small">移除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <!-- <br><br> -->
                <span style="line-height:85px">备注 ： </span>
                <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4}" placeholder="请输入内容" v-model="textarea2" style=" width: 500px;">
                </el-input>

            </div>
            <br></br>
            <el-button size="small" @click="save" type="primary">保存</el-button>&emsp;
            <el-button size="small">取消</el-button>
        </div>

    </div>
</template>
<script>
    import axios from '../../axios.js';
    import Rootpath from "../../../api/index.js"
    export
    default {
        data() {
                return {
                    textarea2: '',
                    activeName: 'first',
                    tableData: [{
                        shop: '八宝粥500g/一罐',
                        name: '说明',
                        province: '盒',
                        city: '00.0/0',



                    }, {
                        shop: '八宝粥500g/一罐',
                        name: '说明',
                        province: '盒',
                        city: '00.0/0',

                    }],
                    formInline: {
                        user: '',
                        region: '',
                        Name: '',
                        times: '',
                        Mobilephone: '',
                        Names: '',
                        states: '',
                        state: ''
                    },
                    purchaseBill: {
                        warehouse_id: 1, //仓库表id
                        purchase_type: 0, //采购类型  1 供应商直销、2 市场自采
                        purchaser_id: 1, //采购商id
                        purchase_date: "1970-01-14 04-38-31", //计划采购日期
                        remarks: "备注",
                        goodsList: []
                    },
                    value: '',
                    option: [{
                        price: '选项1',
                        labe: '一类'
                    }, {
                        price: '选项2',
                        labe: '二类'
                    }, {
                        price: '选项3',
                        labe: '十八类'
                    }, {
                        price: '选项4',
                        labe: '累'
                    }, {
                        price: '选项5',
                        labe: '选择一个类型'
                    }],
                    price: '',

                    //时间选择器

                    value1: '',
                    value2: '',
                    value3: '',
                    goodsList: [],
                    purchaser: [],
                    warehouse: [],
                    pcvalue: null,
                    childrenvalue: null

                };
            },
            created() {
                this.getData();
            },
            methods: {
                onSubmit() {
                        console.log('submit!');
                    },
                    //价格改变
                    pricechange(row) {
                        row.purchase_sum = row.purchase_price * row.purchase_count
                    },
                    //数量改变
                    countchange(row) {
                        row.purchase_sum = row.purchase_price * row.purchase_count
                    },
                    //合计
                    total(param) {
                        const {
                            columns, data
                        } = param
                        const sums = []
                        columns.forEach((column, index) => {
                            if (index === 0) {
                                sums[index] = '合计：'
                            } else if (index === 6) {
                                const values = data.map(item => Number(item[column.property]))
                                if (!values.every(value => isNaN(value))) {
                                    sums[index] = values.reduce((prev, curr) => {
                                        const value = Number(curr)
                                        if (!isNaN(value)) {
                                            return prev + curr

                                        } else {
                                            return prev
                                        }
                                    }, 0)
                                } else {
                                    sums[index] = 'N/A'
                                }
                            } else {
                                sums[index] = ''
                            }
                        })
                        return sums
                    },
                    // 获取数据
                    async getData() {
                        // var purchase_bill = this.$route.query.pno
                        const result = await axios.get(Rootpath.BASE_URL + 'addPurchaseBillPage')
                        this.goodsList = result.data.info.goodsList
                        this.purchaser = result.data.info.purchaser
                        this.warehouse = result.data.info.warehouse
                        let gl = this.goodsList
                        console.log(result.data.info);
                        for (var i = 0; i < gl.length; i++) {
                            let pp = gl[i].purchase_price
                            let pc = gl[i].purchase_count
                            this.goodsList[i].purchase_sum = gl[i].purchase_price * gl[i].purchase_count
                        }
                    },
                    //保存
                    save() {
                        let that = this;
                        // console.log(that.warehouse.warehouse);
                        // console.log(that.purchaser);
                        let purchaser = that.purchaser;
                        // console.log(that.goodsList);
                        for (var i = 0; i < purchaser.length; i++) {
                            that.pcvalue = purchaser[i].value
                            let children = purchaser[i].children
                            for (var j = 0; j < children.length; j++) {
                                that.childrenvalue = children[i].label
                            }
                        }
                        let data = {
                            warehouse_id: that.warehouse.warehouse, //仓库表id
                            purchase_type: that.pcvalue, //采购类型  1 供应商直销、2 市场自采
                            purchaser_id: that.childrenvalue, //采购商id
                            purchase_date: that.value1, //计划采购日期
                            remarks: that.textarea2,
                            goodsList: that.goodsList
                        }

                        // axios.post(Rootpath.BASE_URL + 'addPurchaseBill', {
                        // 			 params: {
                        // 					 data
                        // 			 }
                        // 	 })
                        // 	 .then(function (response) {
                        // 			 console.log(response);
                        // 			 this.$router.push({path:'/profile/success'});
                        // 	 }.bind(this))
                        // 	 .catch(function (error) {
                        // 			 console.log(error);
                        // 	 });


                        axios.post(Rootpath.BASE_URL + 'addPurchaseBill', data)
                            .then(res => {
                                console.log('res=>', res);
                            })

                        // axios.post(Rootpath.BASE_URL + 'addPurchaseBill',qs.stringify({
                        //     data
                        // }))
                        // .then(res=>{
                        //     console.log('res=>',res);
                        // })

                    },
                    deleteRow(index, rows) {
                        rows.splice(index, 1);
                    },
                    //商品添加
                    open() {
                        this.$confirm('商品有误无法添加', '有误', {
                            confirmButtonText: '确定',
                            type: 'error'

                        })


                    },

            }
    };
</script>

<style scoped>
    .select-table {
        margin: auto;
        width: 96%;
        margin-top: 20px;
    }
    .select {
        margin: auto;
        width: 96%;
        background-color: #ffffff;
    }
    /*border: solid 1rpx #007AFF;
*/
    .search-Button {
        margin-left: 20px;
    }
</style>
