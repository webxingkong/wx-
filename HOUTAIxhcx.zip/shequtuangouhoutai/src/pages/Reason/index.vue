<template>
  <div class="Reason-page" style="margin: 20px;">
	  <el-tabs v-model="activeName">
	     <el-tab-pane label="售后原因" name="first">
			   <el-button type="primary" @click="addlayout=true" size="small">新增</el-button>
					<div>
						<el-table
            ref="multipleTable"
            stripe
						    :data="afterSaleReason.slice((currentPage-1)*pagesize,currentPage*pagesize)"
						    stripe
                @row-click="select"
						    style="width: 100%">
						    <el-table-column
						      prop="id"
                  align="center"
						      label="编号">
						    </el-table-column>
						    <el-table-column
						      prop="create_time"
                  align="center"
						      label="创建时间">
						    </el-table-column>
						    <el-table-column
						      prop="after_sale_reason"
                  align="center"
						      label="退货/退款原因">
						    </el-table-column>
							<el-table-column
							  prop="address"
                align="center"
							  label="操作">
							   <template slot-scope="scope">
							          <el-button @click="editlayout = true" type="text" size="small">编辑</el-button>
							          <el-button type="text" @click="delectinfo(scope.row,afterSaleReason)">删除</el-button>
							        </template>
							</el-table-column>
						  </el-table>
              <!--分页-->
          		<el-pagination
          			class="pagination"
          			background
          			@size-change="handleSizeChange"
          			@current-change="handleCurrentChange"
          			:current-page="currentPage"
          			:page-sizes="[5, 10, 20, 50]"
          			:page-size="pagesize"
          			layout="total, sizes, prev, pager, next, jumper"
          			:total="total"
          		></el-pagination>
					</div>
		 </el-tab-pane>
	   </el-tabs>
     <!-- 新增弹出框 -->
 		<el-dialog title="新增" class="layoutbox" :visible.sync="addlayout">
 			<el-form :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
 				<el-form-item class="leftlabel" label="售后原因："><el-input class="inputtext" v-model="afterSaleReasons.after_sale_reason"></el-input></el-form-item>
 			</el-form>
 			<span slot="footer" class="dialog-footer">
 				<el-button @click.self="addlayout = false">取 消</el-button>
 				<el-button type="primary" @click="addsure()">确 定</el-button>
 			</span>
 		</el-dialog>
 		<!-- 新增弹出框  结束-->
     <!-- 编辑弹出框 -->
 		<el-dialog title="编辑" class="layoutbox" :visible.sync="editlayout">
 			<el-form :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
 				<el-form-item class="leftlabel" label="售后原因："><el-input class="inputtext" v-model="clickrow.after_sale_reason"></el-input></el-form-item>
 			</el-form>
 			<span slot="footer" class="dialog-footer">
 				<el-button @click.self="editlayout = false">取 消</el-button>
 				<el-button type="primary" @click="editsure()">确 定</el-button>
 			</span>
 		</el-dialog>
 		<!-- 编辑弹出框  结束-->
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
   data() {
        return {
			       editlayout: false,
             addlayout:false,
			       activeName: 'first',
             reasoninput:'',
             total: 0,
             currentPage: 1,
             table_index: 999,
             pagesize: 5,
             clickrow:[],//点击的行数据
             afterSaleReason: [],
             afterSaleReasons: {
               after_sale_reason: ""
             },
             rules: {
       				name: [{ required: true, message: '请输入活动名称', trigger: 'blur' }, { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }],
       				region: [{ required: true, message: '请选择活动区域', trigger: 'change' }],
       				date1: [{ type: 'date', required: true, message: '请选择日期', trigger: 'change' }],
       				date2: [{ type: 'date', required: true, message: '请选择时间', trigger: 'change' }],
       				type: [{ type: 'array', required: true, message: '请至少选择一个活动性质', trigger: 'change' }],
       				resource: [{ required: true, message: '请选择活动资源', trigger: 'change' }],
       				desc: [{ required: true, message: '请填写活动形式', trigger: 'blur' }]
       			},
        }
      },
      created(){
        this.getData();
      },
	   methods: {
       handleSizeChange(size) {
         this.pagesize = size
       },
       handleCurrentChange(currentPage) {
         this.currentPage = currentPage
       },
	        handleChange(value) {
	          console.log(value);
	        },
          //获取点击的数据
          select(val){
            this.clickrow=val;
            console.log(val);
          },
			 handleClick(row) {

			        console.log(row);
			      },
			add(){
				console.log("999999999")
			},
      // 获取数据
      async getData() {
          const result = await axios.get(Rootpath.BASE_URL + 'afterSaleReason');
          this.afterSaleReason = result.data.afterSaleReason;
          this.total = result.data.afterSaleReason.length
      },
      //新增
      async addsure(index){
        let that=this;
        axios.post(Rootpath.BASE_URL + 'addafterSaleReason', {
            afterSaleReasons: that.afterSaleReasons,
        })
        .then(function (response) {
            that.addlayout = false;
            that.afterSaleReasons.after_sale_reason='';
            that.getData();
            console.log(response);
        })
        .catch(function (error) {
            console.log(error);
        });
      },
      //编辑
      async editsure(index){
        let that=this;
        axios.post(Rootpath.BASE_URL + 'editAfterSaleReason', {
            afterSaleReason: that.clickrow,
        })
        .then(function (response) {
            that.editlayout = false;
            that.getData();
            console.log(response);
        })
        .catch(function (error) {
            console.log(error);
        });
      },
      // 删除弹窗
  		delectinfo(row) {
  			this.$confirm('确定删除该分类？', '提示', {
  				confirmButtonText: '确定',
  				cancelButtonText: '取消',
  				type: 'warning'
  			})
  				.then(() => {
  					this.afterSaleReason.splice(row,afterSaleReason.id);
  				})
  				.catch(() => {
            // console.log(88);
  				});
  		},
			handleClose(done) {
			        this.$confirm('确认关闭？')
			          .then(_ => {
			            done();
			          })
			          .catch(_ => {});
			      }

	      }
};
</script>
<style scoped>
.Reason-page .layoutbox {
	width: 50%;
	margin: 0 auto;
}
	.text{
	    display: flex;
		align-items: center;
	    left: 20px;
	    position: relative;
	    top: 15px;
	  }
	.search {
	  height: 75px;
	  background-color: #F5F5F5;
	  position: relative;
	  top: 16px;
	}
	.search-frame {
	  width: 100%;
	  height: 100px;
	  margin: auto;
	  background-color: #ffffff;
	}

	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px;
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
