<template>
    <div class="select New-page">
        <div class="select-table">

            <el-tabs v-model="activeName">
                <!--单数统计-->
                <el-tab-pane label="单数统计" name="first">
                    <!---->
                    <el-col :span="5">
                        <el-radio-group size="small" v-model="tabPosition">
                          <el-radio-button label="thisweek">本周</el-radio-button>
                          <el-radio-button label="lastweek">上周</el-radio-button>
                          <el-radio-button label="thismonth">本月</el-radio-button>
                          <el-radio-button label="lastmonth">上月</el-radio-button>
                        </el-radio-group>
                    </el-col>
                    <el-col :span="8">
                        &emsp; 日期：
                        <el-date-picker size="small" v-model="value1" type="datetime" placeholder="选择日期时间"></el-date-picker>
                        &emsp;
                        <el-button size="small" type="primary">搜索</el-button>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        退货计算方式：
                        <el-radio v-model="radio" label="1">按下单日期</el-radio>
                        <el-radio v-model="radio" label="2">按退货日期</el-radio>
                    </el-col>
                    <br>
                    <br>
                    <br>
                    <el-row :gutter="20">
                        <el-col :span="8">
                            <div class="content ">
                                <el-col :span="8">
                                    <div class="height flex_c_m">
                                        <div class=" flex_c_m">
                                            <img src="../../assets/Order.png" width="55px" />
                                        </div>
                                    </div>
                                </el-col>
                                <el-col :span="8" class="height"></el-col>
                                <el-col :span="8">
                                    <br>
                                    <span class="text1">{{top_list.order_count_total}}</span>
                                    <br>
                                    <span class="text">下单数量</span>
                                </el-col>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="content ">
                                <el-col :span="8">
                                    <div class="height flex_c_m">
                                        <div class=" flex_c_m">
                                            <img src="../../assets/pen.png" width="70px" />
                                        </div>
                                    </div>
                                </el-col>
                                <el-col :span="8" class="height"></el-col>
                                <el-col :span="8">
                                    <br>
                                    <span class="text1">{{top_list.order_cancel_total}}</span>
                                    <br>
                                    <span class="text">取消订单数</span>
                                </el-col>
                            </div>
                        </el-col>
                        <el-col :span="8">
                            <div class="content ">
                                <el-col :span="8">
                                    <div class="height flex_c_m">
                                        <div class=" flex_c_m">
                                            <img src="../../assets/Order.png" width="55px" />
                                        </div>
                                    </div>
                                </el-col>
                                <el-col :span="8" class="height"></el-col>
                                <el-col :span="8">
                                    <br>
                                    <span class="text1">{{top_list.order_refund_total}}</span>
                                    <br>
                                    <span class="text">退货笔数</span>
                                </el-col>
                            </div>
                        </el-col>
                    </el-row>
                    <!--多级表头列表-->
                    <br>
                    <el-table :data="order_list.slice((currentPage-1)*pagesize,currentPage*pagesize)" style="width: 100%; text-align: center;">
                        <el-table-column align="center" prop="create_time" label="下单时间">
                        </el-table-column>
                        <el-table-column label="订单数量">
                            <el-table-column align="center" prop="ali_price" label="余额支付">
                            </el-table-column>
                            <el-table-column align="center" prop="wx_price" label="微信支付">
                            </el-table-column>
                            <el-table-column align="center" prop="bank_price" label="积分支付">
                            </el-table-column>
                            <el-table-column align="center" prop="order_count" label="合计">
                            </el-table-column>
                        </el-table-column>
                        <el-table-column label="取消订单">
                            <el-table-column align="center" prop="can_ali_price" label="余额支付">
                            </el-table-column>
                            <el-table-column align="center" prop="can_wx_price" label="微信支付">
                            </el-table-column>
                            <el-table-column align="center" prop="can_count" label="合计">
                            </el-table-column>
                        </el-table-column>
                        <el-table-column label="退货订单数量">
                            <el-table-column align="center" prop="re_balance_price" label="余额支付">
                            </el-table-column>
                            <el-table-column align="center" prop="re_leader_price" label="团长余额退货">
                            </el-table-column>
                            <el-table-column align="center" prop="refund_count" label="合计">
                            </el-table-column>
                        </el-table-column>
                    </el-table>
                    <!--分页-->
                    <br>
                    <el-pagination class="block"
                    background
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="currentPage" :page-sizes="[5, 10, 20, 50]"
                    :page-size="pagesize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total">
                    </el-pagination>
                </el-tab-pane>
                <!--金额统计-->
                <el-tab-pane label="金额统计" name="second">

                    <!---->
                    <el-col :span="5">
                        <el-radio-group size="small" v-model="pricetabPosition">
                          <el-radio-button label="price_thisweek">本周</el-radio-button>
                          <el-radio-button label="price_lastweek">上周</el-radio-button>
                          <el-radio-button label="price_thismonth">本月</el-radio-button>
                          <el-radio-button label="price_lastmonth">上月</el-radio-button>
                        </el-radio-group>
                    </el-col>
                    <el-col :span="8">
                        &emsp; 日期：
                        <el-date-picker size="small" v-model="value1" type="datetime" placeholder="选择日期时间"></el-date-picker>
                        &emsp;
                        <el-button size="small" type="primary">搜索</el-button>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        退货计算方式：
                        <el-radio v-model="priceradio" label="1">按下单日期</el-radio>
                        <el-radio v-model="priceradio" label="2">按退货日期</el-radio>
                    </el-col>
                    <br>

                    <!--布局-->
                    <br>
                    <br>
                    <el-row :gutter="20">
                        <el-col :span="5">
                            <div class="content ">
                                <el-col :span="8">
                                    <div class="height flex_c_m">
                                        <div class=" flex_c_m">
                                            <img src="../../assets/Statistics1.png" width="55px" />
                                        </div>
                                    </div>
                                </el-col>

                                <el-col :span="16">
                                    <br>
                                    <span class="text1">{{pricetop_list.order_count_total}}</span>
                                    <br>
                                    <span class="text">订单总金额</span>
                                </el-col>
                            </div>
                        </el-col>
                        <el-col :span="5">
                            <div class="content ">
                                <el-col :span="8">
                                    <div class="height flex_c_m">
                                        <div class=" flex_c_m">
                                            <img src="../../assets/retreat.png" width="70px" />
                                        </div>
                                    </div>
                                </el-col>

                                <el-col :span="16">
                                    <br>
                                    <span class="text1">{{pricetop_list.order_cancel_total}}</span>
                                    <br>
                                    <span class="text">取消订单金额</span>
                                </el-col>
                            </div>
                        </el-col>
                        <el-col :span="4">
                            <div class="content ">
                                <el-col :span="8">
                                    <div class="height flex_c_m">
                                        <div class=" flex_c_m">
                                            <img src="../../assets/Statistics3.png" width="55px" />
                                        </div>
                                    </div>
                                </el-col>

                                <el-col :span="16">
                                    <br>
                                    <span class="text1">{{pricetop_list.order_refund_total}}</span>
                                    <br>
                                    <span class="text">退货金额</span>
                                </el-col>
                            </div>
                        </el-col>
                        <el-col :span="5">
                            <div class="content ">
                                <el-col :span="8">
                                    <div class="height flex_c_m">
                                        <div class=" flex_c_m">
                                            <img src="../../assets/Statistics4.png" width="55px" />
                                        </div>
                                    </div>
                                </el-col>

                                <el-col :span="16">
                                    <br>
                                    <span class="text1">{{pricetop_list.recharge_amount}}</span>
                                    <br>
                                    <span class="text">充值金额</span>
                                </el-col>
                            </div>
                        </el-col>
                        <el-col :span="5">
                            <div class="content ">
                                <el-col :span="8">
                                    <div class="height flex_c_m">
                                        <div class=" flex_c_m">
                                            <img src="../../assets/Statistics5.png" width="55px" />
                                        </div>
                                    </div>
                                </el-col>

                                <el-col :span="16">
                                    <br>
                                    <span class="text1">{{pricetop_list.money_total}}</span>
                                    <br>
                                    <span class="text">金额合计</span>
                                </el-col>
                            </div>
                        </el-col>
                    </el-row>
                    <br>
                    <br>
                    <!--多级表头列表-->
                    <el-table :data="priceorder_list.slice((pricecurrentPage-1)*pricepagesize,pricecurrentPage*pricepagesize)" style="width: 100%; text-align: center;">
                        <el-table-column align="center" prop="create_time" label="下单时间">
                        </el-table-column>
                        <el-table-column label="下单金额">
                            <el-table-column align="center" prop="ali_price" label="余额支付">
                            </el-table-column>
                            <el-table-column align="center" prop="wx_price" label="微信支付">
                            </el-table-column>

                            <el-table-column align="center" prop="bank_price" label="合计">
                            </el-table-column>
                        </el-table-column>
                        <el-table-column label="取消订单数量">
                            <el-table-column align="center" prop="can_ali_price" label="余额支付">
                            </el-table-column>
                            <el-table-column align="center" prop="can_wx_price" label="微信支付">
                            </el-table-column>
                            <el-table-column align="center" prop="can_bank_price" label="合计">
                            </el-table-column>
                        </el-table-column>
                        <el-table-column label="退货金额">
                            <el-table-column align="center" prop="re_balance_price" label="余额支付">
                            </el-table-column>
                            <el-table-column align="center" prop="re_wx_price" label="微信支付">
                            </el-table-column>
                            <el-table-column align="center" prop="re_leader_price" label="团长余额">
                            </el-table-column>
                            <el-table-column align="center" prop="refund_count" label="合计">
                            </el-table-column>

                        </el-table-column>
                        <el-table-column label="充值金额">
                            <el-table-column align="center" prop="shop_mall" label="商城充值">
                            </el-table-column>
                            <el-table-column align="center" prop="backstage" label="后台充值">
                            </el-table-column>
                        </el-table-column>
                        <el-table-column align="center" prop="amount_total" label="小计">
                        </el-table-column>
                    </el-table>
                    <!--分页-->
            				 <el-pagination class="block"
            						 background
            						 @size-change="priceSizeChange"
            						 @current-change="priceCurrentChange"
            						 :current-page="pricecurrentPage"
            						 :page-sizes="[5, 10, 20, 50]"
            						 :page-size="pricepagesize"
            						 layout="total, sizes, prev, pager, next, jumper"
            						 :total="pricetotal">
            					 </el-pagination>
                    <br>
                </el-tab-pane>
            </el-tabs>
        </div>
    </div>
</template>
<script>
import axios from '../../axios.js'
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
import VeLine from 'v-charts/lib/line'
    export default {
        data() {
                return {
                    activeName: 'first',
                    tabPosition: 'thisweek',
                    pricetabPosition: 'price_thisweek',
                    value1: '',
                    value2: '',
                    radio: '1',
                    priceradio: '1',
                    total: 0,
                    currentPage: 1,
                    pagesize: 5,
                    pricetotal: 0,
                    pricecurrentPage: 1,
                    pricepagesize: 5,
                    top_list:[],
                    order_list:[],
                    pricetop_list:[],
                    priceorder_list:[],
                };
            },
            created() {
                this.getData();
            },
            methods: {
                handleClick(tab, event) {
                    console.log(tab, event);
                },
                // 获取数据
                async getData() {
                    const result = await axios.get(Rootpath.BASE_URL + 'business_new?type_time=' + this.tabPosition+'&type='+this.radio);
                    // console.log(result.data);
                    this.top_list = result.data.top_list;
                    this.order_list = result.data.order_list;
                    this.total = result.data.order_list.length;
                    const json = await axios.get(Rootpath.BASE_URL + 'business_price?type_time=' + this.pricetabPosition+'&type='+this.priceradio);
                    this.pricetop_list = json.data.top_list;
                    this.priceorder_list = json.data.order_list;
                    this.pricetotal = json.data.order_list.length;
                },
                handleSizeChange(size) {
                    this.pagesize = size;
                },
                handleCurrentChange(currentPage) {
                    this.currentPage = currentPage;
                },
            		priceSizeChange(pricesize) {
            			this.pricepagesize = pricesize
            		},
            		priceCurrentChange(pricecurrentPage) {
            			this.pricecurrentPage = pricecurrentPage
            		},
            }
    };
</script>
<style scoped>
    .select-table {
        margin: auto;
        width: 96%;
        margin-top: 20px;
    }
    .block {
        text-align: right;
    }
    .select {
        margin: auto;
        width: 96%;
        background-color: #ffffff;
    }
    .text {
        font-size: 14px;
    }
    .text1 {
        font-size: 30px;
    }
    .content {
        height: 80px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
    }
    .height {
        border: solid 1rpx #007AFF;
        height: 80px;
    }
    .Border {
        box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
    }
</style>
