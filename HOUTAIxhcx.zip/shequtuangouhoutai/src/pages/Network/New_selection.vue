<template>
  <div class="New_selection-page" style="margin: 20px;">
	  <el-tabs v-model="activeName">
			<el-tab-pane label="活动设置" name="firsts">
						<div style="width:30%;">
						   <el-form ref="selected_data" :data="selected_data" label-width="110px">
						     <el-form-item label="*活动名称:">
						       <el-input v-model="selected_data.activity_name" style="width:220px;"></el-input>
						     </el-form-item>
						     <el-form-item label="*生效时间：">
						        <el-date-picker
						            v-model="selected_data.activity_start_time"
						            type="datetime"
						            placeholder="选择日期时间">
						          </el-date-picker>
						     </el-form-item>
							 <el-form-item label="*开始时间:">
							    <el-date-picker
							        v-model="selected_data.activity_begin_time"
							        type="datetime"
							        placeholder="选择日期时间">
							      </el-date-picker>
							 </el-form-item>
							 <el-form-item label="*结束时间:">
							    <el-date-picker
							        v-model="selected_data.activity_end_time"
							        type="datetime"
							        placeholder="选择日期时间">
							      </el-date-picker>
							 </el-form-item>
							 <el-form-item label="到货日期类型：">
							   <el-radio-group v-model="selected_data.arrived_time">
							     <el-radio label="指定日期"></el-radio>
							     <el-radio label="指定天气"></el-radio>
							   </el-radio-group>
							 </el-form-item>
							 <el-form-item label="*活动排序：">
							   <el-input v-model="selected_data.order_by"  style="width:220px;"></el-input>
							 </el-form-item>
						     <el-form-item label="即时配送：">
						       <el-switch v-model="selected_data.style"></el-switch>
						     </el-form-item>
							 <el-form-item label="样式选择：">
							   <el-radio-group v-model="selected_data.style">
							     <el-radio label="大图模式"></el-radio>
							     <el-radio label="小图模式"></el-radio>
							   </el-radio-group>
							   <div> <img src="../../assets/404.png" style="width:158px;height:90px;"/></div>
							 </el-form-item>
							 <el-form-item label="适用团长：">
							   <el-radio-group v-model="selected_data.name">
							     <el-radio label="所有团长"></el-radio>
							     <el-radio label="选择团长"></el-radio>
							   </el-radio-group>
							 </el-form-item>
							 <el-form-item label="购买权限：">
							   <el-radio-group v-model="selected_data.name">
							     <el-radio label="所有会员"></el-radio>
							     <el-radio label="新会员"></el-radio>
							   </el-radio-group>
							 </el-form-item>
						   </el-form>
						  <div style="margin-left:35px;padding-bottom: 25px;">
							  <el-button type="primary">取消</el-button>
							  <el-button type="primary">保存</el-button>
						  </div>
						   		</div>

			</el-tab-pane>


		  <!-- 两个切换html -->

	     <el-tab-pane label="活动商品" name="first">
				 <el-button type="primary" @click="New_activities=true">新增活动商品</el-button>
				<!-- 活动商品新增页面 -->
				 <el-dialog
				 		   title="请选择商品"
				 		   :visible.sync="New_activities"
				 		   width="50%">
				 		   <hr />
				   <div>
				 			<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				 			<el-form-item label="状态" style="margin-top: 20px;">
				 			 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
				 				<el-option
				 				  v-for="item in options"
				 				  :key="item.value"
				 				  :label="item.label"
				 				  :value="item.value">
				 				</el-option>
				 			  </el-select>
				 			</el-form-item>
				 			<el-form-item label="商品名称" style="margin-top: 20px;">
				 					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				 			</el-form-item>
				 			<el-form-item label="编码" style="margin-top: 20px;">
				 					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				 			</el-form-item>
							<el-form-item label="分类" style="margin-top: 20px;">
									<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
							</el-form-item>
				 			<el-form-item>
				 			<el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">保存</el-button>
				 			</el-form-item>
				 			</el-form>
				    <el-table
				       ref="multipleTable"
				       :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)"
				       tooltip-effect="dark"
				       style="width: 100%">
				       <el-table-column
				         type="selection"
				         width="55">
				       </el-table-column>
				       <el-table-column
				         label="商品图片"
				         width="120">
				         <template slot-scope="scope">
							 <img src="../../assets/logo.png" style="height: 25px;width:25px;" />
						 </template>
				       </el-table-column>
				       <el-table-column
				         prop="name"
				         label="商品名称"
				         width="120">
				       </el-table-column>
				       <el-table-column
				         prop="address"
				         label="单位"
				         show-overflow-tooltip>
				       </el-table-column>
				 	  <el-table-column
				 	    prop="address"
				 	    label="商城价"
				 	    show-overflow-tooltip>
				 	  </el-table-column>
					  <el-table-column
					    prop="address"
					    label="操作"
					    show-overflow-tooltip>
						<template slot-scope="scope">
							 <el-button type="text" size="small">添加</el-button>
						</template>
					  </el-table-column>
				     </el-table>
				 		</div>
				   <div style="padding-left:72%;height: 32px;"><!-- 分页点击栏靠右边 -->
				   		<span>1/6页,45条结果</span>
				   		<el-input-number size="mini" v-model="num" controls-position="right" @change="handleChange" :min="1" style="width:80px;"></el-input-number>
				   		<span class="menu-icon"><i class="el-icon-arrow-left" /></span>
				   		<span class="menu-icon"><i class="el-icon-arrow-right" /></span>
				   		<el-button size="mini">指定跳转</el-button>
				   </div>

				 	<hr />
				    <span slot="footer">
				 	 <el-button @click="New_activities = false">取 消</el-button>
				 	 <el-button type="primary" @click="New_activities = false">确 定</el-button>
				    </span>
				 </el-dialog>
					<div style="margin-top:15px;">
						<el-table
						    :data="tableData"
						    stripe
						    style="width: 100%">
						    <el-table-column
							   prop="name"
							  align="center"
						      label="商品名称"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="name"
						      label="单位"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="address"
						      label="商城价">
						    </el-table-column>
							<el-table-column
							  align="center"
							  prop="address"
							  label="活动价格">
							  <template slot-scope="scope">
								  <el-input type="text"  value="99" size="small" class="inputxt"></el-input>
							  </template>
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="address"
							  label="单日限购">
							  <template slot-scope="scope">
							  		<el-input type="text"  value="99" size="small" class="inputxt"></el-input>
							  </template>
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="address"
							  label="活动库存">
							  <template slot-scope="scope">
							  		<el-input type="text"  value="99" size="small" class="inputxt"></el-input>
							  </template>
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="address"
							  label="排序号">
							  <template slot-scope="scope">
							  		<el-input type="text"  value="99" size="small" class="inputxt"></el-input>
							  </template>
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="address"
							  label="销量">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="address"
							  label="预计到货时间">
							  <template slot-scope="scope">
							  <el-select v-model="value" placeholder="请选择">
							      <el-option
							        v-for="item in options"
							        :key="item.value"
							        :label="item.label"
							        :value="item.value">
							      </el-option>
							    </el-select>
							  </template>
							</el-table-column>
							<el-table-column label="状态" width="" align="center" >

									  <template slot-scope="scope">
										<el-switch class="switchStyle" v-model="scope.row.on"
										active-color="#00A854"
										 active-value="00000000"
                                        inactive-color="#F04134"
										active-text="上架"
										inactive-text="下架">
										</el-switch>
									  </template>
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="address"
							  label="操作">
							 <template slot-scope="scope">
							 	        <el-button @click="handleClick(scope.$index)" type="text" size="small">删除</el-button>
							 </template>
							 	    </el-table-column>
						  </el-table>
						 <div style="margin:20px;">
							 <el-button type="primary">取消</el-button>
							   <el-button type="primary">保存</el-button>
						 </div>
					</div>

		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  name: 'first',
  components: {},
   data() {
        return {
			New_activities:false,
			 activeName: 'first',
       total: 0,
       currentPage: 1,
       pagesize: 5,
			 switchs:'',
       selected_data:[],
       choice_data:[],
			  num: 1,
			   formInline: {
			            user: '',
			            region: ''
			          },
          tableData: [{
            date: '2016-05-02',
            name: '王小虎',
            address: '上海市普陀区金沙江路 '
          }, {
            date: '2016-05-04',
            name: '王小虎',
            address: '上海市普路 '
          }, {
            date: '2016-05-01',
            name: '王小虎',
            address: '上海市江路 '
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀 '
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '32'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市江路'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市江路'
          },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '32'
		  }],
		  form: {
		            name: '',
		            region: '',
		            date1: '',
		            date2: '',
		            delivery: false,
		            type: [],
		            resource: '',
		            desc: ''
		          },
				          value1: '',
				          value2: '',
				          value3: '',
		      options: [{
		            value: '选项1',
		            label: '黄金糕'
		          }, {
		            value: '选项2',
		            label: '双皮奶'
		          }, {
		            value: '选项3',
		            label: '蚵仔煎'
		          }, {
		            value: '选项4',
		            label: '龙须面'
		          }, {
		            value: '选项5',
		            label: '北京烤鸭'
		          }],
		          value: ''
		        }
      },
      created() {
    			this.getData();
    	},
	   methods: {
       //分页
       handleSizeChange(size) {
         this.pagesize = size
       },
       handleCurrentChange(currentPage) {
         this.currentPage = currentPage
       },
       // 获取数据
       async getData() {
           let that = this;
           axios.post(Rootpath.BASE_URL + 'sel_add', {
             selected_data:that.selected_data,
             choice_data:thaat.choice_data
               })
               .then(function (response) {
                   // that.dialogFormVisible = false;
                   console.log(that.response);
               })
               .catch(function (error) {
                   console.log(error);
               });
           // this.total=result.data.choice_data.length;
       },
	        handleChange(value) {
	          console.log(value);
	        },

			handleClick(index){
				this.tableData.splice(index,1);
			},
			onSubmit() {
			        console.log('submit!');
			      },
	      }
};
</script>
<style >/* 请勿加上scope,因为此公共样式是受某种原因限制的 */
.switchStyle .el-switch__label {
  position: absolute;
  display: none;
color: #436BE5;
}
.switchStyle .el-switch__label--left {
	/* 关闭的提示 */
  z-index: 999999;
  left:5px;
  color:#FFFFFF;
}
.switchStyle .el-switch__label--right {
/* 	开启的提示 */
	  color:#FFFFFF;
  z-index: 999999;
  left: -15px;
}
.switchStyle .el-switch__label.is-active {
  display: block;
}
.switchStyle.el-switch .el-switch__core,
.el-switch .el-switch__label {
  width:60px !important;
}
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px;
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
	}
</style>
