<template>
  <div class="Network-page" style="margin: 20px;">
	  <el-tabs v-model="activeName">
	     <el-tab-pane label="首页精选" name="first">
				<div>
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				  <el-form-item label="状态" style="margin-top: 20px;">
					 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
					    <el-option
					      v-for="item in options"
					      :key="item.value"
					      :label="item.label"
					      :value="item.value">
					    </el-option>
					  </el-select>
				  </el-form-item>
				  <el-form-item label="活动日期" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="活动名称" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item>
					<el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>
				  </el-form-item>
				</el-form>
				</div>
				 <el-button type="primary" @click="increase()">新增</el-button>
					<div style="margin-top:15px;">
						<el-table
						    :data="selected_list.slice((currentPage-1)*pagesize,currentPage*pagesize)"
						    stripe
						    style="width: 100%">
						    <el-table-column
							   prop="activity_name"
							  align="center"
						      label="活动名称"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="activity_start_time"
						      label="生效时间"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="activity_end_time"
						      label="结束时间">
						    </el-table-column>
							<el-table-column
							  align="center"
							  prop="activity_count"
							  label="活动商品数">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="order_by"
							  label="销量">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="arrived_time"
							  label="预计到货时间">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="activity_begin_time"
							  label="活动创建时间">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="state"
							  label="状态">
                <!-- <template slot-scope="scope">
                  <span v-if="scope.row.state===1">进行中</span>
                  <span v-if="scope.row.state===0">结束</span>
                  <el-input v-model="scope.row.state" size="mini" style="width:100px"></el-input>
                </template> -->
							</el-table-column>
							<el-table-column
							  align="center"
							  label="操作">
							 <template slot-scope="scope">
							 	        <el-button @click="handleClick(scope.row)" type="text" size="small">详情</el-button>
                        <el-button type="text" v-if="scope.row.state===1" size="small">编辑</el-button>
                        <el-button type="text" size="small" @click="deletedata(scope.$index)">复制活动</el-button>
							 	        <el-button type="text" v-if="scope.row.state===1" size="small">关闭</el-button>
							 	      </template>
							 	    </el-table-column>
						  </el-table>
              <!--分页-->
               <el-pagination class="block"
                   background
                   @size-change="handleSizeChange"
                   @current-change="handleCurrentChange"
                   :current-page="currentPage"
                   :page-sizes="[5, 10, 20, 50]"
                   :page-size="pagesize"
                   layout="total, sizes, prev, pager, next, jumper"
                   :total="total">
                 </el-pagination>
					</div>

		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  name: 'first',
  components: {},
   data() {
        return {
          total: 0,
    			currentPage: 1,
    			pagesize: 5,
			 activeName: 'first',
			  num: 1,
			   formInline: {
			            user: '',
			            region: ''
			          },
          selected_list: [],
		      options: [{
		            value: '选项1',
		            label: '黄金糕'
		          }, {
		            value: '选项2',
		            label: '双皮奶'
		          }, {
		            value: '选项3',
		            label: '蚵仔煎'
		          }, {
		            value: '选项4',
		            label: '龙须面'
		          }, {
		            value: '选项5',
		            label: '北京烤鸭'
		          }],
		          value: ''
		        }
      },
      created() {
          this.getData();
      },
	   methods: {
       //详情
       details(row){
         this.$router.push({path:'/market/Seckill/Seckill_details',query: {id:row.id}})
       },
       // 获取数据
       async getData() {
         const result = await axios.get(Rootpath.BASE_URL + 'sel_list');
         console.log(result.data);
         this.selected_list = result.data.selected_list;
         // console.log();
         this.total = result.data.selected_list.length;
       },
       //分页
       handleSizeChange(size) {
         this.pagesize = size
       },
       handleCurrentChange(currentPage) {
         this.currentPage = currentPage
       },
	        handleChange(value) {
	          console.log(value);
	        },
			onSubmit() {
			        console.log('submit!');
			      },
				  increase(){
					  this.$router.push({path:'/market/network/New_selection',query: {id:1}})
				  }
	      }
};
</script>
<style scoped>
	.text{
	    display: flex;
		align-items: center;
	    left: 20px;
	    position: relative;
	    top: 15px;
	  }
	.search {
	  height: 75px;
	  background-color: #F5F5F5;
	  position: relative;
	  top: 16px;
	}
	.search-frame {
	  width: 100%;
	  height: 100px;
	  margin: auto;
	  background-color: #ffffff;
	}
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px;
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
