<template>
  <div class="Seckill-page" style="margin: 20px;">
	  <el-tabs v-model="activeName">
	     <el-tab-pane label="秒杀商品" name="first">
				<div>
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				  <el-form-item label="状态" style="margin-top: 20px;">
					 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
					    <el-option
					      v-for="item in options"
					      :key="item.value"
					      :label="item.label"
					      :value="item.value">
					    </el-option>
					  </el-select>
				  </el-form-item>
          <el-form-item label="全部分类" style="margin-top: 20px;">
				  					 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
				  					    <el-option
				  					      v-for="item in options"
				  					      :key="item.value"
				  					      :label="item.label"
				  					      :value="item.value">
				  					    </el-option>
				  					  </el-select>
				  </el-form-item>
				  <el-form-item label="生效时间" style="margin-top: 20px;">
				  					<!-- <el-input  size="small" v-model="searchlist.activity_begin_time" style="width: 120px;"></el-input> -->
                    <el-date-picker
                    v-model="bigin_time"
                    type="daterange"
                    range-separator="-"
                    start-placeholder="开始日期"
                    end-placeholder="结束日期"
                    size="small">
                  </el-date-picker>
				  </el-form-item>

				  <el-form-item label="活动名称" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="searchlist.activity_name" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item style="margin-top: 20px;">
					<el-button  size="small" type="primary" @click="search">搜索</el-button>
				  </el-form-item>
				</el-form>
				</div>
				 <el-button type="primary" @click="increase()">新增</el-button>
					<div style="margin-top:15px;">
						<el-table
						    :data="activity_list.slice((currentPage-1)*pagesize,currentPage*pagesize)"
						    stripe
						    style="width: 100%">
						    <el-table-column
							   prop="activity_name"
							  align="center"
						      label="活动名称"
						      >
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="activity_begin_time"
						      label="生效时间"
						      >
						    </el-table-column>
						    <el-table-column
							  align="center"
						      prop="activity_end_time"
						      label="结束时间">
						    </el-table-column>
							<el-table-column
							  align="center"
							  prop="activity_num"
							  label="活动商品数">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="activity_count"
							  label="销量">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="arrived_time"
							  label="预计到货时间">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="activity_create_time"
							  label="活动创建时间">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="state"
							  label="状态">
							</el-table-column>
							<el-table-column
							  align="center"
							  prop="address"
							  label="操作">
							 <template slot-scope="scope">
							 	        <el-button @click="details(scope.row)" type="text" size="small">详情</el-button>
							 	        <el-button type="text" size="small" @click="copy(scope.row)">复制活动</el-button>
							 	      </template>
							 	    </el-table-column>
						  </el-table>
              <!--分页-->
    					 <el-pagination class="block"
    					     background
    					     @size-change="handleSizeChange"
    					     @current-change="handleCurrentChange"
    					     :current-page="currentPage"
    					     :page-sizes="[5, 10, 20, 50]"
    					     :page-size="pagesize"
    					     layout="total, sizes, prev, pager, next, jumper"
    					     :total="total">
    					   </el-pagination>
					</div>

		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  name: 'first',
  components: {},
   data() {
        return {
          // start_time:'',
          bigin_time:'',
          searchlist:{
            state:'',
            activity_name:'',
            activity_begin_time:''
          },
          total: 0,
    			currentPage: 1,
    			pagesize: 5,
			 activeName: 'first',
			  num: 1,
			   formInline: {
			            user: '',
			            region: ''
			          },
          tableData: [],
          activity_list:[],
		      options: [{
		            value: '选项1',
		            label: '黄金糕'
		          }, {
		            value: '选项2',
		            label: '双皮奶'
		          }, {
		            value: '选项3',
		            label: '蚵仔煎'
		          }, {
		            value: '选项4',
		            label: '龙须面'
		          }, {
		            value: '选项5',
		            label: '北京烤鸭'
		          }],
		          value: ''
		        }
      },
      created() {
    			this.getData();
    	},
	   methods: {
	        handleChange(value) {
	          console.log(value);
	        },
          //搜索
          async search() {
              let that = this;
              axios.get(Rootpath.BASE_URL + 'seckill_search', {
                      params: {
                          state: that.value,
                          activity_name: that.searchlist.activity_name,
                          activity_begin_time: that.bigin_time,
                      }
                  })
                  .then(function (response) {
                      console.log(response);
                      if(response.data==''){
                        console.log("数据为空");
                      }else{
                        // this.activity_list=response.data.activity_list;
                        // this.total=response.data.activity_list.length;
                      }
                      // that.user_list = response.data.user_list
                      // that.total = response.data.user_list.length
                      // this.activity_list=response.data.activity_list;
                      // this.total=response.data.activity_list.length;
                  })
                  .catch(function (error) {
                      console.log(error);
                  });
          },
          //分页
      		handleSizeChange(size) {
      		  this.pagesize = size
      		},
      		handleCurrentChange(currentPage) {
      		  this.currentPage = currentPage
      		},
          // 获取数据
      		async getData() {
      				const result = await axios.get(Rootpath.BASE_URL + 'seckill');
      				console.log(result);
              this.activity_list=result.data.activity_list;
              this.total=result.data.activity_list.length;
      		},
          //跳转新增页面
				  increase(){
				  		 this.$router.push({path:'/market/Seckill/Spike_added',query: {id:1}})
				  },//跳转详情页面
				  details(row){
					  this.$router.push({path:'/market/Seckill/Seckill_details',query: {id:row.id}})
				  },//跳转复制活动页面
				  copy(){
					   this.$router.push({path:'/market/Seckill/Seckill_copy',query: {id:1}})
				  },
	      }
};
</script>
<style scoped>
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px;
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
