<template>
    <div class="Spike_added-page" style="margin: 20px;">
        <el-tabs v-model="activeName">
            <el-tab-pane label="新增商品" name="first">
                <!-- 秒杀商品/选择商品 -->
                <el-dialog title="请选择商品" :visible.sync="New_products" width="820px">
                    <hr />
                    <div>
                        <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
                            <el-form-item label="状态">
                                <el-select v-model="value" placeholder="请选择" style="width: 120px;" size="small">
                                    <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item label="商品名称">
                                <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                            </el-form-item>
                            <el-form-item label="编码">
                                <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                            </el-form-item>
                            <el-form-item label="分类">
                                <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                            </el-form-item>
                            <el-form-item>
                                <el-button size="small" type="primary" @click="onSubmit">搜索</el-button>
                            </el-form-item>
                        </el-form>
                        <el-table ref="multipleTable"
                         :data="choice_list.slice((currentPage-1)*pagesize,currentPage*pagesize)" @select="clickrow" @select-all="clickallrow" tooltip-effect="dark" style="width: 100%">
                            <el-table-column type="selection" width="55">
                            </el-table-column>
                            <el-table-column prop="img_url" label="商品图片" >
                              <template   slot-scope="scope">
                                <img v-for="(item,index) in scope.row.img_url" :src="item.img_url"  min-width="40" height="40" />
                              </template>
                            </el-table-column>
                            <el-table-column prop="product_name" label="商品名称" >
                            </el-table-column>
                            <el-table-column prop="good_unit" label="单位" show-overflow-tooltip>
                            </el-table-column>
                            <el-table-column prop="product_price" label="商城价" show-overflow-tooltip>
                            </el-table-column>
                            <el-table-column prop="address" label="操作" show-overflow-tooltip>
                                <template slot-scope="scope">
                                  <el-button type="text" v-if="scope.row.selection_type==true" size="small" disabled>添加</el-button>
                                  <el-button type="text" v-if="scope.row.selection_type==false" size="small" @click="Addto(scope.row)">添加</el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                        <!--分页-->
              					 <el-pagination class="block"
              					     background
              					     @size-change="handleSizeChange"
              					     @current-change="handleCurrentChange"
              					     :current-page="currentPage"
              					     :page-sizes="[5, 10, 20, 50]"
              					     :page-size="pagesize"
              					     layout="total, sizes, prev, pager, next, jumper"
              					     :total="total">
              					   </el-pagination>
                    </div>

                    <hr />
                    <span slot="footer" class="dialog-footer">
			  	 <el-button @click="New_products = false">取 消</el-button>
			  	 <el-button type="primary" @click="goodsaddto">批量添加</el-button>
			     </span>
                </el-dialog>

                <div style="margin-left:10px ;" id="Input_box">
                    <div class="headtitle" style="line-height:25px;"><i class="iconfont">&#xe685;</i>温馨提示：活动名称是商家对推荐商品活动的别名操作，请使用例如“爆款抢购”、“爆款秒杀”类短语表现，限4字：默认显示“秒杀商品”字样。</div>
                    <div style="width:50%;align-self: flex-start;margin:30px 0px 0px 0px;">
                        <el-form ref="activity_data" :model="activity_data" label-width="170px">
                            <el-form-item label="*活动名称">
                                <el-input v-model="activity_data.activity_name" style="width:240px;left:10px;"></el-input>
                            </el-form-item>
                            <el-form-item label="*生效时间">
                                <el-date-picker type="date" placeholder="选择日期" v-model="activity_data.activity_begin_time" style="width:240px;left:10px;"></el-date-picker>

                            </el-form-item>
                            <el-form-item label="*预计到货时间">
                                <el-col :span="11">
                                    <el-date-picker type="date" placeholder="选择日期" v-model="activity_data.arrived_time" style="width:240px;left:10px;"></el-date-picker>
                                </el-col>
                            </el-form-item>
                            <el-form-item label="活动到期商品自动下架">
                                <el-switch @change="swichchange" v-model="activity_data.delivery" style="left:10px;"></el-switch>
                            </el-form-item>
                            <el-form-item label="活动商品">
                                <el-button type="primary" @click="New_products=true">选择商品</el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                    <el-table :data="choice_data" style="width: 100% ">
                        <el-table-column align="center" prop="product_name" label="商品名称">
                        </el-table-column>
                        <el-table-column align="center" prop="good_unit" label="单位">
                        </el-table-column>
                        <el-table-column align="center" prop="product_price" label="商城价">
                        </el-table-column>
                        <el-table-column align="center" prop="activity_price" label="活动价格">
                          <template slot-scope="scope">
                              <el-input v-model="scope.row.activity_price" size="mini" style="width:100px"></el-input>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" prop="limits_shopping" label="单人限购">
                          <template slot-scope="scope">
                              <el-input v-model="scope.row.limits_shopping" size="mini" style="width:100px"></el-input>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" prop="activity_stock" label="活动库存">
                          <template slot-scope="scope">
                              <el-input v-model="scope.row.activity_stock" size="mini" style="width:100px"></el-input>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" prop="start_time" label="开始时间">
                          <template slot-scope="scope">
                            <el-date-picker
                            v-model="scope.row.start_time"
                            type="datetime"
                            style="width:150px"
                            placeholder="选择日期时间">
                            </el-date-picker>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" prop="end_time" label="结束时间">
                            <template slot-scope="scope">
                              <el-date-picker
                              v-model="scope.row.end_time"
                              type="datetime"
                              style="width:150px"
                              placeholder="选择日期时间">
                              </el-date-picker>
                            </template>
                        </el-table-column>
                        <el-table-column
                          prop="state"
                          label="状态"
                          align="center">
                          <template slot-scope="scope">
                          <el-switch
            			          class="switchStyle"
                            v-model="scope.row.state"
                            active-color="#13ce66"
                            inactive-color="#ff4949"
                            :active-value="1"
                            :inactive-value="-1"
                            active-text="上架"
                            inactive-text="下架">
                          </el-switch>
                          </template>
                        </el-table-column>
                        <el-table-column align="center" prop="sale_count" label="销量">
                          0
                        </el-table-column>
                        <el-table-column align="center" label="操作">
                          <template slot-scope="scope">
            								<el-button type="text" size="small" @click="deleterow(scope.$index,choice_data)">删除</el-button>
            							</template>
                        </el-table-column>
                    </el-table>
                </div>
                <el-button size="small" type="primary" @click="returnback">返回</el-button>
                <el-button size="small" type="primary" @click="addsave">保存</el-button>
            </el-tab-pane>
        </el-tabs>
    </div>
</template>
<script>
    import axios from '../../axios.js';
    import https from "../../../api/https.vue"
    import Rootpath from "../../../api/index.js"
    import qs from '../../../node_modules/qs'
    export
    default {
        name: 'first',
        components: {},
        total: 0,
  			currentPage: 1,
  			pagesize: 5,
        data() {
            return {
                New_products: false, //选择商品弹窗
                activeName: 'first',
                choice_list:[],
                total: 0,
          			currentPage: 1,
          			pagesize: 5,
                activity_data:{
                  company_id:1,//城市id
                  activity_name:"活动名称",//活动名称
                  activity_begin_time:"",//开始时间
                  arrived_time:"",//结束时间
                  delivery:false
                 },
                 choice_data: [//秒杀商品信息
                    // {
                    //     product_id: 1,//商品id
                    //     product_number:"111123a",//商品编号
                    //     activity_price: "1",//活动价
                    //     limits_shopping: "2",//限购
                    //     activity_stock: 13,//库存
                    //     start_time: "111",//开始时间 时间戳
                    //     end_time: "123213",//结束时间 //时间戳
                    //     state: null,//状态1 上架 -1下架
                    //     sale_count: "0"//销量
                    // }
                  ],
                form: {
                    activity_name: '',
                    activity_begin_time: '',
                    arrived_time:'',
                    delivery: false,
                },
                num: 1,
                formInline: {
                    user: '',
                    region: ''
                },
                tableData: [{}],
                options: [{
                    value: '选项1',
                    label: '黄金糕'
                }, {
                    value: '选项2',
                    label: '双皮奶'
                }, {
                    value: '选项3',
                    label: '蚵仔煎'
                }, {
                    value: '选项4',
                    label: '龙须面'
                }, {
                    value: '选项5',
                    label: '北京烤鸭'
                }],
                value: '',
                seleteinfo:[],
            }
        },
        created() {
            this.getData();
        },
        methods: {
          //删除
          deleterow(index,row){
            row.splice(index, 1)
          },
          //分页
      		handleSizeChange(size) {
      		  this.pagesize = size
      		},
      		handleCurrentChange(currentPage) {
      		  this.currentPage = currentPage
      		},
          //点击获取数据
          clickrow(val){
            this.seleteinfo.push(val[0]);
            console.log(2);
          },
          //全选数据
          clickallrow(val){
            for (var i = 0; i < val.length; i++) {
              this.seleteinfo.push(val[i]);
            }

          },
          goodsaddto(){
            for (var i = 0; i < this.seleteinfo.length; i++) {
              this.choice_data.push(this.seleteinfo[i]);
            }
            this.seleteinfo=[];
          },
          //添加
          Addto(row){
            console.log(row);
            this.choice_data.push(row);
          },
          //返回
            returnback() {
                    this.$router.push({
                        path: '/market/Seckill'
                    })
                },
                swichchange(){
                  // this.form.delivery=this.form.delivery;
                  console.log(this.form.delivery);
                },
                // 获取数据
                async getData() {
                  const result = await axios.get(Rootpath.BASE_URL + 'add_choice');
                  // console.log(result.data);
                  this.choice_list = result.data.choice_list;
                  // console.log();
                  this.total = result.data.choice_list.length;
                },
                //保存
                addsave() {
                    let that = this;
                    axios.post(Rootpath.BASE_URL + 'create_choice', {
                      activity_data: that.activity_data,
                      choice_data: that.choice_data,
                        })
                        .then(function (response) {
                            // that.dialogFormVisible = false;

                            console.log(response);
                        })
                        .catch(function (error) {
                            console.log(error);
                        });
                },
                handleChange(value) {
                    console.log(value);
                },
                onSubmit() {
                    console.log('submit!');
                },
        }
    };
</script>
<style scoped>
    .text {
        display: flex;
        align-items: center;
        left: 20px;
        position: relative;
        top: 15px;
    }
    .search {
        height: 75px;
        background-color: #F5F5F5;
        position: relative;
        top: 16px;
    }
    .search-frame {
        width: 100%;
        height: 100px;
        margin: auto;
        background-color: #ffffff;
    }
    .paging {
        position: fixed;
        right: 0px;
        bottom: 0px;
        background: #FAFAFA;
        width: 100%;
        height: 40px;
        float: right;
        line-height: 0px;
        z-index: 999;
        box-shadow: darkgrey 10px 10px 30px 5px;
    }
    @font-face {
        font-family: 'iconfont';
        /* project id 1395133 */
        src: url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.eot');
        src: url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.eot?#iefix') format('embedded-opentype'), url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.woff2') format('woff2'), url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.woff') format('woff'), url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.ttf') format('truetype'), url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.svg#iconfont') format('svg');
    }
    .iconfont {
        font-family: "iconfont" !important;
        font-size: 16px;
        font-style: normal;
        -webkit-font-smoothing: antialiased;
        -webkit-text-stroke-width: 0.2px;
        -moz-osx-font-smoothing: grayscale;
    }
    .headtitle {
        background: rgba(168, 183, 227, 1);
        border: 1px solid rgba(67, 107, 229, 1);
        border-radius: 0px 0px 6px 6px;
        width: 1150px;
        height: 25px;
    }
    /* 更改默认element输入框样式 */
    #Input_box .el-form-item__label {
        width: 160px!important;
    }
</style>
