<template>
  <div class="Service-page" style="margin: 20px;">
	  <el-tabs v-model="activeName" @tab-click="handleClick">
	     <el-tab-pane label="商品详情" name="first">
			
<div style="margin-left:10px ;" id="Input_box">
				<div class="headtitle" style="line-height:25px;"><i class="iconfont">&#xe685;</i>温馨提示：活动名称是商家对推荐商品活动的别名操作，请使用例如“爆款抢购”、“爆款秒杀”类短语表现，限4字：默认显示“秒杀商品”字样。</div>
				<div style="width:50%;align-self: flex-start;margin:30px 0px 0px 0px;">
					<el-form ref="form" :model="form" label-width="90px">
					  <el-form-item label="*活动名称">
					    <el-input v-model="form.name" style="width:240px;left:10px;"></el-input>
					  </el-form-item>
					  <el-form-item label="*生效时间">
					      <el-date-picker type="date" placeholder="选择日期" v-model="form.date1" style="width:240px;left:10px;"></el-date-picker>
					  </el-form-item>
					  <el-form-item label="*预计到货时间">
					    <el-col :span="11">
					      <el-date-picker type="date" placeholder="选择日期" v-model="form.date1" style="width:240px;left:10px;"></el-date-picker>
					    </el-col>
					  </el-form-item>
					  <el-form-item label="活动到期商品自动下架">
					    <el-switch v-model="form.delivery"  style="left:10px;"></el-switch>
					  </el-form-item>
					</el-form>
				</div>
	<div class="forms">
		<el-table
			:data="tableData"
			stripe
			style="width: 100%">
			<el-table-column
			   prop="name"
			  align="center" 
			  label="商品名称"
			  width="180">
			</el-table-column>
			<el-table-column
			  align="center" 
			  prop="name"
			  label="单位"
			  width="180">
			</el-table-column>
			<el-table-column
			  align="center" 
			  prop="address"
			  label="商城价">
			</el-table-column>
			<el-table-column
			  align="center" 
			  prop="address"
			  label="活动价格">
			  <template slot-scope="scope">
				  <el-input type="text"  value="99" size="small" class="inputxt"></el-input>
			  </template>
			</el-table-column>
			<el-table-column
			  align="center" 
			  prop="address"
			  label="单人限购">
			  <template slot-scope="scope">
					<el-input type="text"  value="99" size="small" class="inputxt"></el-input>
			  </template>
			</el-table-column>
			<el-table-column
			  align="center" 
			  prop="address"
			  label="活动库存">
			  <template slot-scope="scope">
					<el-input type="text"  value="99" size="small" class="inputxt"></el-input>
			  </template>
			</el-table-column>
			<el-table-column
			  prop="address"
			  label="开始时间">
			   <template slot-scope="scope">
				<el-date-picker
				  v-model="value1"
				  type="date"
				  placeholder="选择日期">
				</el-date-picker>
				   </template>
			</el-table-column>
			<el-table-column
			  prop="address"
			  label="结束时间">
			   <template slot-scope="scope">
				<el-date-picker
				  v-model="value1"
				  type="date"
				  placeholder="选择日期">
				</el-date-picker>
				   </template>
			</el-table-column>
			<el-table-column
			  align="center" 
			  prop="address"
			  label="状态">
			  <template slot-scope="scope">
					<el-switch
					  width="190px"
					  v-model="switchs"
					  active-color="#13ce66"
					  active-text="上架"
					  inactive-text="下架"
					  inactive-color="#ff4949">
					</el-switch>
			  </template>
			</el-table-column>
			<el-table-column
			  align="center" 
			  prop="address"
			  label="销量">
			</el-table-column>
			<el-table-column
			  align="center" 
			  prop="address"
			  label="操作">
			 <template slot-scope="scope">
					 <el-button @click="handleClick(scope.$index)" type="text" size="small">删除</el-button>
			 </template>
					</el-table-column>
		  </el-table>
	</div>
</div>
		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
export default {
  name: 'first',
  components: {},
   data() {
        return {
			switchs:false,
			New_products:false,//选择商品弹窗
			 activeName: 'first',
			  form: {
			           name: '',
			           region: '',
			           date1: '',
			           date2: '',
			           delivery: false,
			           type: [],
			           resource: '',
			           desc: ''
			         },
					  pickerOptions: {
					           shortcuts: [{
					             text: '今天',
					             onClick(picker) {
					               picker.$emit('pick', new Date());
					             }
					           }, {
					             text: '昨天',
					             onClick(picker) {
					               const date = new Date();
					               date.setTime(date.getTime() - 3600 * 1000 * 24);
					               picker.$emit('pick', date);
					             }
					           }, {
					             text: '一周前',
					             onClick(picker) {
					               const date = new Date();
					               date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
					               picker.$emit('pick', date);
					             }
					           }]
					         },
					         value1: '',
					         value2: '',
					         value3: '',
			  num: 1,
			   formInline: {
			            user: '',
			            region: ''
			          },
          tableData: [{
		  }],
		      options: [{
		            value: '选项1',
		            label: '黄金糕'
		          }, {
		            value: '选项2',
		            label: '双皮奶'
		          }, {
		            value: '选项3',
		            label: '蚵仔煎'
		          }, {
		            value: '选项4',
		            label: '龙须面'
		          }, {
		            value: '选项5',
		            label: '北京烤鸭'
		          }],
		          value: ''
		        }
      },
	   methods: {
	        handleChange(value) {
	          console.log(value);
	        },
			  onSubmit() {
			        console.log('submit!');
			      }
	      }
};
</script>
<style scoped>
@font-face {
  font-family: 'iconfont';  /* project id 1395133 */
  src: url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.eot');
  src: url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.eot?#iefix') format('embedded-opentype'),
  url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.woff2') format('woff2'),
  url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.woff') format('woff'),
  url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.ttf') format('truetype'),
  url('//at.alicdn.com/t/font_1395133_7x8s0d4yala.svg#iconfont') format('svg');
}
	.iconfont{
	    font-family:"iconfont" !important;
	    font-size:16px;font-style:normal;
	    -webkit-font-smoothing: antialiased;
	    -webkit-text-stroke-width: 0.2px;
	    -moz-osx-font-smoothing: grayscale;
		}	
		.headtitle{
			background:rgba(168,183,227,1);
			border:1px solid rgba(67,107,229,1);
			border-radius:0px 0px 6px 6px; 
			width:1150px;
			height:25px;
		}
		/* 更改默认element输入框样式 */
		#Input_box .el-form-item__label{
			  width: 160px!important;
		}
		  .forms .el-input__inner{
			  width:150px;
		  }
</style>
