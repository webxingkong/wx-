<template>
	<div class="select OutAdministration-page">
		<div class="select-table">
			<el-tabs v-model="activeName">
				<!--出库管理-->
				<el-tab-pane label="出库管理" name="first">
					<div class="search">
						<el-form :inline="true" :model="searchlist" class="demo-form-inline search-Button">
							<el-form-item label="出库单号" style="margin-top: 20px;">
								<el-input size="small" v-model="searchlist.out_number" style="width: 120px;"></el-input>
							</el-form-item>
							<el-form-item label="出库时间" style="margin-top: 20px;">
								<el-date-picker
      					v-model="searchlist.delivery_time"
      					type="datetime"
      					placeholder="选择日期时间"
								size="small"
								style="width: 220px;">
    						</el-date-picker>
							</el-form-item>

							<el-form-item label="出库状态" style="margin-top: 20px;">
								<el-select v-model="value" placeholder="请选择" size="small" style="width: 130px;">
									<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" :disabled="item.disabled"></el-option>
								</el-select>
							</el-form-item>
							&emsp;
							<el-form-item><el-button size="small" type="primary" @click="search" style="margin-top: 23px;">搜索</el-button></el-form-item>
						</el-form>
					</div>
					<br />
					<br />

					<div style="float:right"><el-button size="medium">导出查询结果</el-button></div>
					<br />
					<el-table ref="multipleTable" :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)" tooltip-effect="dark" style="width: 100%">
						<el-table-column align="center" width="55"></el-table-column>
						<el-table-column align="center" prop="delivery_number" label="出库单号">
						</el-table-column>
						<el-table-column align="center" prop="bill_price" label="单据金额"></el-table-column>
						<el-table-column align="center" prop="delivery_time" label="出库时间"></el-table-column>
						<el-table-column align="center" prop="warehouses" label="仓库"></el-table-column>
						<!-- <el-table-column align="center" prop="road" label="采购员"></el-table-column> -->
						<el-table-column align="center" prop="delivery_type" label="类型"></el-table-column>
						<el-table-column align="center" prop="producer" label="制单人"></el-table-column>
						<el-table-column align="center" prop="delivery_state" label="入库状态"></el-table-column>
						<el-table-column align="center" fixed="right" label="操作" show-overflow-tooltip>
							<template slot-scope="scope">
								<el-button @click="Outdetails(scope.row)" type="text" size="small">详情</el-button>
								<el-button type="text" size="small">打印</el-button>
							</template>
						</el-table-column>
					</el-table>
					<br />
					<!--分页-->
					 <el-pagination class="block"
					 background
					 @size-change="handleSizeChange"
					 @current-change="handleCurrentChange"
					 :current-page="currentPage"
					 :page-sizes="[5, 10, 20, 50]"
					 :page-size="pagesize"
					 layout="total, sizes, prev, pager, next, jumper"
					 :total="total">
					   </el-pagination>
				</el-tab-pane>
				<!--出库查询-->
				<el-tab-pane label="出库查询" name="second">

						<div class="search">
							<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
								<el-form-item label="出库单号" style="margin-top: 20px;">
									<el-input size="small" v-model="formInline.out_number" style="width: 120px;"></el-input>
								</el-form-item>
								<el-form-item label="出库时间" style="margin-top: 20px;">
									<!-- <el-input size="small" v-model="formInline.region" style="width: 120px;"></el-input> -->
									<el-date-picker
	      					v-model="formInline.delivery_time"
	      					type="datetime"
	      					placeholder="选择日期时间"
									size="small"
									style="width: 220px;">
	    						</el-date-picker>
								</el-form-item>
								<el-form-item label="出库状态" style="margin-top: 20px;">
									<el-select v-model="infovalue" placeholder="请选择" size="small" style="width: 130px;">
										<el-option v-for="item in infooptions" :key="item.value" :label="item.label" :value="item.value" :disabled="item.disabled"></el-option>
									</el-select>
								</el-form-item>
								&emsp;
								<el-form-item><el-button size="small" type="primary" @click="infosearch" style="margin-top: 23px;">搜索</el-button></el-form-item>
							</el-form>
						</div>
						<br />
						<br />

						<div class="right"><el-button size="medium">导出查询结果</el-button></div>
						<br />
						<el-table ref="multipleTable" :data="info" tooltip-effect="dark" style="width: 100%">
							<!-- <el-table-column align="center" width="55"></el-table-column> -->
							<el-table-column align="center" prop="product_name" label="商品">
							</el-table-column>
							<el-table-column align="center" prop="describe" label="描述"></el-table-column>
							<el-table-column align="center" prop="units" label="单位"></el-table-column>
							<el-table-column align="center" prop="warehouse" label="仓库"></el-table-column>

							<el-table-column align="center" prop="delivery_type" label="出库类型"></el-table-column>
							<el-table-column align="center" prop="out_of_stock_number" label="关联单号"></el-table-column>
							<el-table-column align="center" prop="delivery_time" label="出库时间"></el-table-column>
							<el-table-column align="center" prop="delivery_count" label="出库数量"></el-table-column>
							<el-table-column align="center" prop="unit_price" label="出库单价"></el-table-column>
							<el-table-column align="center" prop="price_total" label="出库金额"></el-table-column>
						</el-table>
						<br />
						<div class="block">
							<span>合计：</span><span  style="color: #436BE5">{{Calculation}}</span>

						</div>

					</el-tab-pane>
			</el-tabs>
		</div>


	</div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			activeName: 'first',
			tableData: [],
			info:[],
			total: 0,
			currentPage: 1,
			pagesize: 5,
			infototal: 0,
			infocurrentPage: 1,
			infopagesize: 5,
			searchlist:{
				out_number: '',
				state: '',
				delivery_time:''
			},
			formInline: {
				out_number: '',
				state: '',
				delivery_time:''
			},
			options: [
				{
					value: '选项1',
					label: '待发货'
				},
				{
					value: '选项2',
					label: '已发货'
				}
			],
			infovalue: '',
			infooptions: [
				{
					value: '选项1',
					label: '待发货'
				},
				{
					value: '选项2',
					label: '已发货'
				}
			],
			value: '',
			gridData: [
				{
					date: '八宝粥',
					name: 'SFF62533',
					Reserve: '斤',
					lack: '饮料',
					Actual: '默认',
					gold: '￥12.00',
					address: '530'
				},
				{
					date: '八宝粥',
					name: 'SFF62533',
					Reserve: '斤',
					lack: '饮料',
					Actual: '默认',
					gold: '￥12.00',
					address: '530'
				},
				{
					date: '八宝粥',
					name: 'SFF62533',
					Reserve: '斤',
					lack: '饮料',
					Actual: '默认',
					gold: '￥12.00',
					address: '530'
				},
				{
					date: '八宝粥',
					name: 'SFF62533',
					Reserve: '斤',
					lack: '饮料',
					Actual: '默认',
					gold: '￥12.00',
					address: '530'
				}
			],
			dialogTableVisible: false,
		};
	},
	//计算属性
	computed:{
			 Calculation:function(){
	 			let gl=this.info;
	 			let t=0;
	 			for (var i = 0; i < gl.length; i++) {
	 				t+=gl[i].delivery_count * gl[i].unit_price;
	 			}
	 			return t;
	 		}
	 },
	created() {
			this.getData();
			// this.integrlist();
	},
	methods: {
		// 获取数据
		async getData() {
				const result = await axios.get(Rootpath.BASE_URL + 'deliveryList');
				console.log(result);
				this.tableData=result.data.info;
				this.total = result.data.info.length;
				const json = await axios.get(Rootpath.BASE_URL + 'queryDelivery');
				console.log(json);
				this.info=json.data.info;
				this.infototal = json.data.info.length;
		},
		//详情
		Outdetails(Outdetails){
		 this.$router.push({path:'/library/Out/Outdetails',query: {id:Outdetails}})
		},
		//出库管理搜索
    async search() {
        let that = this;
        axios.get(Rootpath.BASE_URL + 'deliveryList_search', {
                params: {
                    out_number: that.searchlist.out_number,
                    state: that.value,
                    delivery_time: that.searchlist.delivery_time
									}
            })
            .then(function (response) {
								if (response.data=="") {
									that.$alert('没有找到相关数据', '提示', {
    							confirmButtonText: '确定',
    							callback: action => {
        					that.$message({
        					});
    						}
							});
						}else {
							that.tableData = response.data.info
							that.total = response.data.info.length
						}
            })
            .catch(function (error) {
                console.log(error);
            });
    },
		//出库查询搜索
		async infosearch() {
        let that = this;
        axios.get(Rootpath.BASE_URL + 'queryDelivery_search', {
                params: {
                    out_number: that.formInline.out_number,
                    state: that.infovalue,
                    delivery_time: that.formInline.delivery_time
                }
            })
            .then(function (response) {
                console.log(response);
								if (response.data=="") {
									that.$alert('没有找到相关数据', '提示', {
    							confirmButtonText: '确定',
    							callback: action => {
        					that.$message({
        					});
    						}
							});
						}else {
							that.info = response.data.info
							that.infototal = response.data.info.length
						}
            })
            .catch(function (error) {
                console.log(error);
            });
    },
		//分页
		handleSizeChange(size) {
		  this.pagesize = size
		},
		handleCurrentChange(currentPage) {
		  this.currentPage = currentPage
		},
	},
};
</script>

<style scoped>

	.block{
		text-align: right;
	}
	.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
	.right {
		text-align: right;
	}
</style>
