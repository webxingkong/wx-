<template>
	<div class="select Outdetails-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="出库管理详情" name="first"></el-tab-pane></el-tabs>
			<h4>基本信息</h4>
			<el-row>
				<!--第一-->
				<el-col :span="12">
					<div class="grid-content bg-purple ">
						<ul>
							<li class="flex ">
								<div class="labeltext">
									配送单号：
								</div>
								<div class="labeltext">
									{{basicData.out_of_stock_number}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									单据日期：
								</div>
								<div class="labeltext">
									{{basicData.delivery_submission_time}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									出库类型：
								</div>
								<div class="labeltext">
									{{basicData.delivery_type}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									关联单号：
								</div>
								<div class="labeltext">
									{{basicData.delivery_number}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									出库金额：
								</div>
								<div class="labeltext">
									{{basicData.bill_price}}
								</div>
							</li>
						</ul>
					</div>
				</el-col>
				<!--第二-->
				<el-col :span="12">
					<div class="grid-content bg-purple">
						<ul>
							<li class="flex ">
								<div class="labeltext">
									出库时间：
								</div>
								<div class="labeltext">
									{{basicData.delivery_time}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									单据状态：
								</div>
								<div class="labeltext">
									{{basicData.delivery_state}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									出库仓库：
								</div>
								<div class="labeltext">
									{{basicData.warehouse}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									制单人：
								</div>
								<div class="labeltext">
									{{basicData.producer}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									备注：
								</div>
								<div class="labeltext">
									{{basicData.remark}}
								</div>
							</li>
						</ul>
					</div>
				</el-col>
				<!--交货日期-->
			</el-row>
			<h4>单据详情</h4>
			<el-table ref="multipleTable" :data="goodsList" tooltip-effect="dark" style="width: 100%">
				<el-table-column align="center"  width="55"></el-table-column>
				<el-table-column align="center"  prop="product_name" label="商品名称"></el-table-column>
				<el-table-column align="center"  prop="product_desc" label="描述"></el-table-column>
				<el-table-column align="center"  prop="unit" label="单位"></el-table-column>
				<el-table-column align="center"  prop="delivery_count" label="出库数量"></el-table-column>
				<el-table-column align="center"  prop="unit_price" label="单价"></el-table-column>
				<el-table-column align="center"  prop="total_price" label="金额"></el-table-column>
			</el-table><br>
			<div class="block">
				<span>合计：</span>
				<span style="color: #436BE5">{{Calculation}}</span>
			</div>

			<br />
			<h4>单据操作历史</h4>
			<el-table ref="multipleTable" :data="remark" tooltip-effect="dark" style="width: 100%">
				<el-table-column align="center"  prop="operator" label="操作人"></el-table-column>
				<el-table-column align="center"  prop="operator_time" label="时间"></el-table-column>
				<el-table-column align="center"  prop="operator_type" label="类型"></el-table-column>
				<el-table-column align="center"  prop="operator_Record" label="日志"></el-table-column>
			</el-table>
			<br />
			<br />
			<el-button size="small" type="primary" @click="returnback">返回</el-button>
		</div>
		<br />
	</div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			activeName: 'first',
			basicData:[],
			goodsList:[],
			remark:[]
		};
	},
	//计算属性
	computed:{
			 Calculation:function(){
	 			let gl=this.goodsList;
	 			let t=0;
	 			for (var i = 0; i < gl.length; i++) {
	 				t+=gl[i].delivery_count * gl[i].unit_price;
	 			}
	 			return t;
	 		}
	 },
	created() {
			this.getData();
	},
	methods: {
		onSubmit() {
			console.log('submit!');
		},
		deleteRow(index, rows) {
			rows.splice(index, 1);
		},
		async getData() {
		    // var storage_number = this.$route.query.sno
		    const result = await axios.get(Rootpath.BASE_URL + 'deliveryInfo');
				console.log(result);
				this.basicData=result.data.info.basicData;
				this.goodsList=result.data.info.goodsList;
				this.remark=result.data.info.remark;
				console.log(this.basicData);
				console.log(this.goodsList);
				console.log(this.remark);
		},
		returnback(){
			this.$router.push({path:'/library/Out'})
		}
	}
};
</script>

<style scoped>
.grid-content {
	height: 160px;
	font-size: 8px;
}
.labeltext{
	font-size: 14px;
	line-height: 30px
}
.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
	.block{
		text-align: right;
	}
</style>
