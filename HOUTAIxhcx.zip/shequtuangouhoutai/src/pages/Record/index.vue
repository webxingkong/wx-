<template>
  <div class="Service-page" style="margin: 20px;">
	  <el-tabs v-model="activeName" @tab-click="handleClick">
	     <el-tab-pane label="提货订单" name="first">
					<div><!-- 输入框 -->
					<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
					  <el-form-item label="会员名称" style="margin-top: 20px;">
						<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
					  </el-form-item>
					  <el-form-item label="手机号" style="margin-top: 20px;">
						<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
					  </el-form-item>
					  <el-form-item label="会员状态" style="margin-top: 20px;">
						<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
					  </el-form-item>&emsp;
					  <el-form-item label="注册时间" style="margin-top: 20px;">
						<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
					  </el-form-item>&emsp;
					  <el-form-item>
						<el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>
					  </el-form-item>
					</el-form>
					</div>
					<div class="right">
					<el-button size="medium">导出查询结果</el-button>
					</div>
					<div>
						<el-table
						    :data="tableData"
						    stripe
						    style="width: 100%">
						    <el-table-column
						      prop="date"
						      label="订单号"
						      width="180">
						    </el-table-column>
						    <el-table-column
						      prop="name"
						      label="配送方式"
						      width="180">
						    </el-table-column>
						    <el-table-column
						      prop="address"
						      label="商品">
						    </el-table-column>
							<el-table-column
							  prop="address"
							  label="付款时间">
							</el-table-column>
							<el-table-column
							  prop="address"
							  label="团长">
							</el-table-column>
						  </el-table>
					</div>
					<div class="paging">
				  <div style="padding-left:80%;align-items: center;padding-top:9px;" class="flex">
					<div style="line-height:25px;">1/6页，54条结果</div>
					 <el-pagination>
					 </el-pagination>
				</div>
			</div>

		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
export default {
  name: 'first',
  components: {},
   data() {
        return {
			 activeName: 'first',
			//  data后端获取的数据
			 data:[],
			  formInline: {
			           user: '',
			           region: ''
			         },
			  num: 1,
          tableData: [{
            date: 'DD6435315646141221',
            name: '自提',
            address: '火龙果'
          }, {
            date: 'DD6435315646141221',
            name: '自提',
            address: '火龙果 1517 弄'
          }, {
            date: 'DD6435315646141221',
            name: '自提',
            address: '火龙果 1519 弄'
          }, {
            date: 'DD6435315646141221',
            name: '自提',
            address: '火龙果 1516 弄'
          }, {
            date: 'DD6435315646141221',
            name: '自提',
            address: '火龙果 1516 弄'
          }, {
            date: 'DD6435315646141221',
            name: '自提',
            address: '火龙果 1516 弄'
          }, {
            date: 'DD6435315646141221',
            name: '自提',
            address: '火龙果 1516 弄'
          }, {
            date: 'DD6435315646141221',
            name: '自提',
            address: '火龙果 1516 弄'
          },
		  {
		    date: 'DD6435315646141221',
		    name: '自提',
		    address: '火龙果 1516 弄'
		  },
		  {
		    date: 'DD6435315646141221',
		    name: '自提',
		    address: '火龙果 1516 弄'
		  },
		  {
		    date: 'DD6435315646141221',
		    name: '自提',
		    address: '火龙果 1516 弄'
		  },
		  {
		    date: 'DD6435315646141221',
		    name: '自提',
		    address: '火龙果 1516 弄'
		  }]
        }
      },
	   methods: {
	        handleChange(value) {
	          console.log(value);
	        },
			 onSubmit() {
			        console.log('submit!');
			      }
		  },
		  created() {
		const listUrl = 'http://yhxapi.me/mock/24/admin/goods_record';
		axios.get(listUrl).then(response => {
			var s=this.data=response.data;
			console.log(s);
		});
	},
};
</script>
<style scoped>
	.text{
	    display: flex;
		align-items: center;
	    left: 20px;
	    position: relative;
	    top: 15px;
	  }
	.search {
	  height: 75px;
	  background-color: #F5F5F5;
	  position: relative;
	  top: 16px;
	}
	.search-frame {
	  width: 100%;
	  height: 100px;
	  margin: auto;
	  background-color: #ffffff;
	}
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px; 
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
