<template>
	<div class="select Stock-page">
		<div class="select-table">
			<el-tabs v-model="activeName">
				<el-tab-pane label="现有库存" name="first">
					<div class="search">
						<el-form :inline="true" :model="searchlist" class="demo-form-inline search-Button">
							<el-form-item label="仓库" style="margin-top: 20px;">
								<el-select v-model="price" placeholder="请选择" size="small" style="width: 130px;">
									<el-option v-for="item in option" :key="item.price" :label="item.labe" :value="item.price" :disabled="item.disabled"></el-option>
								</el-select>
							</el-form-item>
							<el-form-item label="商品名称" style="margin-top: 20px;">
								<el-input size="small" v-model="searchlist.product_name" style="width: 120px;"></el-input>
							</el-form-item>
							<el-form-item label="商品编码" style="margin-top: 20px;">
								<el-input size="small" v-model="searchlist.product_number" style="width: 120px;"></el-input>
							</el-form-item>
							<el-form-item label="商品种类" style="margin-top: 20px;">
								<el-select v-model="value" placeholder="请选择" size="small" style="width: 130px;">
									<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" :disabled="item.disabled"></el-option>
								</el-select>
							</el-form-item>
							&emsp;
							<el-form-item><el-button size="small" type="primary" @click="search" style="margin-top: 23px;">搜索</el-button></el-form-item>
						</el-form>
					</div>
					<br />
					<br />
					<br />
					<div class="block"><el-button size="medium">导出查询结果</el-button></div>
					<br />
					<el-table ref="multipleTable" :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)" tooltip-effect="dark" style="width: 100%">
						<el-table-column align="center"  width="55"></el-table-column>
						<el-table-column align="center"  prop="product_name" label="商品名称"></el-table-column>
						<el-table-column align="center"  prop="product_number" label="编码"></el-table-column>
						<el-table-column align="center"  prop="warehouse" label="仓库"></el-table-column>
						<el-table-column align="center"  prop="top_classify" label="一级分类"></el-table-column>
						<el-table-column align="center"  prop="second_classify" label="二级分类"></el-table-column>
						<!-- <el-table-column align="center"  prop="Way" label="在途库存"></el-table-column> -->
						<el-table-column align="center"  prop="unit_price" label="库存均价"></el-table-column>
						<!-- <el-table-column align="center"  prop="unit_price" label="现有库存"></el-table-column> -->
						<el-table-column align="center"  prop="total_price" label="库存总金额"></el-table-column>
						<el-table-column align="center"  prop="stock_up_limit" label="库存上限"></el-table-column>
						<el-table-column align="center"  prop="stock_low_limit" label="库存下限" show-overflow-tooltip></el-table-column>
						<el-table-column align="center"  fixed="right" label="操作">
							<template slot-scope="scope">
								<el-button type="text" size="small" @click="bound(scope.row)">设置上下限</el-button>
								<!-- <el-button type="text" size="small" @click="dialogTableVisible = true">成本变更记录</el-button> -->
							</template>
						</el-table-column>
					</el-table>
					<br />
					<!--分页-->
					 <el-pagination class="block"
					     background
					     @size-change="handleSizeChange"
					     @current-change="handleCurrentChange"
					     :current-page="currentPage"
					     :page-sizes="[5, 10, 20, 50]"
					     :page-size="pagesize"
					     layout="total, sizes, prev, pager, next, jumper"
					     :total="total">
					   </el-pagination>
				</el-tab-pane>
			</el-tabs>
		</div>
		<!--上下限-->
		<el-dialog title="库存上下限设置" :visible.sync="dialogFormVisible" width="500px">
			<span>商品：{{form.pno}}</span>
			<el-form :model="form">
				<br />
				<br />
				<el-form-item label="上限:"><el-input v-model="form.stock_up_limit" style="width:350px" autocomplete="off"></el-input></el-form-item>
				<el-form-item label="下限:"><el-input v-model="form.stock_low_limit" style="width:350px" autocomplete="off"></el-input></el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="dialogFormVisible = false">取消</el-button>
				<el-button type="primary" @click="boundsave">保存</el-button>
			</div>
		</el-dialog>
	</div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			activeName: 'first',
			tableData: [],
			total: 0,
			currentPage: 1,
			pagesize: 5,
			searchlist: {
				product_number:'',
				product_name:'',
				warehouse:'',
				sort_id:''
			},

			options: [
				{
					value: '选项1',
					label: '应季水果'
				},
				{
					value: '选项2',
					label: '反季水果'
				}
			],
			value: '',
			option: [
				{
					price: '选项1',
					labe: '南宁农贸市场'
				},
				{
					price: '选项2',
					labe: '新和平批发市场'
				}
			],
			price: '',
			dialogFormVisible: false,
			form: {
				pno: "11",    //商品编号
    		stock_up_limit: 10,   //库存上限
    		stock_low_limit: 11   //库存下线
			},
			formLabelWidth: '100px'
		};
	},
	created() {
			this.getData();
	},
	methods: {
		onSubmit() {
			console.log('submit!');
		},
		//分页
		handleSizeChange(size) {
		  this.pagesize = size
		},
		handleCurrentChange(currentPage) {
		  this.currentPage = currentPage
		},
		// 获取数据
		async getData() {
				const result = await axios.get(Rootpath.BASE_URL + 'existingStockList');
				// console.log(result);
				this.tableData=result.data.info;
				this.total = result.data.info.length;
		},
		//上下限设置
		bound(row){
			this.dialogFormVisible=true,
			this.form.pno=row.product_number;
			this.form.stock_up_limit=row.stock_up_limit;   //库存上限
			this.form.stock_low_limit=row.stock_low_limit;  //下限
		},
		boundsave(){
			let that=this;
			axios.post(Rootpath.BASE_URL + 'setStockLimit', {
            pno: that.form.pno,
            stock_up_limit: that.form.stock_up_limit,
            stock_low_limit: that.form.stock_low_limit,
        })
        .then(function (response) {
            that.dialogFormVisible = false;
            console.log(response);
        })
        .catch(function (error) {
            console.log(error);
        });
		},
		//搜索
    async search() {
        let that = this;
        axios.get(Rootpath.BASE_URL + 'existingStockList_search', {
                params: {
                    product_number: that.searchlist.product_number,//商品编号
                    product_name: that.searchlist.product_name,//商品名称
                    warehouse: that.price,//仓库
                    sort_id: that.value,//商品分类id
                }
            })
            .then(function (response) {
                console.log(response);
                that.tableData = response.data.info
                that.total = response.data.info.length
            })
            .catch(function (error) {
                console.log(error);
            });
    },
	}
};
</script>

<style scoped>
.block {
	text-align: right;
}

.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
</style>
