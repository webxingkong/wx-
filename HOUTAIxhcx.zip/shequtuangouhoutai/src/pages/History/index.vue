<template>
	<div class="select">
	<div class="select-table">
		<el-tabs v-model="activeName" @tab-click="handleClick">
			<!--直供-->
		    <el-tab-pane label="供应商直供" name="first">
		<div class="search">
			<!---->
			<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
			  <el-form-item label="商品" style="margin-top: 20px;">
			    <el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
			  </el-form-item>
			  <el-form-item label="分类" style="margin-top: 20px;">
			    <el-input  size="small" v-model="formInline.region" style="width: 120px;"></el-input>
			  </el-form-item>
			  <el-form-item label="单位" style="margin-top: 20px;">
			    <el-input  size="small" v-model="formInline.Name" style="width: 120px;"></el-input>
			  </el-form-item>&emsp;
			  <el-form-item>
			    <el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>
			  </el-form-item>
			</el-form>
			<!---->
				</div>
		<br><br>
				<div class="Button">
				<div class="right">
				 <el-button size="medium">导出查询结果</el-button>
				</div>
				</div><br>
				<br><br>
				<div class="flex_lr ">
				<div class="Leftbox">
					  <template>
					    <el-table :data="tableData">
					      <el-table-column prop="goods" label="商品" width="100"></el-table-column>
					      <el-table-column prop="unit" label="单位" width="100"></el-table-column>
					      <el-table-column prop="collectquantity" label="收货数量" width="100"></el-table-column>
					      <el-table-column prop="collectunitprice" label="收货单价" width="100"></el-table-column>
					      <el-table-column prop="Receivingamount" label="收货金额" width="100"></el-table-column>
					      <el-table-column prop="Quantityreturned" label="退货数量" width="100"></el-table-column>
					      <el-table-column prop="Refundamount" label="退货金额" width="100"></el-table-column>
					      <el-table-column prop="Actualamount" label="实际金额" show-overflow-tooltip></el-table-column>
					    </el-table>
					  </template>  
				</div>
				<div class="Leftbox">
					  <template>
					    <el-table :data="tableData">
					      <el-table-column prop="goods" label="商品" width="100"></el-table-column>
					      <el-table-column prop="unit" label="单位" width="100"></el-table-column>
						  <el-table-column prop="time" label="采购时间" width="180"></el-table-column>
					      <el-table-column prop="collectquantity" label="收货数量" width="100"></el-table-column>
					      <el-table-column prop="collectunitprice" label="收货单价" width="100"></el-table-column>
					      <el-table-column prop="Quantityreturned" label="退货数量" width="100"></el-table-column>
					      <el-table-column prop="Refundamount" label="退货金额" width="100"></el-table-column>
					      <el-table-column prop="Actualamount" label="实际金额" show-overflow-tooltip></el-table-column>
					    </el-table>
					  </template>
				</div>
				</div>
			</el-tab-pane>
			<!--市场采购-->
		    <el-tab-pane label="市场采购" name="second">
				<div class="search">
					<!---->
					<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
					  <el-form-item label="商品" style="margin-top: 20px;">
					    <el-input  size="small" v-model="formInline.times" style="width: 120px;"></el-input>
					  </el-form-item>
					  <el-form-item label="分类" style="margin-top: 20px;">
					    <el-input  size="small" v-model="formInline.Mobilephone" style="width: 120px;"></el-input>
					  </el-form-item>
					  <el-form-item label="单位" style="margin-top: 20px;">
					    <el-input  size="small" v-model="formInline.Names" style="width: 120px;"></el-input>
					  </el-form-item>&emsp;
					  <el-form-item>
					    <el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>
					  </el-form-item>
					</el-form>
					<!---->
						</div>
						
				<div class="Button">
				<div class="right">
					<br><br>
				 <el-button size="medium">导出查询结果</el-button>
				 </div>
				 </div><br><br><br>
				 <br><br>
				 <div class="flex_lr ">
				 <div class="Leftbox">
				 	  <template>
				 	    <el-table :data="tableData">
				 	      <el-table-column prop="goods" label="商品" width="100"></el-table-column>
				 	      <el-table-column prop="unit" label="单位" width="100"></el-table-column>
				 	      <el-table-column prop="collectquantity" label="收货数量" width="100"></el-table-column>
				 	      <el-table-column prop="collectunitprice" label="收货单价" width="100"></el-table-column>
				 	      <el-table-column prop="Receivingamount" label="收货金额" width="100"></el-table-column>
				 	      <el-table-column prop="Quantityreturned" label="退货数量" width="100"></el-table-column>
				 	      <el-table-column prop="Refundamount" label="退货金额" width="100"></el-table-column>
				 	      <el-table-column prop="Actualamount" label="实际金额" show-overflow-tooltip></el-table-column>
				 	    </el-table>
				 	  </template>  
				 </div>
				 <div class="Leftbox">
				 	  <template>
				 	    <el-table :data="tableData">
				 	      <el-table-column prop="goods" label="商品" width="100"></el-table-column>
				 	      <el-table-column prop="unit" label="单位" width="100"></el-table-column>
				 		  <el-table-column prop="time" label="采购时间" width="180"></el-table-column>
				 	      <el-table-column prop="collectquantity" label="收货数量" width="100"></el-table-column>
				 	      <el-table-column prop="collectunitprice" label="收货单价" width="100"></el-table-column>
				 	      <el-table-column prop="Quantityreturned" label="退货数量" width="100"></el-table-column>
				 	      <el-table-column prop="Refundamount" label="退货金额" width="100"></el-table-column>
				 	      <el-table-column prop="Actualamount" label="实际金额" show-overflow-tooltip></el-table-column>
				 	    </el-table>
				 	  </template>
				 </div>
				 </div>
				</el-tab-pane>
			</el-tab-pane>
		  </el-tabs>
	</div>
	</div>
</template>

<script>
	
export default {
	data() {
			return {
				 activeName: 'first',
				tableData: [
					{
						
						goods: 'xxx',
						unit: '个',
						collectquantity: '0',
						collectunitprice: '8',
						Receivingamount:'￥5',
						Quantityreturned:'3',
						Refundamount:'￥138.0',
						Actualamount:'￥18.0',
						time:'2019-10-20 12:12:12',
						
					},
					{
						
						goods: '名字',
						unit: '件',
						collectquantity: '20',
						collectunitprice: '98',
						Receivingamount:'￥58',
						Quantityreturned:'2',
						Refundamount:'￥138.0',
						Actualamount:'￥18.0',
						time:'2019-10-20 12:12:12',
						
					},
				],
			formInline: {
			      user: '',
			      region: '',
				  Name:'',
				  times:'',
				  Mobilephone:'',
				  Names:''
			    },
			  
			methods: {
			  onSubmit() {
			    console.log('submit!');
			  }
			}
			};
		},
	};

</script>

<style scoped>
	.Leftbox{
		width: 48%;
		height: 100%;
		border: solid 1px #D8D8D8;
	}
	.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	} /*border: solid 1rpx #007AFF;
	*/
	.right {
		text-align: right;
	}
</style>
