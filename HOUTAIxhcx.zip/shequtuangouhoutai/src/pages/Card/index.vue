<template>
	<div class="select">
	<div class="select-table">
		<el-tabs v-model="activeName" @tab-click="handleClick">
		  <el-tab-pane label="充值卡" name="first"></el-tab-pane>
		</el-tabs>
		<div class="search">
			<!---->
			<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
			  <el-form-item label="充值卡名称" style="margin-top: 20px;">
			    <el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
			  </el-form-item>
			  <el-form-item label="批次" style="margin-top: 20px;">
			    <el-input  size="small" v-model="formInline.region" style="width: 120px;"></el-input>
			  </el-form-item>
			  <el-form-item>
			    <el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>
			  </el-form-item>
			</el-form>
			<!---->
				</div>
		<br><br>
		<el-button size="small" type="primary">制卡</el-button>
		 <br><br>
		<el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
			

			<el-table-column prop="name" label="批次号" width="200"></el-table-column>
			<el-table-column prop="date" label="充值卡名称" width="150"></el-table-column>
			<el-table-column prop="integral" label="批次金额" width="130"></el-table-column>
			<el-table-column prop="state" label="已使用金额" width="140"></el-table-column>
			<el-table-column prop="Number" label="批次数量" width="140"></el-table-column>
			<el-table-column prop="Alreadyused" label="已使用数量" width="140"></el-table-column>
			<el-table-column prop="time" label="创建时间" width="240"></el-table-column>
			<el-table-column
			      fixed="right"
			      label="操作"
			      show-overflow-tooltip>
			      <template slot-scope="scope">
			        <el-button @click="handleClick(scope.row)" type="text" size="small">编辑</el-button>
			        <el-button type="text" size="small">删除</el-button>
					
			      </template>
			    </el-table-column>
		</el-table>
		
		
		<br>
		
	</div>
	</div>
</template>

<script>
	
export default {
	data() {
		return {
			activeName: 'first',
			tableData: [
				{
					date: '小虎',
					name: '13557322395',
					rank: '默认等级',
					integral: '0',
					time: '2019-10-20 12:12:15',
					state: '0',
					Alreadyused:'0',
					Number:'0'
				},
			{
				date: '小虎',
				name: '13557322395',
				rank: '默认等级',
				integral: '0',
				time: '2019-10-20 12:12:15',
				state: '0',
				Alreadyused:'0',
				Number:'0'
			},
				{
					date: '小虎',
					name: '13557322395',
					rank: '默认等级',
					integral: '0',
					time: '2019-10-20 12:12:15',
					state: '0',
					Alreadyused:'0',
					Number:'0'
				},
			],
			

			
			
			formInline: {
			      user: '',
			      region: ''
			    },
			methods: {
			  onSubmit() {
			    console.log('submit!');
			  }
			},
			toggleSelection(rows) {
				if (rows) {
					rows.forEach(row => {
						this.$refs.multipleTable.toggleRowSelection(row);
					});
				} else {
					this.$refs.multipleTable.clearSelection();
				}
			},
			handleSelectionChange(val) {
				this.multipleSelection = val;
			}
			
		};
	},

	
	

};
  

  
</script>

<style scoped>
	.footer{height: 44px;
	text-align: right;
	
	}
	
	.Button{
		background-color: #ffffff;
	}
	p{position: relative;
		top: -12px;
			}
	.text{
	
		display: flex;
		left: 20px;
		position: relative;
		top: 15px;
	}
.search {
	height: 75px;
	background-color: #F5F5F5;
	position: relative;
	top: 16px;
}
.search-frame {
	width: 100%;
	height: 100px;
	margin: auto;
	background-color: #ffffff;
}
h3 {
	color: #436be5;
	margin-left: 20px;
	
}
.text-frame-member {
	width: 80px;
	position: relative;
	top: 10px;
}
.text-frame {
	height: 50px;
	width: 100%;
	background-color: #ffffff;
	border-bottom: solid 1px #f0f2f0;
}

.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select{
	margin: auto;
	width: 96%;
	background-color: #ffffff;
}/*border: solid 1rpx #007AFF;
*/

</style>
