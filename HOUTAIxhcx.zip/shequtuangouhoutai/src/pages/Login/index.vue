<template>
  <div class="home-page flex_c_m" :style="{height:windowheight}">
    <div class="centerlogin flex" style="width:900px;height:800px;">
      <div class="leftbox" style="">
        <div class="logo" style="">
          <img src="../../assets/logo.png" alt="" class="logoimg" style="">
          <span style="color:#ffffff;font-size:36px;margin-left:20px">亿万优选</span>
        </div>
        <h1 class="welcome">HELLO,</h1>
        <h1 class="welcome">WELCOME</h1>
        <h1 class="welcome">BACK!</h1>
      </div>
      <div class="rightbox" style="">
        <h1 class="mt50" style="font-size:36px;margin-left:10%">用户登录</h1>
        <el-input v-model="userinput" placeholder="请输入用户名" style="" class="inputtext mt50" prefix-icon="el-icon-user-solid"></el-input>
        <el-input v-model="pwdinput" placeholder="请输入密码" class="inputtext mt50" prefix-icon="el-icon-lock" show-password></el-input>
        <div class="flex_lr_m mt50">
          <el-checkbox v-model="checked" style="margin-left:10%" @change="Change">记住密码</el-checkbox>
          <p style="margin-right:10%" @click="forget">忘记密码？</p>
        </div>
        <el-button class="mt50" type="primary" round style="width:80%;margin-left:10%" @click="login">登录</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
      return {
        checked:false,
        userinput:'',
        pwdinput:''
      }
  },
  //计算属性
	computed:{
			 windowheight:function(){
	 			return window.innerHeight+'px'

	 		}
	 },
   created() {

   },
   methods:{
     Change(val){
       if (val==true) {
         // this.pwdinput=this.pwdinput;
       }else {
         this.pwdinput='';
       }
     },
     //登录
    login() {
       let that = this;
       axios.post(Rootpath.BASE_URL + 'login_in', {
         user_name: that.userinput,
         password: that.pwdinput,
        })
        .then(function (response) {
          that.$router.push('/surface/index');
          console.log(response);
          that.$alert(response.data.msg, '提示', {
            confirmButtonText: '确定',
            callback: action => {

            }

          });

          // this.$router.push({ path: '/surface/index'});
          // that.$router.push({ path: '/profile/success' });
        })
        .catch(function (error) {
            // that.$alert("密码必须是3-18位任意数字字母下划线", '提示', {
            //   confirmButtonText: '确定',
            //   callback: action => {
            //
            //   }
            // });
       });
   },
   //忘记密码
   forget(){
     console.log('忘记了');
   }
   }
};
</script>

<style lang="scss" scoped>
  .inputtext{
    width:80%;margin-left:10%;
  }
  .welcome{
    color: #ffffff;
    font-size: 50px;
    padding-left: 10%
  }
  .mt50{
    margin-top: 50px;
  }
  .leftbox{
    width:50%;height:100%;background:#436BE5;opacity:0.8
  }
  .rightbox{
    width:50%;height:100%;background:#ffffff
  }
  .logo{
    margin-top:50px;margin-bottom:50px
  }
  .logoimg{
    margin-left:10%;width:30px;height:30px;border-radius:50%;border:1px solid red
  }
  .searchClass{
  border: 1px solid #c5c5c5;
  border-radius: 20px;
  background: #f4f4f4;
}
.searchClass .el-input-group__prepend {
  border: none;
  background-color: transparent;
  padding: 0 10px 0 30px;
}
.searchClass .el-input-group__append {
  border: none;
  background-color: transparent;
}
.searchClass .el-input__inner {
  height: 36px;
  line-height: 36px;
  border: none;
  background-color: transparent;
}
.searchClass .el-icon-search{
  font-size: 16px;
}
.searchClass .centerClass {
  height: 100%;
  line-height: 100%;
  display: inline-block;
  vertical-align: middle;
  text-align: right;
}
.searchClass .line {
  width: 1px;
  height: 26px;
  background-color: #c5c5c5;
  margin-left: 14px;
}
.searchClass:hover{
  border: 1px solid #D5E3E8;
  background: #fff;
}
.searchClass:hover .line {
  background-color: #D5E3E8;
}
.searchClass:hover .el-icon-search{
  color: #409eff;
  font-size: 16px;
}
  .home-page{
    background: #1ed086;
    height: 100%;
    width: 100%;
    background:url('../../assets/loginBG.png') no-repeat center center;
    background-size: 100% 100%;
    opacity:0.8;
  }
</style>
