<template>
  <div class="Img-page">
 <el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
   <el-form-item label="商品名称" style="margin-top: 20px;">
   					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
   </el-form-item>
   <el-form-item label="商品货号" style="margin-top: 20px;">
   					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
   </el-form-item>
   <el-form-item>
 	<el-button  size="small" type="primary" @click="search" style="margin-top: 23px;">搜索</el-button>
   </el-form-item>
 </el-form>
    <!-- <div class="btn flex_m">
      <el-button size="small ml16">发布商品</el-button>
    </div> -->
    <el-table
            :data="product_img_list.slice((currentPage-1)*pagesize,currentPage*pagesize)"
            border
            stripe
            class="goods_table"
            min-height="100%">
            <el-table-column
              prop="product_number"
              label="商品编码"
              align="center">
            </el-table-column>

            <el-table-column
              prop="product_name"
              label="商品名称"
              align="center">
            </el-table-column>
            <el-table-column
              prop="product_img"
              label="商品图片"
              align="center">
                 <template   slot-scope="scope">
                   <img v-for="(item,index) in scope.row.img_url_one" :src="item"  min-width="40" height="40" />
                 </template>
            </el-table-column>
            <el-table-column
              prop="product_img"
              label="活动图片"
              align="center">
                 <template   slot-scope="scope">
                    <img v-for="(item,index) in scope.row.img_url_sen" :src="item"  min-width="40" height="40" />
                 </template>
            </el-table-column>
            <el-table-column
              prop="product_img"
              label="详情图片"
              align="center">
                 <template   slot-scope="scope">
                    <img v-for="(item,index) in scope.row.img_url_tow" :src="item"  min-width="40" height="40" />
                 </template>
            </el-table-column>

            <el-table-column label="操作"  align="center">
              <template slot-scope="scope">
                <!-- <el-button type="text"
                           @click="listEdit(scope.$index, scope.row)">编辑</el-button> -->
                           <el-button type="text" @click="addmainimg = true">添加商品主图</el-button>
                <el-button type="text"
                             @click="addmainimg = true">添加详情图片</el-button>
                            <el-button type="text"
                                         @click="addmainimg = true">添加图片</el-button>
              </template>
            </el-table-column>
          </el-table>
          <!--分页-->
          <el-pagination class="pagination"
              background
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-sizes="[5, 10, 20, 50]"
              :page-size="pagesize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="total">
            </el-pagination>
            <!-- 新增分类弹出框 -->
            <el-dialog class="layoutbox" :visible.sync="addmainimg">
              <div class="" style="margin-bottom: 25px;">
                <span style="font-size:18px;font-weight:bold;margin-right:10px;">详情图片</span>
                <span style="color:#999999">商品主图最多上传15张图片，大小不超过2M</span>
              </div>
                <el-upload
                action="http://yhxapi.me/mock/24/admin/UpOssImage"
                list-type="picture-card"
                name="img_file"
                :auto-upload="false"
                :on-remove="handleRemove"
                :on-change="handleChange">
                <i class="el-icon-plus"></i>
                </el-upload>
                <div class="" style="margin-top: 25px;">
                  <span style="color:#999999">导入图片（按住'Ctrl'键批量选择图片，单张图片不超过2M</span>
                </div>
                <span slot="footer" class="dialog-footer">
                  <el-button @click="addmainimg = false">取 消</el-button>
                  <el-button type="primary">确 定</el-button>
                </span>
          </el-dialog>
            <!-- 新增分类弹出框   结束-->

            <!-- 图片弹出 -->
            <el-dialog title="新增商品下级分类" class="layoutbox" :visible.sync="lookimg">
              <!-- <el-dialog :visible.sync="lookimg" size="tiny"> -->
              <img width="100%" :src="dialogImageUrl" alt="">
              <!-- </el-dialog> -->
              <span slot="footer" class="dialog-footer">
                <el-button @click="addmainimg = false">取 消</el-button>
                <el-button type="primary" @click="addmainimg = false">确 定</el-button>
              </span>
          </el-dialog>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      searchFrom:{
        imageBase64:'',
      },
      imglist:{
            name: "",
            type: "",//图片类型
            tmp_name: "",//路径
            error: 0,
            size: null
      },
      imgUrl:'',
      fromInlineimg:[],
      product_img_list: [],
	    formInline: {
	             user: '',
	             region: ''
	           },
      total: 0,
      currentPage: 1,
      // table_index: 999,
      goodslist_img:'path/getgoosList_Image',
      pagesize: 5,
      img_file: {
        name: ".jpg",
        type: "image/jpeg",
        tmp_name: "C:\\Windows\\php27DE.tmp",
        error: 0,
        size: 0
      },
      user: '',
      goodsnum: '',
      addmainimg:false,
      dialogImageUrl: '',
      goodsdata:https.goodsdata,
      lookimg:false,
      dialogVisible: false,
      ruleForm: {
               name: '',
               region: '',
               date1: '',
               date2: '',
               delivery: false,
               type: [],
               resource: '',
               desc: ''
             },
             rules: {
               name: [
                 { required: true, message: '请输入活动名称', trigger: 'blur' },
                 { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
               ],
               region: [
                 { required: true, message: '请选择活动区域', trigger: 'change' }
               ],
               date1: [
                 { type: 'date', required: true, message: '请选择日期', trigger: 'change' }
               ],
               date2: [
                 { type: 'date', required: true, message: '请选择时间', trigger: 'change' }
               ],
               type: [
                 { type: 'array', required: true, message: '请至少选择一个活动性质', trigger: 'change' }
               ],
               resource: [
                 { required: true, message: '请选择活动资源', trigger: 'change' }
               ],
               desc: [
                 { required: true, message: '请填写活动形式', trigger: 'blur' }
               ]
      }
    }
  },
  created(){
     this.getHomeData();
   },
  methods:{
    search(){
      console.log(this.goodsdata);
    },
  handleChange (file, fileList, item) {
    console.log(file);
    const self = this;
    this.fromInlineimg.push({url:file.url});
    const reader = new FileReader();
    reader.onload = function(){
      self.searchFrom.imageBase64 = this.result;
      // console.log(self.searchFrom.imageBase64);
      self.img_file.name=file.name;
      self.img_file.type=file.raw.type;
      self.img_file.tmp_name=self.searchFrom.imageBase64;
      self.img_file.size=file.size;

      axios.post(Rootpath.BASE_URL + 'baseUploadImage', {

              base64:self.img_file.tmp_name
          })
          .then(function (response) {
              // that.dialogFormVisible = false;
              console.log(response);
              console.log(response.data.file);
          })
          .catch(function (error) {
              console.log(error);
          });
    };

    reader.readAsDataURL(file.raw);
},
    handleSizeChange(size) {
      this.pagesize = size
    },
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage
    },
    handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      // 获取数据
      async getHomeData() {
        const result = await axios.get(Rootpath.BASE_URL + 'goods_img');
        // console.log(result);
        this.product_img_list = result.data.product_img_list;
        this.total = result.data.product_img_list.length;
    },
  },
};
</script>
<style scoped>
.layoutbox{
  width: 70%;
  height: 80%;
  margin: 0 auto
}
.Img-page .noactive{
  display: none;
}
.Img-page .el-dialog__close{
  display: none;
}
.Img-page .el-dialog__header{
  border-bottom: 1px solid #D8D8D8;
}
.Img-page .el-dialog__body{
  border-bottom : 1px solid #D8D8D8;
}
.Img-page .el-dialog{
  border-radius:6px;
}
.el-dialog{
  width: 500px;
}
</style>
