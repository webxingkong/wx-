<template>
	<div class="select Grade-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="会员等级" name="first"></el-tab-pane></el-tabs>
			<br />
			<el-button @click="addlayout = true" size="small" type="primary" >新增</el-button>
			<br />
			<el-table :data="leavel_list" @row-click="select" style="width: 100%">
				<el-table-column prop="user_level_name" label="会员等级"></el-table-column>
				<el-table-column prop="upgrade_conditions" label="升级积分"></el-table-column>
				<el-table-column prop="user_discount" label="可享受折扣率"></el-table-column>
				<el-table-column prop="score_percentage" label="备注"></el-table-column>
				<el-table-column fixed="right" label="操作">
					<template slot-scope="scope">
						<el-button @click="editlayout=true" type="text" size="small">编辑</el-button>
						<el-button type="text" @click="deleteinfo(scope.row)">删除</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!--分页-->
			<el-pagination class="pagination"
					background
					@size-change="handleSizeChange"
					@current-change="handleCurrentChange"
					:current-page="currentPage"
					:page-sizes="[5, 10, 20, 50]"
					:page-size="pagesize"
					layout="total, sizes, prev, pager, next, jumper"
					:total="total">
				</el-pagination>
		</div>
		<el-dialog title="新增等级" :visible.sync="addlayout" width="36%">
			<el-form :model="form">
				<el-form-item label="等级名称:" :label-width="formLabelWidth"><el-input v-model="form.user_level_name" autocomplete="off"></el-input></el-form-item>
			<el-form-item label="升级积分条件:" :label-width="formLabelWidth">达到&emsp;<el-input v-model="form.upgrade_conditions" autocomplete="off" style="width: 180px;"></el-input>&emsp;分 可升级</el-form-item>
			<el-form-item label="会员折扣:" :label-width="formLabelWidth"><el-input v-model="form.user_discount" autocomplete="off"></el-input></el-form-item>
			<el-form-item label="积分比率:" :label-width="formLabelWidth"><el-input v-model="form.score_percentage" autocomplete="off"></el-input></el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="addlayout = false">取 消</el-button>
				<el-button type="primary" @click="addsure()">确 定</el-button>
			</div>
		</el-dialog>


		<!-- 编辑弹窗 -->
		<el-dialog title="编辑等级" :visible.sync="editlayout" width="36%">
			<el-form :model="form">
				<el-form-item label="等级名称:" :label-width="formLabelWidth"><el-input v-model="clickform.user_level_name" autocomplete="off"></el-input></el-form-item>
			<el-form-item label="升级积分条件:" :label-width="formLabelWidth">达到&emsp;<el-input v-model="clickform.upgrade_conditions" autocomplete="off" style="width: 180px;"></el-input>&emsp;分 可升级</el-form-item>
			<el-form-item label="会员折扣:" :label-width="formLabelWidth"><el-input v-model="clickform.user_discount" autocomplete="off"></el-input></el-form-item>
			<el-form-item label="积分比率:" :label-width="formLabelWidth"><el-input v-model="clickform.score_percentage" autocomplete="off"></el-input></el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="editlayout = false">取 消</el-button>
				<el-button type="primary" @click="editsure()">确 定</el-button>
			</div>
		</el-dialog>
	</div>
</template>
<script>
import axios from '../../axios.js';
import Rootpath from "../../../api/index.js"
export default {
	data() {
		return {
			total: 0,
      currentPage: 1,
      pagesize: 5,
			editlayout: false,
			addlayout: false,
			form: {
				user_level_name: '',
				upgrade_conditions: '',
				user_discount: '',
				score_percentage:''
			},
			clickform:{
				user_level_name: '',
				upgrade_conditions: '',
				user_discount: '',
				score_percentage:''
			},
			formLabelWidth: '150px',
			activeName: 'first',
			leavel_list: [],
			formInline: {
				user: '',
				region: ''
			}
		};
	},
	created(){
     this.ajaxData();
   },
	methods: {
		handleSizeChange(size) {
      this.pagesize = size
    },
    handleCurrentChange(currentPage) {
      this.currentPage = currentPage
    },
		handleClick() {
			console.log(1);
		},
		//获取点击的数据
		select(val){
			this.clickform=val;
		},
		deleteinfo(row) {
			let that = this;
			that.$confirm('删除等级后，等级属实会员将移至默认等级，请谨慎操作！', '提示', {
				confirmButtonText: '确定',
				cancelButtonText: '取消',
				type: 'warning'
			})
				.then(() => {
					// this.leavel_list.splice(row,1);
					axios.post(Rootpath.BASE_URL+'leaveldel', {
						id: row.id
						// data:that.form
						})
						.then(function (response) {
							console.log(response);
							if (response.data.code==1) {
 							 that.$alert(response.data.msg, '提示', {
  		            confirmButtonText: '确定',
  		            callback: action => {

  		            }

  		          });
 						 	that.ajaxData();
 						}else {
 							that.$alert(response.data.msg, '提示', {
 		            confirmButtonText: '确定',
 		            callback: action => {

 		            }

 		          });
 						}
						})
						.catch(function (error) {
							console.log(error);
						});
				})
				.catch(() => {
					that.$message({
						type: 'info',
						message: '已取消删除'
					});
				});
		},

		//获取数据
		async ajaxData(){
         const result = await axios.get(Rootpath.BASE_URL+'leavellist');
         // console.log(result);
				 this.leavel_list = result.data.leavel_list;
 				this.total = result.data.leavel_list.length;
      },
		//新增保存
		async addsure(){
			let that = this;
		  axios.post(Rootpath.BASE_URL + 'leaveladd', {
			 user_level_name: that.form.user_level_name,
			 upgrade_conditions: that.form.upgrade_conditions,
			 user_discount: that.form.user_discount,
			 score_percentage:that.form.score_percentage
								 // data:that.form
				 })
				 .then(function (response) {
						 // that.dialogFormVisible = false;
						 console.log(response);
						 that.addlayout=false;
						 if (response.data.msg=="添加成功") {
							 that.$alert(response.data.msg, '提示', {
 		            confirmButtonText: '确定',
 		            callback: action => {

 		            }

 		          });
						 	that.ajaxData();
						}else {
							that.$alert(response.data.msg, '提示', {
		            confirmButtonText: '确定',
		            callback: action => {

		            }

		          });
						}

				 })
				 .catch(function (error) {
						 console.log(error);
				 });
		},
		//编辑保存
		async editsure(index){
			let that=this;

					axios.post(Rootpath.BASE_URL+'leaveladd', {
						user_level_name: that.clickform.user_level_name,
						upgrade_conditions: that.clickform.upgrade_conditions,
						user_discount: that.clickform.user_discount,
						score_percentage:that.clickform.score_percentage
						// data:that.form
		  })
		  .then(function (response) {
				console.log(response);
		    that.editlayout=false;
		  })
		  .catch(function (error) {
		    console.log(error);
		  });
		},
	}
};
</script>
<style scoped>


	.text {
		display: flex;
		left: 20px;
		position: relative;
		top: 15px;
	}



	.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	} /*border: solid 1rpx #007AFF;
	*/

</style>
