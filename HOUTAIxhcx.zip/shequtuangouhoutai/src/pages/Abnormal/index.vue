<template>
  <div class="Service-page" style="margin: 20px;">
	  <el-tabs v-model="activeName" @tab-click="handleClick">
	     <el-tab-pane label="配送单" name="first">
				<div>
				<el-form :inline="true" :model="formInline">
				  <el-form-item label="输入单号" style="margin-top: 20px;">
					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item>
					<el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>		
				  </el-form-item>
				</el-form>
				</div>
					 <div class="right">
					 <el-button size="medium">导出查询结果</el-button>
					 </div>
					<div>
						<el-table
						    :data="tableData"
						    stripe
						    style="width: 100%">
						    <el-table-column
							   prop="name"
							  align="center" 
						      label="订单号"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center" 
						      prop="name"
						      label="店铺名称"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center" 
						      prop="address"
						      label="下单金额">
						    </el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="发货日期">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="发货金额">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="付款状态">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="订单状态">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="订单来源">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="操作">
							</el-table-column>
						  </el-table>
					</div>
				<div class="paging">
			  <div style="padding-left:80%;align-items: center;padding-top:9px;" class="flex">
				<div style="line-height:25px;">1/6页，54条结果</div>
				 <el-pagination>
				 </el-pagination>
			</div>
		</div>
		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
export default {
  name: 'first',
  components: {},
   data() {
        return {
			 activeName: 'first',
			  num: 1,
			   formInline: {
			            user: '',
			            region: ''
			          },
          tableData: [{
            date: '2016-05-02',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1518 弄'
          }, {
            date: '2016-05-04',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1517 弄'
          }, {
            date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  }]
        }
      },
	   methods: {
	        handleChange(value) {
	          console.log(value);
	        },
			onSubmit() {
			        console.log('submit!');
			      }
	      }
};
</script>
<style scoped>
</style>
