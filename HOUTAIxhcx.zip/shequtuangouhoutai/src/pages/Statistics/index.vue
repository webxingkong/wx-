<template>
	<div class="select">
		<div class="select-table">
			<el-tabs v-model="activeName">
				<!--列表模式-->
				<el-tab-pane label="商品模式" name="first">
					<el-radio-group v-model="tabPosition">
						<el-radio-button label="thisweek">本周</el-radio-button>
						<el-radio-button label="lastweek">上周</el-radio-button>
						<el-radio-button label="thismonth">本月</el-radio-button>
						<el-radio-button label="lastmonth">上月</el-radio-button>
					</el-radio-group>
					<!--时间选择器-->
					&emsp;
					<span class="demonstration">日期：</span>
					<el-date-picker v-model="value1" type="datetime" placeholder="选择日期时间"></el-date-picker>
				&emsp;
				<el-button size="medium" type="primary">搜索</el-button></el-form-item>
				<br /><br />
				<!--布局模块-->
				<el-row :gutter="20">
				  <el-col :span="5">
					  <el-row class="Border flex_m">
					  	<el-col :span="8">
					  		<div class="grid-content flex_c_m"><img src="../../assets/Order.png" width="55px" /></div>
					  	</el-col>
					  	<el-col :span="15">
					  		<div class="grid-content">

					  			<h1>{{top_profit.shop_money}}</h1>
					  			实际收入
					  		</div>
					  	</el-col>
					  </el-row>
				  </el-col>
				  <el-col :span="5">
					  <el-row class="Border flex_m">
					  	<el-col :span="8">
					  		<div class="grid-content flex_c_m"><img src="../../assets/pen.png" width="66px" /></div>
					  	</el-col>
					  	<el-col :span="15">
					  		<div class="grid-content">

					  			<h1>{{top_profit.cost_sum_count}}</h1>
					  			总成本
					  		</div>
					  	</el-col>
					  </el-row>
				  </el-col>
				  <el-col :span="4">
					  <el-row class="Border flex_m">
					  	<el-col :span="8">
					  		<div class="grid-content flex_c_m"><img src="../../assets/single.png" width="55px" /></div>
					  	</el-col>&emsp;
					  	<el-col :span="15">
					  		<div class="grid-content">

					  			<h1>{{top_profit.comm_sum_count}}</h1>
					  			总佣金
					  		</div>
					  	</el-col>
					  </el-row>
				  </el-col>
				  <el-col :span="5">
					  <el-row class="Border flex_m">
					  	<el-col :span="8">
					  		<div class="grid-content flex_c_m"><img src="../../assets/retreat.png" width="68px" /></div>
					  	</el-col>
					  	<el-col :span="15">
					  		<div class="grid-content">

					  			<h1>{{top_profit.gross_profit_sum}}</h1>
					  			毛利
					  		</div>
					  	</el-col>
					  </el-row>
				  </el-col>
				  <el-col :span="5">
					  <el-row class="Border flex_m">
					  	<el-col :span="8">
					  		<div class="grid-content flex_c_m"><img src="../../assets/Subtotal.png" width="55px" /></div>
					  	</el-col>
					  	<el-col :span="16">
					  		<div class="grid-content">

					  			<h1>{{top_profit.gross_profit_margin}}</h1>
					  			毛利率
					  		</div>
					  	</el-col>
					  </el-row>
				  </el-col>
				</el-row>
				<br>
				<br>
				<br>

				<!--表格-->
				<el-table :data="shop_profit_list.slice((currentPage-1)*pagesize,currentPage*pagesize)">
					<el-table-column property="product_name" label="商品名称" ></el-table-column>
					<el-table-column property="product_sort_name" label="分类" ></el-table-column>
					<el-table-column property="order_price" label="订货金额" ></el-table-column>
					<el-table-column property="unit_price" label="优惠金额" ></el-table-column>
					<el-table-column property="return_price" label="退货金额" ></el-table-column>
					<el-table-column property="selling_cost" label="销售成本" ></el-table-column>
					<el-table-column property="refund_cost" label="退货成本" ></el-table-column>
					<el-table-column property="leader_com" label="团长佣金" ></el-table-column>
					<el-table-column property="user_com" label="会员佣金" ></el-table-column>
					<el-table-column property="gross_profit" label="毛利" ></el-table-column>
					<el-table-column property="gross_profit_margin" label="毛利率"></el-table-column>
				</el-table>
				<!--分页--><br>
				 <el-pagination class="block"
				     background
				     @size-change="handleSizeChange"
				     @current-change="handleCurrentChange"
				     :current-page="currentPage"
				     :page-sizes="[5, 10, 20, 50]"
				     :page-size="pagesize"
				     layout="total, sizes, prev, pager, next, jumper"
				     :total="total">
				   </el-pagination>
				</el-tab-pane>

				<!--图表模式-->
				<el-tab-pane label="团长模式" name="second">
					<el-radio-group v-model="commander_tabPosition">
						<el-radio-button label="commander_thisweek">本周</el-radio-button>
						<el-radio-button label="commander_lastweek">上周</el-radio-button>
						<el-radio-button label="commander_thismonth">本月</el-radio-button>
						<el-radio-button label="commander_lastmonth">上月</el-radio-button>
						</el-radio-group>
						<!--时间选择器-->
						&emsp;
						<span class="demonstration">日期：</span>
						<el-date-picker v-model="value1" type="datetime" placeholder="选择日期时间"></el-date-picker>
					&emsp;
					<el-button size="medium" type="primary">搜索</el-button></el-form-item>
					<br /><br />
					<!--布局模块-->
					<el-row :gutter="20">
					  <el-col :span="5">
						  <el-row class="Border flex_m">
						  	<el-col :span="8">
						  		<div class="grid-content flex_c_m"><img src="../../assets/Order.png" width="55px" /></div>
						  	</el-col>
						  	<el-col :span="15">
						  		<div class="grid-content">

						  			<h1>{{top_profit.shop_money}}</h1>
						  			实际收入
						  		</div>
						  	</el-col>
						  </el-row>
					  </el-col>
					  <el-col :span="5">
						  <el-row class="Border flex_m">
						  	<el-col :span="8">
						  		<div class="grid-content flex_c_m"><img src="../../assets/pen.png" width="65px" /></div>
						  	</el-col>
						  	<el-col :span="15">
						  		<div class="grid-content">

						  			<h1>{{top_profit.cost_sum_count}}</h1>
						  			总成本
						  		</div>
						  	</el-col>
						  </el-row>
					  </el-col>
					  <el-col :span="4">
						  <el-row class="Border flex_m">
						  	<el-col :span="8">
						  		<div class="grid-content flex_c_m"><img src="../../assets/single.png" width="55px" /></div>
						  	</el-col>&emsp;
						  	<el-col :span="15">
						  		<div class="grid-content">

						  			<h1>{{top_profit.comm_sum_count}}</h1>
						  			总佣金
						  		</div>
						  	</el-col>
						  </el-row>
					  </el-col>
					  <el-col :span="5">
						  <el-row class="Border flex_m">
						  	<el-col :span="8">
						  		<div class="grid-content flex_c_m"><img src="../../assets/retreat.png" width="68px" /></div>
						  	</el-col>
						  	<el-col :span="15">
						  		<div class="grid-content">

						  			<h1>{{top_profit.gross_profit_sum}}</h1>
						  			毛利
						  		</div>
						  	</el-col>
						  </el-row>
					  </el-col>
					  <el-col :span="5">
						  <el-row class="Border flex_m">
						  	<el-col :span="8">
						  		<div class="grid-content flex_c_m"><img src="../../assets/Subtotal.png" width="55px"/></div>
						  	</el-col>
						  	<el-col :span="16">
						  		<div class="grid-content">

						  			<h1>{{top_profit.gross_profit_margin}}</h1>
						  			毛利率
						  		</div>
						  	</el-col>
						  </el-row>
					  </el-col>
					</el-row>
					<br><br><br>
					<!--列表-->
	 <el-table :data="commandershop_profit_list.slice((commandercurrentPage-1)*commanderpagesize,commandercurrentPage*commanderpagesize)">
	 	<el-table-column property="product_name" label="商品名称" ></el-table-column>
	 	<el-table-column property="product_sort_name" label="分类" ></el-table-column>
	 	<el-table-column property="order_price" label="订货金额" ></el-table-column>
	 	<el-table-column property="unit_price" label="优惠金额" ></el-table-column>
	 	<el-table-column property="return_price" label="退货金额" ></el-table-column>
	 	<el-table-column property="selling_cost" label="销售成本" ></el-table-column>
	 	<el-table-column property="refund_cost" label="退货成本" ></el-table-column>
	 	<el-table-column property="leader_com" label="团长佣金" ></el-table-column>
	 	<el-table-column property="user_com" label="会员佣金" ></el-table-column>
	 	<el-table-column property="gross_profit" label="毛利" ></el-table-column>
	 	<el-table-column property="gross_profit_margin" label="毛利率"></el-table-column>
	 </el-table>
			  <!--分页--><br>
			   <el-pagination class="block"
			       background
			       @size-change="commanderSizeChange"
			       @current-change="commanderCurrentChange"
			       :current-page="commandercurrentPage"
			       :page-sizes="[5, 10, 20, 50]"
			       :page-size="commanderpagesize"
			       layout="total, sizes, prev, pager, next, jumper"
			       :total="commandertotal">
			     </el-pagination>
			</el-tab-pane>
			</el-tabs>
		</div>
	</div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
import VeLine from 'v-charts/lib/line'
export default {
	data() {
		 this.typeArr = ['line', 'histogram', 'pie','bar','waterfall']//
		      this.index = 0//

		return {

			activeName: 'first',
			tabPosition: 'thisweek',
			commander_tabPosition:'commander_thisweek',
			value1: '',
			value2: '',
			total: 0,
			currentPage: 1,
			commanderpagesize: 5,
			commandertotal: 0,
			commandercurrentPage: 1,
			pagesize: 5,
			top_profit:[],
			value3: '',
			shop_profit_list: [],
			commandertop_profit:[],
			commandershop_profit_list:[],
		};

	},
	created() {
			this.getData();
	},
components: { VeLine },
	methods: {
		handleClick(tab, event) {
			console.log(tab, event);
		},
		// 获取数据
		async getData() {
				const result = await axios.get(Rootpath.BASE_URL + 'gross_profit?time=' + this.tabPosition);
				// console.log(result.data);
				this.top_profit = result.data.top_profit;
				this.shop_profit_list = result.data.shop_profit_list;
				this.total = result.data.shop_profit_list.length;
				const json = await axios.get(Rootpath.BASE_URL + 'gross_profit_le?time=' + this.commander_tabPosition);
				// console.log(result.data);
				this.commandertop_profit = result.data.top_profit;
				this.commandershop_profit_list = result.data.shop_profit_list;
				this.commandertotal = result.data.shop_profit_list.length;
		},
		//分页
		handleSizeChange(size) {
			this.pagesize = size;
		},
		handleCurrentChange(currentPage) {
			this.currentPage = currentPage;
		},
		//分页
		commanderSizeChange(commandersize) {
			this.commanderpagesize = commandersize;
		},
		commanderCurrentChange(commandercurrentPage) {
			this.commandercurrentPage = commandercurrentPage;
		},



	},

	//

};

</script>


<style scoped>
.grid-content{
height: 60px;
	}
	.Border{
		box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
	}
	h1{
		font-size: 20px;
	}
	.block {
		text-align: right;
	}
	.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
</style>
