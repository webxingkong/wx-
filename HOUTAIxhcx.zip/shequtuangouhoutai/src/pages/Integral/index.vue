<template>
	<div class="select Integral-page">
		<div class="select-table">
			<el-tabs v-model="activeName" @tab-click="handleClick">
				<!--积分商城设置-->

					<el-tab-pane label="积分商商城设置" name="second">
						<div class="frame">
							<span>积分商城开启状态： </span>
							<el-switch
							  v-model="value"
							  active-color="#999999"
							  inactive-color="#436BE5">
							</el-switch>
							<br><br>
							<span> &emsp;自定义积分名称：</span>
							<el-input  size="small" v-model="input" placeholder="请输入内容" style="width: 240px;"></el-input>
							<br><br>
						<span >&emsp;积分商城广告图:</span><br><br>
						<el-upload
						  action="https://jsonplaceholder.typicode.com/posts/"
						  list-type="picture-card"
						  :on-preview="handlePictureCardPreview"
						  :on-remove="handleRemove" class="upload">
						  <i class="el-icon-plus"></i>
						</el-upload>
						<el-dialog :visible.sync="dialogVisible">
						  <img width="100%" :src="dialogImageUrl" alt="">
						</el-dialog> <br>
						<span class="text2">图片尺寸宽度706px，高度238px，大小≤6MB，支持JPG、PNG、JPEG</span><br><br><br>
						<span class="textright">转发标题：</span>
						<el-input  size="small" v-model="input" placeholder="请输入内容" style="width: 240px;"></el-input><br><br>
						<span>&emsp;转发分享图片：</span><br><br>
						<el-upload
						  action="https://jsonplaceholder.typicode.com/posts/"
						  list-type="picture-card"
						  :on-preview="handlePictureCardPreview"
						  :on-remove="handleRemove" class="upload">
						  <i class="el-icon-plus"></i>
						</el-upload> <br>
						<el-dialog :visible.sync="dialogVisible">
						  <img width="100%" :src="dialogImageUrl" alt="" >
						</el-dialog>
						<span class="text2">图片尺寸宽度500px，高度400px，大小≤6MB，支持JPG、PNG、JPEG</span>
						<br><br>
						<el-button size="small" type="primary"  class="upload">保存</el-button>
						<br />
						<br /></div>
					</el-tab-pane>

				<!--积分商品-->
				<el-tab-pane label="积分商品" name="first">
					<el-button size="small" type="primary" @click="dialogTableVisible = true">添加活动商品</el-button>
					<br /><br />
					<el-table :data="tableData" style="width: 100%">

						<el-table-column prop="name" label="商品名称"></el-table-column>
						<el-table-column prop="Company" label="单位"></el-table-column>
						<el-table-column prop="address" label="商品价"></el-table-column>
						<el-table-column prop="address" label="兑换积分"><input placeholder="请输入兑换积分" style="width: 100px;"></input></el-table-column>
						<el-table-column prop="address" label="单人限购"><input placeholder="请输入限购数量" style="width: 100px;"></input></el-table-column>
						<el-table-column prop="address" label="排序号"><input style="width: 100px;"></input></el-table-column>
						<el-table-column fixed="right" label="操作" width="50">
							<template slot-scope="scope">
								<el-button type="text" size="small">删除</el-button>

							</template>
						</el-table-column>
					</el-table>

					<br />
					<el-button size="small">取消</el-button>
					<el-button size="small" type="primary">保存</el-button>
					<br><br>
					</el-tab-pane>
			</el-tabs>
		</div>
		<!--选择商品弹窗-->
		<el-dialog title="请选择商品" :visible.sync="dialogTableVisible" width="60%">
			<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				<el-form-item label="状态">
					<el-select size="small" v-model="values" placeholder="请选择" style=" width: 120px;">
						<el-option v-for="item in options" :key="item.values" :label="item.label" :value="item.values"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="商品名称"><el-input size="small" v-model="formInline.goodsname" style="width: 120px;"></el-input></el-form-item>
				<el-form-item label="编码"><el-input size="small" v-model="formInline.goodscode" style="width: 120px;"></el-input></el-form-item>
				<el-form-item label="分类"><el-input size="small" v-model="formInline.goodscode" style="width: 120px;"></el-input></el-form-item>

				<el-form-item><el-button size="small" type="primary">搜索</el-button></el-form-item>
			</el-form>
			<!--表单-->
			<el-table ref="multipleTable" :data="gridData" tooltip-effect="dark" style="width: 100%">
				<el-table-column type="selection" width="55"></el-table-column>
				<el-table-column prop="name" label="商品图片" ></el-table-column>
				<el-table-column prop="code" label="商品名称" ></el-table-column>
				<el-table-column prop="Company" label="单位" ></el-table-column>
				<el-table-column prop="urls" label="商城价" ></el-table-column>

				<el-table-column fixed="right" label="操作" width="60">
					<template slot-scope="scope">
						<el-button type="text" size="small">添加</el-button>
					</template>
				</el-table-column>
			</el-table>
			<br />
			<br />
			<!--分页-->
			<el-pagination
				class="block"
				background
				@size-change="handleSizeChange"
				@current-change="handleCurrentChange"
				:current-page="currentPage"
				:page-sizes="[5, 10, 20, 50]"
				:page-size="pagesize"
				layout="total, sizes, prev, pager, next, jumper"
				:total="total"
			></el-pagination>
			<br />
			<div style="text-align: right;"><el-button size="small" type="primary">选择</el-button></div>
		</el-dialog>
	</div>
</template>

<script>
export default {
	data() {
		return {
			activeName: 'second',
			value: true,
			radio: '1',
			input: '',
			dialogImageUrl: '',
			dialogVisible: false,
			integrals_list: [],
			gridData: [
				{
					name: '八宝粥',
					code: 'SFS65986',
					Company: '盒',
					class: '饮品',
					Warehouse: '默认',
					Price: '￥12.0',
					Stock: '500'
				},
				{
					name: '八宝粥',
					code: 'SFS65986',
					Company: '盒',
					class: '饮品',
					Warehouse: '默认',
					Price: '￥12.0',
					Stock: '500'
				},
				{
					name: '八宝粥',
					code: 'SFS65986',
					Company: '盒',
					class: '饮品',
					Warehouse: '默认',
					Price: '￥12.0',
					Stock: '500'
				},
				{
					name: '八宝粥',
					code: 'SFS65986',
					Company: '盒',
					class: '饮品',
					Warehouse: '默认',
					Price: '￥12.0',
					Stock: '500'
				}
			],
			dialogTableVisible: false,
			formInline: {
				user: '',
				region: '',
				Name: '',
				times: '',
				Mobilephone: '',
				Names: '',
				states: '',
				state: ''
			},
			options: [
				{
					values: '选项1',
					label: '黄金糕'
				},
				{
					values: '选项2',
					label: '双皮奶'
				},
				{
					values: '选项3',
					label: '蚵仔煎'
				},
				{
					values: '选项4',
					label: '龙须面'
				},
				{
					values: '选项5',
					label: '北京烤鸭'
				}
			],
			values: ''
		};
	},
	created(){
		this.getData();
	},
	methods: {
		handleClick(tab, event) {
			console.log(tab, event);
		},
		//分页
		handleSizeChange(size) {
			this.pagesize = size;
		},
		handleCurrentChange(currentPage) {
			this.currentPage = currentPage;
		},
//上传
  	handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePictureCardPreview(file) {
        this.dialogImageUrl = file.url;
        this.dialogVisible = true;
      },
			// 获取数据
			async getData (){
					const result = await getHomeCasual('accumulate','tupian');
					this.integrals_list = result.integrals_list
					this.total = result.integrals_list.length
			}
	}
};
</script>

<style scoped>
.text2{
	font-size: 13px;
	color: #999999;
	margin-left: 150px;
}

.select-table {
	margin: auto;
	width: 96%;
	margin-top: 20px;
}
.select {
	margin: auto;
	width: 96%;
	background-color: #ffffff;
}
.text1 {
	font-size: 13px;

}
.block {
	text-align: right;
	margin-top: -15px;
}
.frame{
	margin-left: 80px;
}
.textright{
	margin-left: 50px;
}
.upload{
	margin-left: 150px;
}
</style>
