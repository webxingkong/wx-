<template>
	<div class="select Accessdetails-page">
		<div class="select-table">
			<el-tabs v-model="activeName">
				<el-tab-pane label="出入库详情" name="first">
					<div class="search">
						<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
							<el-form-item label="仓库" style="margin-top: 20px;">
								<el-select v-model="price" placeholder="请选择" size="small" style="width: 130px;">
									<el-option v-for="item in option" :key="item.price" :label="item.labe" :value="item.price" :disabled="item.disabled"></el-option>
								</el-select>
							</el-form-item>
							<el-form-item label="商品名称" style="margin-top: 20px;">
								<el-input size="small" v-model="formInline.region" style="width: 120px;"></el-input>
							</el-form-item>

							<el-form-item label="商品编码" style="margin-top: 20px;">
								<el-input size="small" v-model="formInline.Name" style="width: 120px;"></el-input>
							</el-form-item>

							<el-form-item label="入库时间" style="margin-top: 20px;">
								<el-date-picker v-model="value1" type="datetime" placeholder="选择日期时间"></el-date-picker>
							</el-form-item>
							&emsp;
							<el-form-item><el-button size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button></el-form-item>
						</el-form>
					</div>
					<br />
					<br />
					<br />

					<div class="block"><el-button size="medium">导出查询结果</el-button></div>
					<br />
					<el-table ref="multipleTable" :data="tableData" tooltip-effect="dark" style="width: 100%">
						<el-table-column width="55"></el-table-column>
						<el-table-column prop="shop" label="商品名称" width="150"></el-table-column>
						<el-table-column prop="Code" label="编码" width="150"></el-table-column>
						<el-table-column prop="single" label="关联单号" width="150"></el-table-column>

						<el-table-column prop="Out" label="出库时间" width="180"></el-table-column>
						<el-table-column prop="entertime" label="入库时间" width="180"></el-table-column>
						<el-table-column prop="state" label="操作前库存" width="150"></el-table-column>
						<el-table-column prop="Accessamount" label="出入库数量" width="150"></el-table-column>
						<el-table-column prop="Balance" label="结余库存" width="150"></el-table-column>
						<el-table-column prop="Stockpurchase" label="进货价" width="150"></el-table-column>
						<el-table-column prop="Shipment" label="出货价" width="150"></el-table-column>
						<el-table-column prop="cost" label="成本价" width="150"></el-table-column>
						<el-table-column prop="gold" label="出入库金额" width="150"><I>80.0</I></el-table-column>
					</el-table>
					<br />
					<!--分页-->
					 <el-pagination class="block"
					     background
					     @size-change="handleSizeChange"
					     @current-change="handleCurrentChange"
					     :current-page="currentPage"
					     :page-sizes="[5, 10, 20, 50]"
					     :page-size="pagesize"
					     layout="total, sizes, prev, pager, next, jumper"
					     :total="total">
					   </el-pagination>
				</el-tab-pane>
			</el-tabs>
		</div>
	</div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			activeName: 'first',
			tableData: [],
			formInline: {
				user: '',
				region: '',
				Name: '',
				times: '',
				Mobilephone: '',
				Names: ''
			},

			options: [
				{
					value: '选项1',
					label: '应季水果'
				},
				{
					value: '选项2',
					label: '反季水果'
				},
				{
					value: '选项3',
					label: '应季蔬菜'
				},
				{
					value: '选项4',
					label: '反季蔬菜'
				},
				{
					value: '选项5',
					label: '牛奶'
				}
			],
			value: '',
			option: [
				{
					price: '选项1',
					labe: '南宁农贸市场'
				},
				{
					price: '选项2',
					labe: '新和平批发市场'
				},
				{
					price: '选项3',
					labe: '石埠市场'
				},
				{
					price: '选项4',
					labe: '滨江华府农贸市场'
				},
				{
					price: '选项5',
					labe: '菜市场'
				}
			],
			price: '',
			value1: '',
			value2: '',
			value3: ''
		};
	},
	created() {
			this.getData();
	},
	methods: {
		onSubmit() {
			console.log('submit!');
		},
		async getData() {
		    var storage_number = this.$route.query.pn
		    const result = await axios.get(Rootpath.BASE_URL + 'storageInfo?sno=' + storage_number);
				this.basic_info=result.data.info.basic_info;
				this.goodsList=result.data.info.goodsList;
				this.record=result.data.info.record;
		},
		//分页
		handleSizeChange(size) {
		  this.pagesize = size
		},
		handleCurrentChange(currentPage) {
		  this.currentPage = currentPage
		},
	}
};
</script>

<style scoped>

.block{
	text-align: right;
}
.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
</style>
