<template>
	<div class="select Access-page">
		<div class="select-table">
			<el-tabs v-model="activeName">
				<el-tab-pane label="出入库存" name="first">
					<div class="search">
						<el-form :inline="true" :model="searchlist" class="demo-form-inline search-Button">
							<el-form-item label="仓库" style="margin-top: 20px;">
								<el-select v-model="price" placeholder="请选择" size="small" style="width: 130px;">
									<el-option v-for="item in option" :key="item.price" :label="item.labe" :value="item.price" :disabled="item.disabled"></el-option>
								</el-select>
							</el-form-item>
							<el-form-item label="商品名称" style="margin-top: 20px;">
								<el-input size="small" v-model="searchlist.product_name" style="width: 120px;"></el-input>
							</el-form-item>

							<el-form-item label="商品编码" style="margin-top: 20px;">
								<el-input size="small" v-model="searchlist.product_number" style="width: 120px;"></el-input>
							</el-form-item>

							<el-form-item label="商品种类" style="margin-top: 20px;">
								<el-select v-model="value" placeholder="请选择" size="small" style="width: 130px;">
									<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" :disabled="item.disabled"></el-option>
								</el-select>
							</el-form-item>
							&emsp;
							<el-form-item><el-button size="small" type="primary" @click="search" style="margin-top: 23px;">搜索</el-button></el-form-item>
						</el-form>
					</div>
					<br />
					<br />
					<br />
					<div>入库总金额：<i>{{storageprice}}</i>&emsp;出库总金额：<i>{{deliveryprice}}</i></div>
					<div class="block"><el-button size="medium">导出查询结果</el-button></div>
					<br />
					<el-table ref="multipleTable" :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)" tooltip-effect="dark" style="width: 100%">
						<el-table-column align="center" width="55"></el-table-column>
						<el-table-column align="center" prop="product_name" label="商品名称"></el-table-column>
						<el-table-column align="center" prop="product_number" label="编码"></el-table-column>
						<el-table-column align="center" prop="warehouses" label="仓库"></el-table-column>
						<el-table-column align="center" prop="storage_count" label="入库数量"></el-table-column>
						<el-table-column align="center" prop="delivery_count" label="出库数量"></el-table-column>
						<el-table-column align="center" prop="storageg_price" label="入库金额"></el-table-column>
						<el-table-column align="center" prop="delivery_price" label="出库金额"></el-table-column>
						<!-- <el-table-column align="center" prop="all" label="成本均价"></el-table-column> -->
						<!-- <el-table-column align="center" prop="present" label="现有库存" show-overflow-tooltip></el-table-column> -->
						<el-table-column align="center" label="操作">
							<template slot-scope="scope">
								<el-button type="text" size="small" @click="Accessdetails(scope.row)">详情</el-button>
							</template>
						</el-table-column>
					</el-table>
					<!--分页-->
					 <el-pagination class="block"
					     background
					     @size-change="handleSizeChange"
					     @current-change="handleCurrentChange"
					     :current-page="currentPage"
					     :page-sizes="[5, 10, 20, 50]"
					     :page-size="pagesize"
					     layout="total, sizes, prev, pager, next, jumper"
					     :total="total">
					   </el-pagination>
				</el-tab-pane>
			</el-tabs>
		</div>
	</div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			activeName: 'first',
			tableData: [],
			total: 0,
			info:[],
			currentPage: 1,
			pagesize: 5,
			searchlist: {
				product_number: '',
				product_name: '',
				warehouse: '',
				sort_id: ''
			},



			options: [
				{
					value: '选项1',
					label: '应季水果'
				},
				{
					value: '选项2',
					label: '反季水果'
				},
				{
					value: '选项3',
					label: '应季蔬菜'
				},
				{
					value: '选项4',
					label: '反季蔬菜'
				},
				{
					value: '选项5',
					label: '牛奶'
				}
			],
			value: '',
			option: [
				{
					price: '选项1',
					labe: '南宁农贸市场'
				},
				{
					price: '选项2',
					labe: '新和平批发市场'
				},
				{
					price: '选项3',
					labe: '石埠市场'
				},
				{
					price: '选项4',
					labe: '滨江华府农贸市场'
				},
				{
					price: '选项5',
					labe: '菜市场'
				}
			],
			price:'',
		};
	},
	//计算属性
	computed:{
				//出库金额
			 deliveryprice:function(){
	 			let dl=this.tableData;
	 			let d=0;
	 			for (var i = 0; i < dl.length; i++) {
	 				d+=dl[i].delivery_count * dl[i].delivery_price;
	 			}
	 			return d;
	 		},
			//入库金额
			storageprice:function(){
			 let sl=this.tableData;
			 let s=0;
			 for (var i = 0; i < sl.length; i++) {
				 s+=sl[i].storage_count * sl[i].storage_price;
			 }
			 return s;
		 },
	 },
	created() {
			this.getData();
	},
	methods: {
		onSubmit() {
			console.log('submit!');
		},
		// 获取数据
		async getData() {
				const result = await axios.get(Rootpath.BASE_URL + 'warehouDelivery');
				console.log(result);
				this.info=result.data.info;
				this.tableData=result.data.info;
				this.total = result.data.info.length;
				console.log(result.data.info);
		},
		//详情
		Accessdetails(row){
		 this.$router.push({path:'/library/Access/Accessdetails',query: {pn:row.product_name}});
		},
		//搜索
    async search() {
        let that = this;
        axios.get(Rootpath.BASE_URL + 'warehouDelivery_search', {
                params: {
                    product_number: that.searchlist.product_number,
                    product_name: that.searchlist.product_name,
                    warehouse: that.price,
                    sort_id: that.value
                }
            })
            .then(function (response) {
                console.log(response);
                // that.tableData = response.data.info.warehou_list;
                // that.total = response.data.info.warehou_list.length;
            })
            .catch(function (error) {
                console.log(error);
            });
    },
		//分页
		handleSizeChange(size) {
		  this.pagesize = size
		},
		handleCurrentChange(currentPage) {
		  this.currentPage = currentPage
		},
	},
};
</script>

<style scoped>

.block{
	text-align: right;
}
.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
</style>
