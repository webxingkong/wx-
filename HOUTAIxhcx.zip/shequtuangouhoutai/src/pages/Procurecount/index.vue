<template>
  <div class="Service-page" style="margin: 20px;">
	  <el-tabs v-model="activeName" @tab-click="handleClick">
	     <el-tab-pane label="采购结算" name="first">
			 <!-- 付款弹层 -->
	 <el-dialog
	   title="付款记录"
	   :visible.sync="payments"
	   width="40%"
	   :before-close="payments">
		 <hr />
	  <div>
	<el-table
		  :data="tableData"
		  style="width: 100%">
		  <el-table-column
		  align="center"
			prop="date"
			label="流水号"
			width="180">
		  </el-table-column>
		  <el-table-column
		    align="center"
			prop="name"
			label="业务日期"
			width="180">
		  </el-table-column>
		  <el-table-column
		    align="center"
			prop="name"
			label="付款金额"
			width="180">
		  </el-table-column>
		  <el-table-column
		    align="center"
			prop="name"
			label="经办人"
			width="180">
		  </el-table-column>
		  <el-table-column
		    align="center"
			prop="name"
			label="备注"
			width="180">
		  </el-table-column>
		</el-table>
		<div style="padding-left:60%;height: 32px;"><!-- 分页点击栏靠右边 -->
				<span>1/6页,45条结果</span>
				<el-input-number size="mini" v-model="num" controls-position="right" @change="handleChange" :min="1" style="width:80px;"></el-input-number>
				<span class="menu-icon"><i class="el-icon-arrow-left" /></span>
				<span class="menu-icon"><i class="el-icon-arrow-right" /></span>
				<el-button size="mini">指定跳转</el-button>
		</div>
		</div>  			  
		 <hr />
	   <span slot="footer" class="dialog-footer">
		 <el-button type="primary" @click="payments = false">关闭</el-button>
	   </span>
	 </el-dialog>
				<!-- 付款记录弹层 -->
				    <div>
			<el-dialog
			  title="新增付款"
			  :visible.sync="Payment_record"
			  width="25%"
			  :before-close="Payment_record">
			    <hr />
<div style="width:500px;padding-left:60px">
	<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
  <el-form-item label="流水号" prop="name">
    <el-input v-model="ruleForm.name"></el-input>
  </el-form-item>
    <el-form-item label="收款人" prop="name" required>
    <el-input v-model="ruleForm.name"></el-input>
  </el-form-item>
      <el-form-item label="应付金额" prop="name">
    <el-input v-model="ruleForm.name"></el-input>
  </el-form-item>
        <el-form-item label="本次付款" prop="name" required>
    <el-input v-model="ruleForm.name"></el-input>
  </el-form-item>
  <el-form-item label="经办人" prop="region">
    <el-select v-model="ruleForm.region" placeholder="请选择活动区域">
      <el-option label="区域一" value="shanghai"></el-option>
      <el-option label="区域二" value="beijing"></el-option>
    </el-select>
  </el-form-item>
  <el-form-item label="付款日期" >
    <el-col :span="11">
      <el-form-item prop="应付金额">
        <el-date-picker type="date" placeholder="选择日期" v-model="ruleForm.date1" style="width: 100%;"></el-date-picker>
      </el-form-item>
    </el-col>
    <el-col :span="11">
    </el-col>
  </el-form-item>
  <el-form-item label="是否付款" prop="type">
    <el-checkbox-group v-model="ruleForm.type">
      <el-checkbox label="付款完成" name="type"></el-checkbox>
    </el-checkbox-group>
  </el-form-item>
  <el-form-item label="备注" prop="desc">
    <el-input type="textarea" v-model="ruleForm.desc"></el-input>
  </el-form-item>
  </el-form>
</div>
				<hr />
			  <span slot="footer" class="dialog-footer">
							 <el-button @click="Payment_record = false">取 消</el-button>
							 <el-button type="primary" @click="Payment_record = false">确 定</el-button>
			  </span>
			</el-dialog>
					</div>

				<div>
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				  <el-form-item label="全部" style="margin-top: 20px;">
					 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
					    <el-option
					      v-for="item in options"
					      :key="item.value"
					      :label="item.label"
					      :value="item.value">
					    </el-option>
					  </el-select>
				  </el-form-item>
				  <el-form-item label="采购员" style="margin-top: 20px;">
				  					 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
				  					    <el-option
				  					      v-for="item in options"
				  					      :key="item.value"
				  					      :label="item.label"
				  					      :value="item.value">
				  					    </el-option>
				  					  </el-select>
				  </el-form-item>
				  <el-form-item label="供应商" style="margin-top: 20px;">
				  					 <el-select v-model="value" placeholder="请选择" style="width: 120px;"  size="small">
				  					    <el-option
				  					      v-for="item in options"
				  					      :key="item.value"
				  					      :label="item.label"
				  					      :value="item.value">
				  					    </el-option>
				  					  </el-select>
				  </el-form-item>
				  <el-form-item label="采购单号" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
				  <el-form-item label="收货单号" style="margin-top: 20px;">
				  					<el-input  size="small" v-model="formInline.user" style="width: 120px;"></el-input>
				  </el-form-item>
					<el-button  size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button>		
				  </el-form-item>
				</el-form>
				</div>
				<div style="margin: 15px; color:#606266;display: flex;">
					<div style="padding-left:20px">应付金额:$<font style="color: red;">93</font></div>
					<div style="padding-left:190px">已付金额:$<font style="color: red;">33</font></div>
					<div style="padding-left:190px">代付金额:$<font style="color: red;">593</font></div>
				</div>
					<div style="margin-top:15px;">
						<el-table
						    :data="tableData"
						    stripe
						    style="width: 100%">
						    <el-table-column
							   prop="name"
							  align="center" 
						      label="结算对象"
						      width="180">
							  <template slot-scope="scope">
								  <div>采购员:未设置</div>
								  <p>未设置</p>
							  </template>
						    </el-table-column>
						    <el-table-column
							  align="center" 
						      prop="name"
						      label="关联采购单"
						      width="180">
						    </el-table-column>
						    <el-table-column
							  align="center" 
						      prop="address"
						      label="收货单">
						    </el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="应付金额">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="已付金额">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="代付金额">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="状态">
							</el-table-column>
							<el-table-column
							  align="center" 
							  prop="address"
							  label="操作">
							 <template slot-scope="scope">
							 	        <el-button @click="payments=true" type="text" size="small">付款</el-button>
							 	        <el-button type="text" size="small" @click="Payment_record=true">付款记录</el-button>
							 	      </template>
							 	    </el-table-column>
						  </el-table>
					</div>
				<div class="paging">
			  <div style="padding-left:80%;align-items: center;padding-top:9px;" class="flex">
				<span>1/6页,45条结果</span>
				&emsp;
				<el-input-number size="mini" v-model="num" controls-position="right" @change="handleChange" :min="1" style="width:80px;"></el-input-number>
				&emsp;&emsp;
				<span class="menu-icon"><i class="el-icon-arrow-left" /></span>
				&emsp;
				<span class="menu-icon"><i class="el-icon-arrow-right" /></span>
				&emsp;
				<el-button size="mini">指定跳转</el-button>
			</div>
		</div>

		 </el-tab-pane>
	   </el-tabs>
  </div>
</template>
<script>
export default {
  name: 'first',
  components: {},
   data() {
        return {
			 activeName: 'first',
			 payments:false,
			//  付款
			 Payment_record:false,
			//  付款记录
			  num: 1,
			   formInline: {
			            user: '',
			            region: ''
					  },
					  ruleForm: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },

          tableData: [{
            date: '2016-05-02',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1518 弄'
          }, {
            date: '2016-05-04',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1517 弄'
          }, {
            date: '2016-05-01',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1519 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          }, {
            date: '2016-05-03',
            name: '王小虎',
            address: '上海市普陀区金沙江路 1516 弄'
          },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  },
		  {
		    date: '2016-05-03',
		    name: '王小虎',
		    address: '上海市普陀区金沙江路 1516 弄'
		  }],
		      options: [{
		            value: '选项1',
		            label: '黄金糕'
		          }, {
		            value: '选项2',
		            label: '双皮奶'
		          }, {
		            value: '选项3',
		            label: '蚵仔煎'
		          }, {
		            value: '选项4',
		            label: '龙须面'
		          }, {
		            value: '选项5',
		            label: '北京烤鸭'
		          }],
		          value: ''
		        }
      },
	   methods: {
	        handleChange(value) {
	          console.log(value);
	        },
			onSubmit() {
			        console.log('submit!');
			      },
	      }
};
</script>
<style scoped>
	.paging{
			position: fixed;
			right:0px;
			bottom:0px;
			background: #FAFAFA;
			width:100%;
			height:40px; 
			float: right;
			line-height: 0px;
			z-index: 999;
			 box-shadow: darkgrey 10px 10px 30px 5px ;
		}
</style>
