<template>
  <div class="Data-page" :data="assist_list">
	  <div class="headtitle flex_m">
      <i class="el-icon-star-on"></i>
      计算单位
    </div>
    <div class="content flex_wrap">
        <div class="msbtn flex_c_m" v-for="(item,index) in assist_list.unit" @click="getbtninfo($event,index)" :name="item.unit" :value="item.id" :key="index" @mouseenter="CompanymouseEnter(index)" @mouseleave="CompanymouseLeave">
            <div class="companyinfo">{{item.unit}}</div>
            <div class="mschice flex_lr_m" :class="{noactive:index!=Company}">
              <i class="el-icon-edit" @click="editcompany=true" style="margin: 0 10px;"></i>
              <i class="el-icon-delete" @click.stop="deletecompany($event,index)" :name="item.unit" :value="item.id" style="margin: 0 10px;"></i>
            </div>
        </div>
        <!-- <button type="button" name="button" size="mini">新增</button> -->
        <el-button class="addbtn" size="small" @click="addcompany = true">新增</el-button>
    </div>


    <div class="headtitle flex_m">
      <i class="el-icon-star-on"></i>
      商品标签
    </div>
    <div class="content flex_wrap">
        <div class="msbtn flex_c_m" v-for="(item,index) in assist_list.table" @click="getlabelmsg($event,index)" :name="item.product_label_name" :value="item.id" :key="index" @mouseenter="labelmouseEnter(index)" @mouseleave="labelmouseLeave">
            <span>{{item.product_label_name}}</span>
            <div class="mschice flex_lr_m" :class="{noactive:index!=label}">
              <i class="el-icon-edit" @click="editlabel=true" style="margin: 0 10px;"></i>
              <i class="el-icon-delete" @click.stop="deletelabel($event,index)" :name="item.product_label_name" :value="item.id" style="margin: 0 10px;"></i>
            </div>
        </div>
        <el-button class="addbtn" size="small" @click="addlabel = true">新增</el-button>
    </div>

    <!-- <div class="headtitle">
      <el-button type="primary" icon="el-icon-plus"  @click="addtype = true">新增多规模分组</el-button>
    </div>

    <div class="headtitle flex_fcs" style="padding-top:30px">
      <div class="flex_m">
        <i class="el-icon-star-on"></i>
        <span>口味</span>
      </div>
      <div class="flex_fcs" style="width:80px;padding-right:40px">
        <el-button type="text" style="color:#436BE5" @click="delect">删除</el-button>
        <el-button type="text" style="color:black" @click="edittype = true">修改</el-button>
      </div>
    </div>
    <div class="content flex_wrap">
        <div class="msbtn flex_c_m" v-for="(item,index) in assist_list.specs_group[0].product_specs" :key="index" @mouseenter="FlavormouseEnter(index)" @mouseleave="FlavormouseLeave">
            <span>{{item.product_specs_name}}</span>
            <div class="mschice flex_lr_m" :class="{noactive:index!=Flavor}">
              <i class="el-icon-edit" style="margin: 0 10px;"></i>
              <i class="el-icon-delete" style="margin: 0 10px;"></i>
            </div>
        </div>
        <el-button class="addbtn" size="small" @click="addFlavor = true">新增</el-button>
    </div>
    <div class="headtitle flex_fcs">
      <div class="flex_m">
        <i class="el-icon-star-on"></i>
        <span>规格</span>
      </div>
      <div class="flex_fcs" style="width:80px;padding-right:40px">
        <el-button type="text" style="color:#436BE5" @click="delect">删除</el-button>
        <el-button type="text" style="color:black" @click="edittype = true">修改</el-button>
      </div>
    </div>
    <div class="content flex_wrap">
        <div class="msbtn flex_c_m" v-for="(item,index) in assist_list.specs_group[2].product_specs" :key="index" @mouseenter="normsmouseEnter(index)" @mouseleave="normsmouseLeave">
            <span>{{item.product_specs_name}}</span>
            <div class="mschice flex_lr_m" :class="{noactive:index!=norms}">
              <i class="el-icon-edit" style="margin: 0 10px;"></i>
              <i class="el-icon-delete" style="margin: 0 10px;"></i>
            </div>
        </div>
        <el-button class="addbtn" size="small" @click="addnorms = true">新增</el-button>
    </div>

    <div class="headtitle flex_fcs">
      <div class="flex_m">
        <i class="el-icon-star-on"></i>
        <span>重量</span>
      </div>
      <div class="flex_fcs" style="width:80px;padding-right:40px">
        <el-button type="text" style="color:#436BE5" @click="delect">删除</el-button>
        <el-button type="text" style="color:black" @click="edittype = true">修改</el-button>
      </div>
    </div>
    <div class="content flex_wrap">
        <div class="msbtn flex_c_m" v-for="(item,index) in assist_list.specs_group[1].product_specs" :key="index" @mouseenter="weightmouseEnter(index)" @mouseleave="weightmouseLeave">
            <span>{{item.product_specs_name}}</span>
            <div class="mschice flex_lr_m" :class="{noactive:index!=weight}">
              <i class="el-icon-edit" style="margin: 0 10px;"></i>
              <i class="el-icon-delete" style="margin: 0 10px;"></i>
            </div>
        </div>
        <el-button class="addbtn" size="small" @click="addweight = true">新增</el-button>
    </div> -->

    <!-- 新增单位弹出框 -->
              <el-dialog title="新增单位" class="layoutbox" :visible.sync="addcompany">
                  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                      <el-form-item class="leftlabel" label="单位：">
                        <el-input class="inputtext" placeholder="长度不超过8位" v-model="add_company.addcompany_name"></el-input>
                      </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="addcompany = false">取 消</el-button>
                    <el-button type="primary" @click="addcompanylist()">确 定</el-button>
                  </span>
            </el-dialog>
    <!-- 新增单位弹出框  结束-->
    <!-- 修改单位弹出框 -->
              <el-dialog title="修改单位" class="layoutbox" :visible.sync="editcompany">
                  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                      <el-form-item class="leftlabel" label="单位：">
                        <el-input class="inputtext" placeholder="长度不超过8位" v-model="edit_company.addcompany_name"></el-input>
                      </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="editcompany = false">取 消</el-button>
                    <el-button type="primary" @click="editcompanylist()">确 定</el-button>
                  </span>
            </el-dialog>
    <!-- 修改单位弹出框  结束-->
    <!-- 新增标签弹出框 -->
              <el-dialog title="新增标签" class="layoutbox" :visible.sync="addlabel">
                  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                      <el-form-item class="leftlabel" label="标签：" prop="">
                        <el-input class="inputtext" placeholder="长度不超过位" v-model="add_label.addlabel_name"></el-input>
                      </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="addlabel = false">取 消</el-button>
                    <el-button type="primary" @click="addlabellist()">确 定</el-button>
                  </span>
            </el-dialog>
    <!-- 新增标签弹出框  结束-->
    <!-- 修改标签弹出框 -->
              <el-dialog title="修改标签" class="layoutbox" :visible.sync="editlabel">
                  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                      <el-form-item class="leftlabel" label="标签：" prop="">
                        <el-input class="inputtext" placeholder="长度不超过位" v-model="edit_label.editlabel_name"></el-input>
                      </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="editlabel = false">取 消</el-button>
                    <el-button type="primary" @click="editlabellist()">确 定</el-button>
                  </span>
            </el-dialog>
    <!-- 修改标签弹出框  结束-->

    <!-- 新增口味弹出框 -->
              <el-dialog title="新增口味" class="layoutbox" :visible.sync="addFlavor">
                  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                      <el-form-item class="leftlabel" label="口味：" prop="name">
                        <el-input class="inputtext" placeholder="长度不超过位" v-model="ruleForm.name"></el-input>
                      </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="addFlavor = false">取 消</el-button>
                    <el-button type="primary" @click="addFlavor = false">确 定</el-button>
                  </span>
            </el-dialog>
    <!-- 新增口味弹出框  结束-->


    <!-- 新增规格弹出框 -->
              <el-dialog title="新增规格" class="layoutbox" :visible.sync="addnorms">
                  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                      <el-form-item class="leftlabel" label="规格：" prop="name">
                        <el-input class="inputtext" placeholder="长度不超过位" v-model="ruleForm.name"></el-input>
                      </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="addnorms = false">取 消</el-button>
                    <el-button type="primary" @click="addnorms = false">确 定</el-button>
                  </span>
            </el-dialog>
    <!-- 新增规格弹出框  结束-->


    <!-- 新增重量弹出框 -->
              <el-dialog title="新增重量" class="layoutbox" :visible.sync="addweight">
                  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                      <el-form-item class="leftlabel" label="重量：" prop="name">
                        <el-input class="inputtext" placeholder="长度不超过位" v-model="ruleForm.name"></el-input>
                      </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="addweight = false">取 消</el-button>
                    <el-button type="primary" @click="addweight = false">确 定</el-button>
                  </span>
            </el-dialog>
    <!-- 新增重量弹出框  结束-->

    <!-- 编辑分类弹出框 -->
              <el-dialog title="编辑分组" class="layoutbox" :visible.sync="edittype">
                  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                      <el-form-item class="leftlabel" label="标签：" prop="name">
                        <el-input class="inputtext" placeholder="长度不超过位" v-model="ruleForm.name"></el-input>
                      </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="edittype = false">取 消</el-button>
                    <el-button type="primary" @click="edittype = false">确 定</el-button>
                  </span>
            </el-dialog>
    <!-- 编辑分组弹出框  结束-->
    <!-- 新增分类弹出框 -->

              <el-dialog title="新增分组" class="layoutbox" :visible.sync="addtype">
                  <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                      <el-form-item class="leftlabel" label="标签：" prop="name">
                        <el-input class="inputtext" placeholder="长度不超过位" v-model="ruleForm.name"></el-input>
                      </el-form-item>
                  </el-form>
                  <span slot="footer" class="dialog-footer">
                    <el-button @click="addtype = false">取 消</el-button>
                    <el-button type="primary" @click="addtype = false">确 定</el-button>
                  </span>
            </el-dialog>
    <!-- 新增分类弹出框  结束-->

  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      assist_list:[],
      // isActive:false,
      Company:-1,
      label:-1,
      Flavor:-1,//口味
      norms:-1,//规格
      weight:-1,
      addcompany:false,//单位
      editcompany:false,//单位修改
      addlabel:false,//标签
      editlabel:false,//修改标签
      addFlavor:false,//口味
      addnorms:false,//规格
      addweight:false,//重量
      edittype:false,
      addtype:false,//添加分类
      add_company:{
        addcompany_id:null,
        addcompany_name:'',
      },//添加单位
      edit_company:{
        addcompany_id:null,
        addcompany_name:'',
      },//添加修改
      add_label:{
        addlabel_id:null,
        addlabel_name:'',
      },//添加标签
      edit_label:{
        editlabel_id:null,
        editlabel_name:''
      },//修改标签
      add_Flavor:{
        addFlavor_id:null,
        addFlavor_name:'',
      },//添加口味
      add_norms:{
        addnorms_id:null,
        addnorms_name:'',
      },//添加规格
      add_weight:{
        addweight_id:null,
        addweight_name:'',
      },//添加重量
      ruleForm: {
               name: '',
               region: '',
               date1: '',
               date2: '',
               delivery: false,
               type: [],
               resource: '',
               desc: ''
             },
            rules: {
               name: [
                 { required: true},
               ],
               region: [
                 { required: true, message: '请选择活动区域', trigger: 'change' }
               ],
               date1: [
                 { type: 'date', required: true, message: '请选择日期', trigger: 'change' }
               ],
               date2: [
                 { type: 'date', required: true, message: '请选择时间', trigger: 'change' }
               ],
               type: [
                 { type: 'array', required: true, message: '请至少选择一个活动性质', trigger: 'change' }
               ],
               resource: [
                 { required: true, message: '请选择活动资源', trigger: 'change' }
               ],
               desc: [
                 { required: true, message: '请填写活动形式', trigger: 'blur' }
               ]
      },


    }
  },
  created() {
    this.getData();
  },
  methods:{
    //   鼠标移入
     CompanymouseEnter(index){
       this.Company = index;
       // this.label = index;
     },
   //   鼠标移除
     CompanymouseLeave(){
         this.Company=-1;
         // this.label = -1;
     },
    //   鼠标移入
     labelmouseEnter(index){
       // this.isActive = index;
       this.label = index;
     },
   //   鼠标移除
     labelmouseLeave(){
         // this.isActive=null;
         this.label = -1;
     },
     //   鼠标移入
      FlavormouseEnter(index){
        this.Flavor = index;
        // this.label = index;
      },
    //   鼠标移除
      FlavormouseLeave(){
          this.Flavor=null;
          // this.label = -1;
      },
      //   鼠标移入
       normsmouseEnter(index){
         this.norms = index;
         // this.label = index;
       },
     //   鼠标移除
       normsmouseLeave(){
           this.norms=null;
           // this.label = -1;
       },
       //   鼠标移入
        weightmouseEnter(index){
          this.weight = index;
          // this.label = index;
        },
      //   鼠标移除
        weightmouseLeave(){
            this.weight=null;
            // this.label = -1;
        },
        // 获取数据
        async getData() {
          const result = await axios.get(Rootpath.BASE_URL + 'auxiliary_name');
          this.assist_list = result.data.assist_list;
          this.total = result.data.assist_list.length;
          console.log(this.assist_list);
      },
      getbtninfo(e,index){
        console.log(e.currentTarget.getAttribute('value'));
        console.log(e.currentTarget.getAttribute('name'));
        this.edit_company.addcompany_id=e.currentTarget.getAttribute('value');
        this.edit_company.addcompany_name=e.currentTarget.getAttribute('name');
      },
      getlabelmsg(e,index){
        console.log(e.currentTarget.getAttribute('value'));
        console.log(e.currentTarget.getAttribute('name'));
        this.edit_label.editlabel_id=e.currentTarget.getAttribute('value');
        this.edit_label.editlabel_name=e.currentTarget.getAttribute('name');
      },
      //单位删除
      deletecompany(e,index){
        console.log(e.currentTarget.getAttribute('value'));
        let kid=e.currentTarget.getAttribute('value');
        let that=this;
        this.$confirm('是否确定删除该单位?删除之后使用了该单位的商品需要重新设置单位！', '删除', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
        .then(() => {
          axios.post(Rootpath.BASE_URL + 'units_del', {
                id:kid,
            })
            .then(function (response) {
                console.log(response);
                that.getData();
            })
            .catch(function (error) {
                console.log(error);
            })
        }).catch(() => {
          console.log("quxiao");
        });

      },
     // 添加单位
     async addcompanylist(){
      let that=this;
      console.log(that.add_company.id);
      axios.post(Rootpath.BASE_URL + 'unitsadd', {
            unit:that.add_company.addcompany_name,
        })
        .then(function (response) {
            console.log(response);
            that.addcompany=false;
            that.getData();
        })
        .catch(function (error) {
            console.log(error);
        });
 		},
    //单位修改
    async editcompanylist(){
      let that=this;
      axios.post(Rootpath.BASE_URL + 'units_edit', {
            id:that.edit_company.addcompany_id,
            unit:that.edit_company.addcompany_name,

        })
        .then(function (response) {
            console.log(response);
            that.editcompany=false;
            that.getData();
        })
        .catch(function (error) {
            console.log(error);
        });
    },
    // 添加标签
    async addlabellist(index){
     let that=this;
     axios.post(Rootpath.BASE_URL + 'addtable', {
           product_label_name:that.add_label.addlabel_name,
       })
       .then(function (response) {
           console.log(response);
           that.addlabel=false;
           that.getData();
       })
       .catch(function (error) {
           console.log(error);
       });
   },
   //修改标签
   async editlabellist(){
     let that=this;
     axios.post(Rootpath.BASE_URL + 'updatetable', {
           id:that.edit_label.editlabel_id,
           product_label_name:that.edit_label.editlabel_name,
       })
       .then(function (response) {
           console.log(response);
           that.editlabel=false;
           that.getData();
       })
       .catch(function (error) {
           console.log(error);
       });
   },
   //标签删除
   deletelabel(e,index){
     console.log(e.currentTarget.getAttribute('value'));
     let kid=e.currentTarget.getAttribute('value');
     let that=this;
     this.$confirm('是否确定删除该单位?删除之后使用了该单位的商品需要重新设置单位！', '删除', {
       confirmButtonText: '确定',
       cancelButtonText: '取消',
       type: 'warning'
     })
     .then(() => {
       axios.post(Rootpath.BASE_URL + 'deltable', {
             id:kid,
         })
         .then(function (response) {
             console.log(response);
             that.getData();
         })
         .catch(function (error) {
             console.log(error);
         })
     }).catch(() => {
       console.log("quxiao");
     });

   },

     delect() {
       const confirmText = ['是否确定删除该规格组？',  '删除之后,使用了该规格组的商品需要重新设置规格！ ']
          const newDatas = []
          const h = this.$createElement
          for (const i in confirmText) {
            newDatas.push(h('p', null, confirmText[i]))
          }
          this.$confirm(
            '提示',
            {
              title: '提示',
              message: h('div', null, newDatas),
              showCancelButton: true,
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }
          ).then(() => {

          })
       // this.$confirm('是否确定删除该规格组？\r删除之后,使用了该规格组的商品需要重新设置规格！', '提示', {
       //   confirmButtonText: '确定',
       //   cancelButtonText: '取消',
       //   type: 'warning'
       // }).then(() => {
       //   this.$message({
       //     type: 'success',
       //     message: '删除成功!'
       //   });
       // }).catch(() => {
       //   this.$message({
       //     type: 'info',
       //     message: '已取消删除'
       //   });
       // });
     },
  }
};
</script>
<style scoped>
  .Data-page .headtitle{
    height: 40px;
    background: #ffffff;
    padding-left: 20px;
  }
  /* .title i{
    margin-left: 18px;
  } */
  .Data-page .noactive{
    display: none;
  }
  .Data-page .addbtn{
    background: #436BE5;
    width: 80px;
    height: 32px;
    margin-left:8px;
    color: #ffffff;
    margin-top: 10px
  }
  .Data-page .msbtn{
    position: relative;
    width: 70px;
    height: 30px;
    border: 1px solid #D8D8D8;
    border-radius: 4px;
    color: #D8D8D8;
    margin-right: 5px;
    margin-top: 10px;
  }
  .Data-page .msbtn .mschice{
    position: absolute;;
    top:0;
    left:0;
    width: 70px;
    height: 30px;
    background:rgba(0,0,0,1);
    opacity:0.8;
    border-radius:4px;
    z-index: 1;

  }
  .Data-page .content li{
    list-style-type:none;
    margin-top: 5px;
    position: relative;
  }
  .Data-page .content{
    min-height: 125px;
    background: #ffffff;
    margin-top: 10px;
    padding-left: 20px;
  }
  .Data-page .layoutbox{
    width: 50%;
    margin: 0 auto;
  }
  .Data-page .el-dialog{
    width: 50%;
  }
  .Data-page .inputtext{
    width: 75%
  }
</style>
