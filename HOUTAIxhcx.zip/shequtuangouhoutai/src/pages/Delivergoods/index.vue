<template>
	<div class="select Delivergoods-page">
		<div class="select-table">
			<el-tabs v-model="activeName">
				<!--发货出库-->
				<el-tab-pane label="发货出库" name="first">
					<div class="search">
						<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
							<el-form-item label="联系人" style="margin-top: 20px;"><el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input></el-form-item>
							<el-form-item label="手机号" style="margin-top: 20px;">
								<el-input size="small" v-model="formInline.region" style="width: 120px;"></el-input>
							</el-form-item>
							<el-form-item label="全部路线" style="margin-top: 20px;">
								<el-select v-model="value" placeholder="请选择" size="small" style="width: 130px;">
									<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" :disabled="item.disabled"></el-option>
								</el-select>
							</el-form-item>
							&emsp;
							<el-form-item label="时间" style="margin-top: 20px;"><el-input size="small" v-model="formInline.Name" style="width: 120px;"></el-input></el-form-item>
							&emsp;
							<el-form-item><el-button size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button></el-form-item>
						</el-form>
					</div>
					<br />
					<br />
					<el-button size="small" type="primary">创建出库单</el-button><br />
					<div class="right"><el-button size="medium">一键发货出库</el-button></div>

					<br />
					<el-table ref="multipleTable" :data="info.slice((currentPage-1)*pagesize,currentPage*pagesize)" tooltip-effect="dark" style="width: 100%">
						<el-table-column width="55"></el-table-column>
						<el-table-column label="店铺名称">
							<template slot-scope="scope">
								{{ scope.row.community_name }}
							</template>
						</el-table-column>
						<el-table-column prop="leader_name" align="center" label="联系人"></el-table-column>
						<el-table-column prop="leader_mobile" align="center" label="电话"></el-table-column>
						<el-table-column prop="detail_address" align="center" label="地址"></el-table-column>
						<el-table-column prop="region_id" align="center" label="路线"></el-table-column>
						<el-table-column prop="region_name" align="center" label="区域"></el-table-column>
						<el-table-column prop="shortage_sum" align="center" label="缺货金额"></el-table-column>
						<el-table-column prop="deliver_sum" align="center" label="实际发货金额"></el-table-column>
						<el-table-column prop="state_name" align="center" label="状态"></el-table-column>
						<el-table-column fixed="right" align="center" label="操作">
							<template slot-scope="scope">
								<el-button @click="handleClick(scope.row)" type="text">打印</el-button>
								<el-button type="text" @click="see(scope.row)">查看</el-button>
								<el-button type="text">确认发货</el-button>
							</template>
						</el-table-column>
					</el-table>
					<!--分页-->
					<el-pagination class="pagination"
							background
							@size-change="handleSizeChange"
							@current-change="handleCurrentChange"
							:current-page="currentPage"
							:page-sizes="[5, 10, 20, 50]"
							:page-size="pagesize"
							layout="total, sizes, prev, pager, next, jumper"
							:total="total">
						</el-pagination>
					<br />
				</el-tab-pane>
				<!--缺货管理-->
				<el-tab-pane label="缺货管理" name="second">
					<div class="search">
						<!---->
						<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
							<el-form-item label="商品状态" style="margin-top: 20px;">

								    <el-select v-model="wares" placeholder="请选择" size="small" style="width: 130px;">
								    	<el-option v-for="item in goods" :key="item.wares" :label="item.statess" :value="item.wares" :disabled="item.disabled"></el-option>
								    </el-select>

							</el-form-item>
							<el-form-item label="店铺名称" style="margin-top: 20px;">
								<el-input size="small" v-model="formInline.region" style="width: 120px;"></el-input>
							</el-form-item>
							<el-form-item label="商品名称" style="margin-top: 20px;">

								    <el-select v-model="names" placeholder="请选择" size="small" style="width: 130px;">
								    	<el-option v-for="item in name" :key="item.names" :label="item.label" :value="item.names" :disabled="item.disabled"></el-option>
								    </el-select>

							</el-form-item>
							<el-form-item label="商品编码" style="margin-top: 20px;">
								<el-input size="small" v-model="formInline.states" style="width: 120px;"></el-input>
							</el-form-item>
							&emsp;

							<el-form-item><el-button size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button></el-form-item>
						</el-form>
						<!---->
					</div>
					<br />
					<br />
					<br />
					<br />
					<div class="right">
						<el-button size="medium">生成补货采购单</el-button>
						<el-button size="medium">缺货退款</el-button>
						<el-button size="medium">缺货补发</el-button>
						<el-button size="medium">一键发货出库</el-button>
					</div>

					<br />
					<el-table ref="multipleTable" :data="shortageinfo.slice((shortagecurrentPage-1)*shortagepagesize,shortagecurrentPage*shortagepagesize)" tooltip-effect="dark" style="width: 100%">
						<el-table-column type="selection" width="55"></el-table-column>

						<el-table-column align="center" prop="product_name" label="商品名称"></el-table-column>
						<el-table-column align="center" prop="product_tagging" label="商品状态"></el-table-column>
						<el-table-column align="center" prop="community_name" label="店铺名称"></el-table-column>
						<el-table-column align="center" prop="leader_name" label="会员名称"></el-table-column>
						<el-table-column align="center" prop="leader_login" label="会员电话"></el-table-column>
						<el-table-column align="center" prop="delivery_number" label="关联配送单"></el-table-column>
						<el-table-column align="center" prop="bill_state" label="单据发货状态"></el-table-column>
						<el-table-column align="center" prop="order_number" label="关联订单"></el-table-column>
						<el-table-column align="center" prop="stock_quantity" label="缺货数量"></el-table-column>

						<el-table-column align="center" label="操作">
							<template slot-scope="scope">

								<el-button type="text" size="small">退款</el-button>
								<el-button type="text" size="small">补发</el-button>
							</template>
						</el-table-column>
					</el-table>
					<br />
					<!--分页-->
					 <el-pagination class="block"
					     background
					     @size-change="shortageSizeChange"
					     @current-change="shortageCurrentChange"
					     :current-page="shortagecurrentPage"
					     :page-sizes="[5, 10, 20, 50]"
					     :page-size="shortagepagesize"
					     layout="total, sizes, prev, pager, next, jumper"
					     :total="shortagetotal">
					   </el-pagination>
				</el-tab-pane>
			</el-tabs>
		</div>
		<!--查看-->
		<el-dialog title="查看信息" :visible.sync="dialogTableVisible" width="60%">
			<el-table :data="seeinfo">
				<el-table-column property="product_name" align="center" label="商品名称" width="120"></el-table-column>
				<el-table-column property="product_desc" align="center" label="描述" width="120"></el-table-column>
				<el-table-column property="reserve_order_count" align="center" label="预定量" width="120"></el-table-column>
				<el-table-column property="stock_quantity" align="center" label="缺货量" width="120"></el-table-column>
				<el-table-column property="order_count" align="center" label="实际量" width="120"></el-table-column>
				<el-table-column property="order_sum" align="center" label="发货金额" width="120"></el-table-column>
				<el-table-column property="state_name" align="center" label="状态"></el-table-column>
			</el-table><br>
			<el-pagination class="block"
			    background
			    @size-change="seehandleSizeChange"
			    @current-change="seehandleCurrentChange"
			    :current-page="seecurrentPage"
			    :page-sizes="[5, 10, 20, 50]"
			    :page-size="seepagesize"
			    layout="total, sizes, prev, pager, next, jumper"
			    :total="seetotal">
			  </el-pagination>
			  <el-button size="small" type="primary" class="block">关闭</el-button>
		</el-dialog>

	</div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			activeName: 'first',
			total: 0,
			currentPage: 1,
			pagesize: 5,
			seetotal: 0,
			seecurrentPage: 1,
			seepagesize: 5,
			shortagetotal: 0,
			shortagecurrentPage: 1,
			shortagepagesize: 5,
			info:[],//列表
			seeinfo:[],//详情列表
		shortageinfo: [],
			formInline: {
				user: '',
				region: '',
				Name: '',
				times: '',
				Mobilephone: '',
				Names: ''
			},

			options: [//路线
				{
					value: '选项1',
					label: '路线一'
				},
				{
					value: '选项2',
					label: '路线二'
				},
				{
					value: '选项3',
					label: '路线三'
				},
				{
					value: '选项4',
					label: '路线四'
				},
				{
					value: '选项5',
					label: '路线五'
				}
			],
			value: '',
 goods: [{//商品状态
          wares: '选项1',
          statess: '待发货'
        }, {
          wares: '选项2',
          statess: '已发货'
        }, {
          wares: '选项3',
          statess: '发货中'
        }, {
          wares: '选项4',
          statess: '缺货'
        }, {
          wares: '选项5',
          statess: '退款'
        }],
        wares: '',
		name: [{//商品名称
		         names: '选项1',
		         label: '黄金糕'
		       }, {
		         names: '选项2',
		         label: '双皮奶'
		       }, {
		         names: '选项3',
		         label: '蚵仔煎'
		       }, {
		         names: '选项4',
		         label: '龙须面'
		       }, {
		         names: '选项5',
		         label: '北京烤鸭'
		       }],
		       names: '',
			gridData: [
				{
					date: '水果',
					name: '额？',
					Reserve: '1.00斤',
					lack: '12.0斤',
					Actual: '10.0斤',
					gold: '￥12.00',
					address: '已发货'
				},
				{
					date: '蔬菜',
					name: '',
					Reserve: '1.00斤',
					lack: '12.0斤',
					Actual: '10.0斤',
					gold: '￥12.00',
					address: '已发货'
				},
				{
					date: '牛奶',
					name: '',
					Reserve: '1.00斤',
					lack: '12.0斤',
					Actual: '10.0斤',
					gold: '￥12.00',
					address: '已发货'
				},
				{
					date: '茶叶',
					name: '',
					Reserve: '1.00斤',
					lack: '12.0斤',
					Actual: '10.0斤',
					gold: '￥12.00',
					address: '已发货'
				}
			],
			dialogTableVisible: false
		};
	},
	created() {
			this.getData();
			// this.integrlist();
	},
	methods: {
		onSubmit() {
			console.log('submit!');
		},
		// 获取数据
		async getData() {
				const result = await axios.get(Rootpath.BASE_URL + 'deliverGoodsList');
				console.log(result);
				this.info=result.data.info;
				this.total = result.data.info.length;
				const json=await axios.get(Rootpath.BASE_URL + 'lackStockPage');
				console.log(json);
				this.shortageinfo=json.data.info;
				this.shortagetotal=json.data.info.length;
		},
	  //分页
	  handleSizeChange(size) {
	    this.pagesize = size
	  },
	  handleCurrentChange(currentPage) {
	    this.currentPage = currentPage
	  },
		seehandleSizeChange(size) {
	    this.seepagesize = size
	  },
	  seehandleCurrentChange(currentPage) {
	    this.seecurrentPage = currentPage
	  },
		shortageSizeChange(size) {
	    this.shortagepagesize = size
	  },
	  shortageCurrentChange(currentPage) {
	    this.shortagecurrentPage = currentPage
	  },

		//查看
		async see(row){
			this.dialogTableVisible=true;
			const result = await axios.get(Rootpath.BASE_URL + 'getDeliverGoodsInfo?did='+row.deliverGoods_id);
			this.seeinfo=result.data.info;
			this.seetotal = result.data.info.length;
		}
	}
};
</script>

<style scoped>
	.block{
		text-align: right;

	}
	.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
	.right {
		text-align: right;
		margin-top: -30px;
	}
</style>
