<template>
  <div class="Changepassword-page">
      <el-tabs v-model="activeName">
  <!-- 区域 -->
      <el-tab-pane label="修改密码" name="first">
        <div class="">
          <el-form :model="ruleForm" label-width="100px" class="demo-ruleForm">
            <el-form-item label="用户名：" prop="username" class="leftlabeltext">
              <el-input disabled v-model="ruleForm.username"></el-input>
            </el-form-item>
            <el-form-item label="原始密码：" prop="Originalpassword" class="leftlabeltext">
              <el-input v-model="ruleForm.Originalpassword"></el-input>
            </el-form-item>
            <el-form-item label="新密码：" prop="Newpassword" class="leftlabeltext">
              <el-input v-model="ruleForm.Newpassword"></el-input>
            </el-form-item>
            <el-form-item label="确认密码：" prop="Confirmpassword" class="leftlabeltext">
              <el-input v-model="ruleForm.Confirmpassword"></el-input>
            </el-form-item>
            <el-form-item class="leftlabeltext">
              <el-button type="primary" @click="save()" size="small">提交修改</el-button>
            </el-form-item>
          </el-form>
        </div>
      </el-tab-pane>


    </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      activeName: 'first',
      Distributionroute:[],
      addRegion:false,
      // cash_list:{
      //   id:'',
      //   user_name:''
      // },
      ruleForm: {
          username: '',
          Originalpassword: '',
          Newpassword: '',
          Confirmpassword: ''
        },


    }
  },
  created() {
    this.getData();
  },
  methods:{
      // 获取数据
      async getData() {
        const result = await axios.get(Rootpath.BASE_URL + 'edit_info');
        this.ruleForm.username=result.data.user_name;
        console.log(result);
      },
      save() {
        let that = this;
        axios.post(Rootpath.BASE_URL + 'leaveladd', {
                user_name: that.ruleForm.username,//用户名
                pwd: that.ruleForm.Originalpassword,//原密码
                password: that.ruleForm.Newpassword,//新密码
                repassword: that.ruleForm.Confirmpassword,//确认密码
            })
            .then(function (response) {
                console.log(response);
                that.$confirm('保存成功', '提示', {
          				confirmButtonText: '确定',
          				cancelButtonText: '取消',
          				type: 'success'
          			})
          				.then(() => {

          				})
          				.catch(() => {

          				});
            })
            .catch(function (error) {
                console.log(error);
            });

  		},
  },
};
</script>
<style scoped>
.Changepassword-page{
  background: #ffffff;
  width: 95%;
  margin: 0 auto;
}
.leftlabeltext{
  margin-left: 50px;
}
.Changepassword-page .el-tabs__nav{
  margin-left: 20px;
}
.Changepassword-page .title_text{
  margin-left: 5%;
  margin-bottom: 20px;
}
.Changepassword-page .title_text i{
  margin-left: 20px
}
.Changepassword-page .title_text span{
  background:rgba(168,183,227,1);
  border-radius:0px 0px 3px 3px;
  padding-right: 10px;

}
.Changepassword-page .el-input{
  width: 300px;
}
.Changepassword-page .el-form-item__label{
  width: 100px !important;
}
</style>
