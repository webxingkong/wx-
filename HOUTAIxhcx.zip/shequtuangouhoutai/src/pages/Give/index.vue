<template>
  <div class="Give-page">
    <el-tabs v-model="activeName" @tab-click="handleClick">
    <el-tab-pane label="配送方式" name="first">
      <div class="">
        <el-form ref="form" :model="form" label-width="180px">
          <div class="title_text">
            <span><i class="el-icon-info"></i>温馨提示：您可以根据实际情况设定配送方式和配送费，若选择多种配送方式，会员可以在下单时自行选择。会员选择送货上门时，须填写收获地址</span>
          </div>
          <el-form-item label="配送方式：">
            <!-- <el-checkbox-group v-model="form.type">
              <el-checkbox label="自提" name="type"></el-checkbox>
              <el-checkbox label="送货上门" name="type"></el-checkbox>
            </el-checkbox-group> -->
            <el-radio v-model="radio" label="1">自提</el-radio>
            <el-radio v-model="radio" label="2">送货上门</el-radio>
          </el-form-item>
          <el-form-item label="配送费：">
            <el-input v-model="form.transport_price"></el-input>
            <el-tooltip class="item" visible-arrow="false" content="若会员一次性提交多笔不同到货日期的订单，将按照不同到货日期，收取多笔配送费" placement="right">
              <i class="el-icon-question"></i>
            </el-tooltip>
          </el-form-item>
          <el-form-item label="满额免配送费：">
            <el-input v-model="form.free_transport_price"></el-input>
            <el-tooltip class="item" visible-arrow="false" content="以订单按照到货日期拆分前的折后金额为准" placement="right">
              <i class="el-icon-question"></i>
            </el-tooltip>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="save">保存</el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-tab-pane>

  </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      activeName: 'first',
      radio: '1',
      // formInline: {
			// 	user: '',
			// 	region: '',
			// 	Name: '',
			// 	times: '',
			// 	Mobilephone: '',
			// 	Names: '',
      //
			// },
      form: {
        id: '',
        transport_price: '',
        free_transport_price:'',
        }

    }
  },
  created() {
			this.getData();
	},
  methods:{
    handleClick(tab, event) {
        console.log(tab, event);
      },
      onSubmit() {
        console.log('submit!');
      },
      async getData() {
        const result = await axios.get(Rootpath.BASE_URL + 'port_type');
        console.log(result);
        this.form = result.data;
      },
      // 保存弹窗
      save() {
        let that=this;
        axios({
	        url: Rootpath.BASE_URL + 'port_edit',
	        method: 'post',
	        data: {
            id: that.form.id,
            transport_type: that.radio,
            transport_price: that.form.transport_price,
            free_transport_price: that.form.free_transport_price
	        },
	        headers: {
	            'Content-Type': 'application/x-www-form-urlencoded'
	        }
	    })
	    .then(respanse => {
	        console.log(respanse);
	    })
			.catch(function (error) {
	            console.log(error);
	        });
  		},
  },
};

</script>
<style scoped>
.Give-page{
  background: #ffffff;
  width: 95%;
  margin: 0 auto;
}
.Give-page .el-tabs__nav{
  margin-left: 20px;
}
.Give-page .el-tabs__header{
  background: #ffffff;
  margin-top: 50px;
}
.Give-page .hearsearch{
    background: #F5F5F5;
    width: 96%;
    margin: 0 auto;
  }
  .Give-page .hearbtn{
    line-height: 60px;
  }
  .Give-page .addbtn{
    height: 60px;
    width: 96%;
    margin: 0 auto;
  }
  .Give-page .title_text{
    margin-left: 5%;
    margin-bottom: 20px;
  }
  .Give-page .title_text i{
    margin-left: 20px
  }
  .Give-page .title_text span{
    background:rgba(168,183,227,1);
    border-radius:0px 0px 3px 3px;
    padding-right: 10px;

  }
  .Give-page .el-input{
    width: 300px;
  }
  /* .Give-page .el-message-box__message p{
    top: 0;
  } */
  .el-message-box__message p{
    top: 0;
  }
  .el-tooltip__popper.is-dark {
    background:rgba(168,183,227,1);
    color: #333333;
}
.el-tooltip__popper {
    position: absolute;
    border-radius: 4px;
    padding: 10px;
    z-index: 2000;
    font-size: 12px;
    line-height: 1.2;
    word-wrap: break-word;
    width:370px;
    height:25px;
    border:1px solid rgba(67,107,229,1);
    box-shadow:0px 2px 2px 0px rgba(0, 0, 0, 0.16);
}
</style>
