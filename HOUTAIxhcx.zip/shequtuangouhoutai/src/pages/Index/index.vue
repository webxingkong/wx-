<template>
  <div class="index-page">
    <div id="pieReport">
      <!--布局模块-->
      <el-row :gutter="20">
        <el-col :span="6">
          <el-row class="Border flex_m">
            <el-col :span="8">
              <div class="grid-content flex_m"><img src="../../assets/Order.png" width="100%" height="100%" /></div>
            </el-col>
            <el-col :span="15">
              <div class="grid-content">

                <h1>0</h1>
                下单笔数
              </div>
            </el-col>
          </el-row>
        </el-col>
        <el-col :span="6">
          <el-row class="Border flex_m">
            <el-col :span="8">
              <div class="grid-content flex_m"><img src="../../assets/pen.png" width="100%" height="100%" /></div>
            </el-col>
            <el-col :span="15">
              <div class="grid-content">

                <h1>0</h1>
                退货笔数
              </div>
            </el-col>
          </el-row>
        </el-col>
        <el-col :span="6">
          <el-row class="Border flex_m">
            <el-col :span="8">
              <div class="grid-content flex_m"><img src="../../assets/single.png" width="100%" height="100%" /></div>
            </el-col>&emsp;
            <el-col :span="15">
              <div class="grid-content">

                <h1>0.00</h1>
                下单金额
              </div>
            </el-col>
          </el-row>
        </el-col>
        <el-col :span="6">
          <el-row class="Border flex_m">
            <el-col :span="8">
              <div class="grid-content flex_m"><img src="../../assets/retreat.png" width="100%" height="100%" /></div>
            </el-col>
            <el-col :span="15">
              <div class="grid-content">

                <h1>0.00</h1>
                退货金额
              </div>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <div class="grid-content bg-purple-light chart_height" style="margin-right:10px">
            <div class="charttitle flex_fcs">
              <div class="charttitle_left" style="font-weight:bold;font-size:14px">
                待处理事务
              </div>
            </div>
            <div class="charttitle flex_fcs">
              <div class="charttitle_left" style="font-weight:bold;font-size:14px">
                订单
              </div>
              <div class="charttitle_right">
                待发货<span>0</span>个
              </div>
            </div>
            <div class="charttitle flex_fcs">
              <div class="charttitle_left" style="font-weight:bold;font-size:14px">
                采购
              </div>
              <div class="charttitle_right">
                待处理<span>3</span>个
              </div>
            </div>
            <div class="charttitle flex_lr_m">
              <div class="charttitle_left" style="font-weight:bold;font-size:14px">
                售后
              </div>
              <div class="charttitle_right">
                取消订单待审核<span>3</span>单
              </div>
              <div class="charttitle_right">
                售后结算<span>3</span>单
              </div>
              <div class="charttitle_right">
                待处理<span>3</span>个
              </div>
            </div>
            <div class="charttitle flex_lr_m">
              <div class="charttitle_left" style="font-weight:bold;font-size:14px">
                团长
              </div>
              <div class="charttitle_right" style="visibility:hidden">
                取消订单待审核<span>3</span>单
              </div>
              <div class="charttitle_right">
                未审核<span>3</span>个
              </div>
              <div class="charttitle_right flex_lr">

                <div class="charttitle_right">
                  使用情况<span>10</span>/<span>99</span>
                </div>
              </div>
            </div>
          </div>
        </el-col>
        <el-col :span="12">

          <div class="grid-content bg-purple chart_height" style="margin-left:10px;background:#FFFFFF">
            <div class="charttitle flex_fcs">
              <div class="charttitle_left" style="font-weight:bold;font-size:14px">
                营业数据趋势图
              </div>
              <div class="charttitle_right">
                <el-radio v-model="radio" label="1">最近7天</el-radio>
                <el-radio v-model="radio" label="2">最近15天</el-radio>
                <el-radio v-model="radio" label="3">最近30天</el-radio>
              </div>
            </div>
            <div id="main" style="width: 96%;height: 85%;margin:0 auto"></div>
          </div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">

          <div class="grid-content bg-purple chart_height" style="margin-right:10px;background:#FFFFFF">
            <div class="charttitle flex_fcs">
              <div class="charttitle_left" style="font-weight:bold;font-size:14px">
                会员增长情况
              </div>
              <div class="charttitle_right">
                <el-radio v-model="radio" label="1">最近7天</el-radio>
                <el-radio v-model="radio" label="2">最近15天</el-radio>
              </div>
            </div>
            <div id="membership_growth" style="width: 96%;height: 85%;margin:0 auto"></div>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="grid-content bg-purple-light chart_height" style="margin-left:10px">
            <div class="charttitle flex_fcs">
              <div class="charttitle_left" style="font-weight:bold;font-size:14px">
                会员增长情况
              </div>
              <div class="charttitle_right">
                <el-radio v-model="radio" label="1">最近7天</el-radio>
                <el-radio v-model="radio" label="2">最近15天</el-radio>
              </div>
            </div>
            <div id="General_platform" style="width: 96%;height: 85%;margin:0 auto"></div>
          </div>

        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <div class="grid-content bg-purple-light chart_height" style="margin-right:10px">
            <div class="charttitle flex_fcs">
              <div class="charttitle_left" style="font-weight:bold;font-size:14px">
                团长销售排行（本月）
              </div>
            </div>
            <div id="Salesranking_thismon" style="width: 96%;height: 85%;margin:0 auto"></div>
          </div>
        </el-col>
        <el-col :span="12">

          <div class="grid-content bg-purple chart_height" style="margin-left:10px;background:#FFFFFF">
            <div class="charttitle flex_fcs">
              <div class="charttitle_left" style="font-weight:bold;font-size:14px">
                团长销售排行（上月）
              </div>
            </div>
            <div id="Salesranking" style="width: 96%;height: 85%;margin:0 auto"></div>
          </div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <div class="grid-content bg-purple-light chart_height" style="margin-right:10px">
            <div class="charttitle flex_fcs">
              <div class="charttitle_left" style="font-weight:bold;font-size:14px">
                快捷入口
              </div>
            </div>
            <el-row :gutter="20">
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
              <el-col :span="4" class="flex_c_m">
                <div class="grid-content bg-purple">
                  <img src="../../assets/single.png" alt="" width="32px" height="32px">
                  <div class="">
                    商品
                  </div>
                </div>
              </el-col>
            </el-row>
          </div>
        </el-col>
      </el-row>


    </div>
  </div>
</template>
<script>
import axios from "../../axios.js"
import echarts from "../../../node_modules/echarts/lib/echarts.js"
export default {
        name: '',
        data () {
            return {
                charts: '',
                radio: '1',
                membership_growth_chart:'',
                General_platform_chart:'',
                Sales_ranking_chart:'',
                Salesranking_thismon_chart:'',
            }
        },
        methods:{
            drawPie(id){
               this.charts = echarts.init(document.getElementById(id))
               this.charts.setOption({
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    data:['邮件营销','联盟广告']
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                toolbox: {
                    feature: {
                        saveAsImage: {}
                    }
                },
                xAxis: {
                    type: 'category',
                    boundaryGap: false,
                    data: ['周一','周二','周三','周四','周五','周六','周日']
                },
                yAxis: {
                    type: 'value'
                },
                series: [
                    {
                        name:'邮件营销',
                        type:'line',
                        stack: '总量',
                        data:[12, 13, 10, 34, 40, 20, 50]
                    },
                    {
                        name:'联盟广告',
                        type:'line',
                        stack: '总量',
                        data:[20, 18, 19, 34, 29, 33, 30]
                    }
                ]
              })
            },
            // 会员增长情况（分公司）
            membership_growth(id){
              this.membership_growth_chart = echarts.init(document.getElementById(id))
              this.membership_growth_chart.setOption({
                xAxis: {
                type: 'category',
                data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
                },
                yAxis: {
                  type: 'value'
                },
                series: [{
                  data: [12, 20, 10, 8, 7, 10, 10],
                  type: 'bar'
                }]
              })
            },
            // 会员增长情况（总公司）
            General_platform(id){
              this.General_platform_chart = echarts.init(document.getElementById(id))
              this.General_platform_chart.setOption({
                xAxis: {
                type: 'category',
                data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
                },
                yAxis: {
                  type: 'value'
                },
                series: [{
                  data: [120, 200, 150, 80, 70, 110, 130],
                  type: 'bar'
                }]
              })
            },
            // 团长销售排行（上月）
            Sales_ranking(id){
              this.Sales_ranking_chart = echarts.init(document.getElementById(id))
              this.Sales_ranking_chart.setOption({
                title : {
                  text: '销售金额：88888',
                  x:'center'
                },
                tooltip : {
                  trigger: 'item',
                  formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                  orient: 'vertical',
                  left: 'left',
                  data: ['直接访问','邮件营销','联盟广告','视频广告','搜索引擎']
                },
                series : [
                  {
                    name: '访问来源',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                      {value:335, name:'直接访问'},
                      {value:310, name:'邮件营销'},
                      {value:234, name:'联盟广告'},
                      {value:135, name:'视频广告'},
                      {value:1548, name:'搜索引擎'}
                    ],
                    itemStyle: {
                      emphasis: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                      }
                    }
                  }
                ]
              })
            },
            Salesranking_thismon(id){
              this.Salesranking_thismon_chart = echarts.init(document.getElementById(id))
              this.Salesranking_thismon_chart.setOption({
                title : {
                  text: '销售金额：88888',
                  x:'center'
                },
                tooltip : {
                  trigger: 'item',
                  formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                  orient: 'vertical',
                  left: 'left',
                  data: ['直接访问','邮件营销','联盟广告','视频广告','搜索引擎']
                },
                series : [
                  {
                    name: '访问来源',
                    type: 'pie',
                    radius : '55%',
                    center: ['50%', '60%'],
                    data:[
                      {value:335, name:'直接访问'},
                      {value:310, name:'邮件营销'},
                      {value:234, name:'联盟广告'},
                      {value:135, name:'视频广告'},
                      {value:1548, name:'搜索引擎'}
                    ],
                    itemStyle: {
                      emphasis: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                      }
                    }
                  }
                ]
              })
            }

        },
        created() {
          const listUrl = 'http://yhxapi.me/mock/24/admin/path/echarts'
          axios.get(listUrl).then((response) => {
            console.log(response);
            // this.Distributionroute = response.data.Distributionroute
            // this.total = response.data.Distributionroute.length
          })
        },
      //调用
        mounted(){
          const that = this
          window.onresize = () => {
            return (() => {
              that.charts.resize();
              that.membership_growth_chart.resize();
              that.General_platform_chart.resize();
              that.Sales_ranking_chart.resize();
            })()
          }
            that.$nextTick(function() {
                that.drawPie('main');
                that.membership_growth('membership_growth');
                that.General_platform('General_platform');
                that.Sales_ranking('Salesranking');
                that.Salesranking_thismon('Salesranking_thismon');
            })
        }
    }

</script>
<style media="screen">
.Give-page{
  background: #ffffff;
  width: 95%;
  margin: 0 auto;
}
li{
  list-style: none;
}
#pieReport{
  width: 96%;
  margin: 0 auto;
}
.charttitle{
  height: 15%;
  border-bottom: 1px solid rgba(240,240,240,1);
  width: 96%;
  margin: 0 auto;
}
.grid-content{
    height: 60px;
}
.chart_height{
  height: 300px;
  background: #ffffff;
}
.el-row{
  margin-top: 20px
}
.Border {
  background: #ffffff;
}
/* .Border{
  box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
} */
h1{
  font-size: 20px;
}
.block {
  text-align: right;
}
.Give-page .el-tabs__nav{
  margin-left: 20px;
}
.Give-page .el-tabs__header{
  background: #ffffff;
  margin-top: 50px;
}
.Give-page .hearsearch{
    background: #F5F5F5;
    width: 96%;
    margin: 0 auto;
  }
  .Give-page .hearbtn{
    line-height: 60px;
  }
  .Give-page .addbtn{
    height: 60px;
    width: 96%;
    margin: 0 auto;
  }
  .Give-page .title_text{
    margin-left: 5%;
    margin-bottom: 20px;
  }
  .Give-page .title_text i{
    margin-left: 20px
  }
  .Give-page .title_text span{
    background:rgba(168,183,227,1);
    border-radius:0px 0px 3px 3px;
    padding-right: 10px;

  }
  .Give-page .el-input{
    width: 300px;
  }
  /* .Give-page .el-message-box__message p{
    top: 0;
  } */
  .el-message-box__message p{
    top: 0;
  }
  .el-tooltip__popper.is-dark {
    background:rgba(168,183,227,1);
    color: #333333;
}
.el-tooltip__popper {
    position: absolute;
    border-radius: 4px;
    padding: 10px;
    z-index: 2000;
    font-size: 12px;
    line-height: 1.2;
    word-wrap: break-word;
    width:370px;
    height:32px;
    border:1px solid rgba(67,107,229,1);
    box-shadow:0px 2px 2px 0px rgba(0, 0, 0, 0.16);
}
</style>
