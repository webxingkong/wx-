<template>
<div style="margin: 19px;">
	<div style="background:#C8C9CC; margin: 0px 16px;border-radius:3px;">订单详情</div>
	<div style="display: flex;justify-content:space-between; margin: 0px 16px; color:#333333;">
		<div>
			<div>
				<div class="margin14">订单号:{{orderInfo.order_number}}</div>
				<div class="margin14">订单状态:{{orderInfo.order_state}}</div>
				<div class="margin14">下单时间:{{orderInfo.order_time}}</div>
				<div class="margin14">备注:{{orderInfo.order_remarks}}</div>
			</div>
		</div>
		<div style="margin-right:30%">
			<div>
				<div class="margin14">支付方式:{{orderInfo.pay_mode}}</div>
				<div class="margin14">发货日期:{{orderInfo.delivery_date}}</div>
				<div class="margin14">支付流水号:{{orderInfo.pay_number}}</div>
				<div class="margin14">退款流水号:{{orderInfo.refund}}</div>
			</div>
		</div>
	</div>
	<div style="background:#C8C9CC; margin:30px 0px 0px 16px;border-radius:3px;">收货信息</div>
	<div style="display: flex;justify-content:space-between; margin: 0px 16px; color:#333333;">
		<div>
			<div>
				<div class="margin14">会员名称:{{pickInfo.wx_name}}</div>
				<div class="margin14">收货地址:{{pickInfo.user_address}}</div>
				<div class="margin14">收货人:{{pickInfo.user_name}}</div>
				<div class="margin14">团长手机:{{pickInfo.user_mobile}}</div>
				<div class="margin14">取货码:{{pickInfo.pick}}</div>
				<div class="margin14">取货时间:{{pickInfo.get_goods_time}}</div>
			</div>
		</div>
		<div style="margin-right:30%">
			<div>
				<div class="margin14">会员手机号:{{pickInfo.leader_mobile}}</div>
				<div class="margin14">团长名称:{{pickInfo.leader_name}}</div>
				<div class="margin14">团长店铺:{{pickInfo.community_name}}</div>
				<div class="margin14">提货地址:{{pickInfo.community_address}}</div>
				<div class="margin14">取货方式:{{pickInfo.transport_type_name}}</div>
				<div class="margin14">配送方式:{{pickInfo.transport_type}}</div>
			</div>
		</div>
	</div>
  <div style="margin:20px 0px 20px;">
	  <el-table
		:data="info.orderGoodsInfo"
	  :header-cell-style="{background:'#eef1f6',color:'#606266'}"
	        style="width: 100%">
	        <el-table-column
			align="center"
	          label="商品图片"
						prop="img_url">
	        </el-table-column>
	        <el-table-column
				align="center"
	          label="商品名称"
						prop="goods_name">
	        </el-table-column>
	        <el-table-column
				align="center"
	          prop="address"
	          label="退款状态">
	        </el-table-column>
			<el-table-column
				align="center"
			  prop="order_unit"
			  label="下单单位">
			</el-table-column>
			<el-table-column
				align="center"
			  prop="goods_price"
			  label="下单单价">
			</el-table-column>
			<el-table-column
				align="center"
			  prop="goods_sum"
			  label="下单金额">
			</el-table-column>
	      </el-table>
				<div class="underlist" style="background:#ffffff;height:60px">
					<el-row :gutter="20" class="">
		  			<el-col :span="4"><div class="grid-content bg-purple flex_c_m">订单总价：<span style="color:red">￥{{info.order_sum}}</span></div></el-col>
		  			<el-col :span="4"><div class="grid-content bg-purple flex_c_m">优惠金额：<span style="color:red">￥{{info.discount}}</span></div></el-col>
		  			<el-col :span="4"><div class="grid-content bg-purple flex_c_m">配送费：<span style="color:red">￥{{info.delivery_fee}}</span></div></el-col>
						<el-col :span="4"><div class="grid-content bg-purple flex_c_m">实付金额：<span style="color:red">￥{{info.pay_money}}</span></div></el-col>
		  			<el-col :span="4"><div class="grid-content bg-purple flex_c_m">退款金额：<span style="color:red">￥{{info.refund_amount}}</span></div></el-col>
					</el-row>
				</div>
  </div>
   <el-table
	 		:data="info.record"
        style="width: 100%">
				<el-table-column
					align="center"
					label="操作人"
					prop="operator">
				</el-table-column>
				<el-table-column
			align="center"
					prop="operator_time"
					label="时间">
				</el-table-column>
		<el-table-column
			align="center"
			prop="operator_type"
			label="类型">
		</el-table-column>
		<el-table-column
			align="center"
			prop="operator_Record"
			label="日志">
		</el-table-column>
      </el-table>

</div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
   data() {
        return {
          info: [],
					orderInfo:[],
					pickInfo:[],
        };
      },
			created() {
			this.getData();
			},
      methods: {
				// 获取数据
				async getData (){

					 // this.total = result.info.length
					 var order_number = this.$route.query.on;
           const result = await axios.get(Rootpath.BASE_URL + 'orderInfo?orderNumber=' + order_number);
           this.info = result.data.info;
					 this.orderInfo=result.data.info.orderInfo;
					 this.pickInfo=result.data.info.pickInfo;
				},
      },


};
</script>
<style scoped>
	.margin14{
		font-size:15px;
		margin-top:20px;
	}
	.underlist .el-row{
		margin-top: 0px
	}
</style>
