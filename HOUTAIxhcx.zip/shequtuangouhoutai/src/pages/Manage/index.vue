<template>
    <div class="Manage-page" style="margin: 20px;">
        <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="所有订单" name="0">
                <div>
                    <el-form :inline="true" :model="formInline">
                        <el-form-item label="订单号" style="margin-top: 20px;">
                            <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                        </el-form-item>
                        <el-form-item label="商品名称" style="margin-top: 20px;">
                            <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                        </el-form-item>
                        <el-form-item label="收货人" style="margin-top: 20px;">
                            <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                        </el-form-item>&emsp;
                        <el-form-item label="手机号码" style="margin-top: 20px;">
                            <el-input size="small" v-model="formInline.user" style="width: 120px;"></el-input>
                        </el-form-item>&emsp;
                        <el-form-item style="margin-top: 20px;">
                            <el-button size="small" type="primary" @click="onSubmit">搜索</el-button>
                        </el-form-item>
                    </el-form>
                </div>
                <div class="right">
                    <el-button size="medium" onClick="handleHistoryPush">导出查询结果</el-button>
                </div>
                <div>
                    <el-table :data="orderList.slice((currentPage-1)*pagesize,currentPage*pagesize)" style="width:100%">
                        <el-table-column align="left" label="商品" width="300">
                            <template slot-scope="scope">
                                <div class="flex" style="flex-direction:column;line-height:15px;">
                                    <div class="flex " style="flex-direction:column;">
                                        <div class="flex">
                                            <p class="font_h"><i class="iconfont pr5">&#xe63a;</i>订单号:
                                                <p style="color:#6381E7 ;">{{scope.row.order_number}}</p>
                                        </div>
                                        <div class="flex pb20 boxsize">
                                            <div class="pl20">
                                                <div>{{scope.row.create_time}}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </template>
                        </el-table-column>
                        <el-table-column align="center" prop="user_name" label="会员名称">

                        </el-table-column>
                        <el-table-column align="center" prop="order_sum" label="订单总额">
                        </el-table-column>
                        <el-table-column align="center" prop="delivery_date" label="发货日期">
                        </el-table-column>
                        <el-table-column align="center" prop="community_name" label="社区店">
                        </el-table-column>
                        <el-table-column align="center" prop="order_state" label="订单状态">
                        </el-table-column>
                        <el-table-column align="center" prop="order_remarks" label="备注">
                        </el-table-column>
                        <el-table-column align="center" label="操作">
                            <template slot-scope="scope">
                                <el-button @click="details(scope.row)" type="text" size="small">详情</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                    <!--分页-->
                    <!--分页-->
                    <el-pagination class="pagination"
                        background
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page="currentPage"
                        :page-sizes="[5, 10, 20, 50]"
                        :page-size="pagesize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="total">
                      </el-pagination>
                    </el-pagination>
                </div>

            </el-tab-pane>
            <el-tab-pane label="待付款" name="5">配置管理</el-tab-pane>
            <el-tab-pane label="备货中" name="1">角色管理</el-tab-pane>
            <el-tab-pane label="交易完成" name="3">定时任务补偿</el-tab-pane>
            <el-tab-pane label="已关闭" name="4">已关闭</el-tab-pane>
        </el-tabs>
    </div>
</template>
<script>
    import axios from '../../axios.js';
    import https from "../../../api/https.vue"
    import Rootpath from "../../../api/index.js"
    import qs from '../../../node_modules/qs'
    export
    default {
        components: {},
        data() {
            return {
                activeName: '0',
                total: 0,
                currentPage: 1,
                pagesize: 5,
                data: '这是模拟参数传递',
                formInline: {
                    user: '',
                    region: ''
                },
                //后台数据
                orderList: []
            };
        },
        created() {
            this.getData();
            this.activeName=0;
            this.handleClick();
        },
        methods: {
            handleClick(tab, event) {
              this.activeName=tab.name;
              this.getData();
            },
            handleSizeChange(size) {
              this.pagesize = size
            },
            handleCurrentChange(currentPage) {
              this.currentPage = currentPage
            },
            handleRemove(file, fileList) {
                console.log(file, fileList);
              },
            onSubmit() {
                console.log('submit!');
            },
            details(row){
              console.log(row.order_number);
  					  this.$router.push({path:'/table/basic/details',query: {on:row.order_number}})
  				  },
            // 获取数据
            async getData() {
                const result = await axios.get(Rootpath.BASE_URL + 'orderList?state='+this.activeName);
                console.log(result);
                this.orderList = result.data.orderList;
                this.total = result.data.orderList.length;
            },
          },

    }
</script>
<style>
    @font-face {
        font-family: 'iconfont';
        /* project id 1395133 */
        src: url('//at.alicdn.com/t/font_1395133_9kv1q4q8mkt.eot');
        src: url('//at.alicdn.com/t/font_1395133_9kv1q4q8mkt.eot?#iefix') format('embedded-opentype'), url('//at.alicdn.com/t/font_1395133_9kv1q4q8mkt.woff2') format('woff2'), url('//at.alicdn.com/t/font_1395133_9kv1q4q8mkt.woff') format('woff'), url('//at.alicdn.com/t/font_1395133_9kv1q4q8mkt.ttf') format('truetype'), url('//at.alicdn.com/t/font_1395133_9kv1q4q8mkt.svg#iconfont') format('svg');
    }
    .iconfont {
        font-family: "iconfont" !important;
        font-size: 16px;
        font-style: normal;
        -webkit-font-smoothing: antialiased;
        -webkit-text-stroke-width: 0.2px;
        -moz-osx-font-smoothing: grayscale;
    }
    .right {
        margin-bottom: 5px;
        float: right;
    }
    /* 分页的样式 */
    .paging {
        position: fixed;
        right: 0px;
        bottom: 0px;
        background: #FAFAFA;
        width: 100%;
        height: 40px;
        float: right;
        line-height: 0px;
        z-index: 999;
        box-shadow: darkgrey 10px 10px 30px 5px;
    }
</style>
