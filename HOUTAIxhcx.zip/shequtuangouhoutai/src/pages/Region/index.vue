<template>
  <div class="Region-page">
      <el-tabs v-model="activeName">
  <!-- 区域 -->
      <el-tab-pane label="区域" name="first">
        <div class="hearsearch">
          <el-form :inline="true" :model="formInline" class="flex_m hearbtn">
            <el-form-item label="区域名称" style="margin-left:2%"><el-input size="small" v-model="formInline.Name" style="width: 120px;"></el-input></el-form-item>
            <el-form-item><el-button size="small" type="primary">搜索</el-button></el-form-item>
          </el-form>
        </div>
        <div class="addbtn flex_m">
          <el-button size="mini" name="button" type="primary" @click="addRegion = true">新增</el-button>
        </div>

        <el-table
            :data="Distributionroute"
            stripe
            style="width: 100%;width: 96%;
            margin: 0 auto;">
            <el-table-column
              prop="region"
              align="center"
              label="区域名称">
            </el-table-column>
            <el-table-column
              prop="region_leader"
              align="center"
              label="总团长数">
            </el-table-column>
          <el-table-column
            prop="create_time"
            align="center"
            label="开通时间">
          </el-table-column>
          <el-table-column
            prop="address"
            align="center"
            label="操作">
             <template slot-scope="scope">
               <el-button type="text" @click="editRegion = true">修改</el-button>
               <el-button type="text" @click="deleterow(scope.$index, Distributionroute)">删除</el-button>
             </template>
          </el-table-column>
          </el-table>
      </el-tab-pane>

      <!-- 新增弹出框 -->
      <el-dialog title="新增区域" class="layoutbox" :visible.sync="addRegion">
        <el-form :model="addform" :rules="rules" ref="addform" label-width="100px" class="demo-ruleForm">
          <el-form-item class="leftlabel" label="区域名称：" prop="region"><el-input class="inputtext" v-model="addform.region"></el-input></el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="addRegion = false">取 消</el-button>
          <el-button type="primary" @click="addsave">确 定</el-button>
        </span>
      </el-dialog>
      <!-- 新增弹出框  结束-->

      <!-- 编辑弹出框 -->
      <el-dialog title="编辑区域" class="layoutbox" :visible.sync="editRegion">
        <el-form :model="editform" :rules="rules" ref="editform" label-width="100px" class="demo-ruleForm">
          <el-form-item class="leftlabel" label="区域名称：" prop="name"><el-input class="inputtext" v-model="editform.region_id"></el-input></el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="editRegion = false">取 消</el-button>
          <el-button type="primary" @click="editsave">确 定</el-button>
        </span>
      </el-dialog>
      <!-- 编辑弹出框  结束-->
    </el-tabs>
  </div>
</template>
<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
  data(){
    return{
      activeName: 'first',
      Distributionroute:[],
      addRegion:false,
      editRegion:false,
      formInline: {
				user: '',
				region: '',
				Name: '',
				times: '',
				Mobilephone: '',
				Names: ''
			},
      editform: {
          region_id: '',
        },
      addform: {
          region: '',
        },
        ruleForm: {
  				name: '',
  				region: '',
  				date1: '',
  				date2: '',
  				delivery: false,
  				type: [],
  				resource: '',
  				desc: ''
  			},
  			rules: {
  				name: [{ required: true, message: '请输入活动名称', trigger: 'blur' }, { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }],
  				region: [{ required: true, message: '请选择活动区域', trigger: 'change' }],
  				date1: [{ type: 'date', required: true, message: '请选择日期', trigger: 'change' }],
  				date2: [{ type: 'date', required: true, message: '请选择时间', trigger: 'change' }],
  				type: [{ type: 'array', required: true, message: '请至少选择一个活动性质', trigger: 'change' }],
  				resource: [{ required: true, message: '请选择活动资源', trigger: 'change' }],
  				desc: [{ required: true, message: '请填写活动形式', trigger: 'blur' }]
  			}

    }
  },
  methods:{
    // 获取数据
      async getData() {
        const result = await axios.get(Rootpath.BASE_URL + 'region_list');
        this.Distributionroute = result.data.region_list
        this.total = result.data.region_list.length
      },
      addsave(){
        let that=this;
        axios.post(Rootpath.BASE_URL + 'region_add', {
            region: that.addform.region
        })
        .then(function (response) {
            that.addRegion = false;
        })
        .catch(function (error) {
            console.log(error);
        });
      },
      editsave(){
        let that=this;
        axios.post(Rootpath.BASE_URL + 'region_edit', {
            region_id: that.editform.region_id
        })
        .then(function (response) {
            that.editRegion = false;
        })
        .catch(function (error) {
            console.log(error);
        });
      },
      deleterow(index,row){
        // console.log(row.id);
        row.splice(index, 1);
      },
  },
  created() {
    this.getData();
  },
};
</script>
<style scoped>
.Region-page{
  background: #ffffff;
  width: 95%;
  margin: 0 auto;
}
.Region-page .el-tabs__nav{
  margin-left: 20px;
}
.Region-page .el-tabs__header{
  background: #ffffff;
  margin-top: 50px;
}
.Region-page .el-form-item{
  margin-bottom: 0 !important;
}
.Region-page .hearsearch{
    background: #F5F5F5;
    width: 96%;
    margin: 0 auto;
  }
  .Region-page .hearbtn{
    line-height: 60px;
  }
  .Region-page .el-form-item__content{
    line-height:60px !important;
  }
  .Region-page .addbtn{
    height: 60px;
    width: 96%;
    margin: 0 auto;
  }
  .Region-page .layoutbox {
  	width: 50%;
  	margin: 0 auto;
  }
  .Region-page .el-dialog {
  	border-radius: 6px !important;
  }
  .Region-page .inputtext {
  	width: 75%;
  }
  /* .leftlabel label{
    width: 100px !important;
  } */
  .Region-page .el-dialog__header {
  	border-bottom: 1px solid #d8d8d8;
  }
  .Region-page .el-dialog__footer {
  	border-top: 1px solid #d8d8d8;
  }
  .Region-page .el-form-item__label{
    line-height: 60px;
  }
</style>
