<template>
  <div class="RegionMap-page">
    <el-tabs v-model="activeName" @tab-click="handleClick">
    <el-tab-pane label="用户管理" name="first">
        <el-container style="height: 700px;">
          <el-aside width="180px">
            <el-button type="primary" name="button" size="small">收起区域<i class="el-icon-arrow-right el-icon--right"></i></el-button>
            <ul style="padding-left:0px;">
              <li class="areali" v-for="(item,index) in area" :key="index">
              <el-checkbox>{{item.name}}</el-checkbox></li>
            </ul>
          </el-aside>

          <el-container>
            <el-header class="flex" style="height:50px">
              <div class="">
                <span>全部团长数量:&nbsp;&nbsp;3</span>
              </div>
              <div class="" style="margin-left:55px">
                <span>所选区域团长数:&nbsp;&nbsp;3</span>
              </div>
            </el-header>
            <el-main>
              <!-- 自定义地图弹层 -->
       			 <div class="layertopostition" v-show="ifshow">
       				 <div id="container" class="map"></div>
               <div class="mapbuttom">
                 <el-input id='lnglat' type="text" value='116.39,39.9'  style="width:160px;padding-right:10px;"></el-input>
        				  <el-input  id='address' type="text"  style="width:450px;padding-right:110px;"></el-input>
                        <el-button @click="ifshow = false">取 消</el-button>
        			    <el-button type="primary" @click="determines()">确 定</el-button>
               </div>
             </div>
            </el-main>
          </el-container>
        </el-container>

      </el-tab-pane>


  </el-tabs>
  </div>
</template>
<script>

export default {
  data(){
    return{
      activeName: 'first',
      checked: true,
      ifshow:false,//经纬度弹层
      City:[],/* 存储返回的城市地址 */
      area:[
        {name:"青秀区"},
        {name:"兴宁区"},
        {name:"江南区"},
        {name:"西乡塘去"},
        {name:"邕宁区"},
        {name:"良庆区"},
        {name:"武鸣区"},
      ]
    }
  },
  methods: {
     handleClick(tab, event) {
       console.log(tab, event);
     },
     position() {
        var THis = this;
        var City = THis.City;
        var map = new AMap.Map("container", {
            resizeEnable: true
        });

        AMap.plugin('AMap.Geolocation', function () {
            var geolocation = new AMap.Geolocation({
                enableHighAccuracy: true, //是否使用高精度定位，默认:true
                timeout: 10000, //超过10秒后停止定位，默认：5s
                buttonPosition: 'RB', //定位按钮的停靠位置
                buttonOffset: new AMap.Pixel(10, 20), //定位按钮与设置的停靠位置的偏移量，默认：Pixel(10, 20)
                zoomToAccuracy: true, //定位成功后是否自动调整地图视野到定位点
            });
            map.addControl(geolocation);
            AMap.event.addListener(geolocation, 'complete', onComplete); // 返回定位信息
        });
        var geocoder = new AMap.Geocoder({
            city: "010", //城市设为北京，默认：“全国”
            radius: 1000 //范围，默认：500
        });

        function onComplete(obj) {
            var res = JSON.stringify(obj.addressComponent, null, 4);
        }
        var marker = new AMap.Marker();;

        function regeoCode() {

            var lnglat = document.getElementById('lnglat').value.split(',');
            map.add(marker);
            marker.setPosition(lnglat);
            geocoder.getAddress(lnglat, function (status, result) {
                if (status === 'complete' && result.regeocode) {
                    var address = result.regeocode.formattedAddress;
                    document.getElementById('address').value = address;
                    THis.City = result.regeocode.formattedAddress;
                } else {
                    log.error('根据经纬度查询地址失败')
                }
            });
        }

        map.on('click', function (e) {
            document.getElementById('lnglat').value = e.lnglat;
            regeoCode();
        })
        document.getElementById('lnglat').onkeydown = function (e) {
            if (e.keyCode === 13) {
                regeoCode();
                return false;
            }
            return true;
        };
    },
    /* 地图层用户点击的时候push地址数据到选择栏,然后关闭布尔值控制 */
    determines() {
        var City = this.City;
        document.getElementById('Citys').value = City; //将获取到的数据添加到详细地址里面
        this.ifshow = false;

    },
    /* swith经纬度的自定义弹层 */
    alertpostiton() {
        this.position();
        this.ifshow = true;
    }
},
beforeUpdate() {
    this.position();
},
mounted() {
    this.alertpostiton();
},
};


</script>
<style scoped>
.RegionMap-page{
  width: 96%;
  margin: 0 auto;
  background: #ffffff;
  margin-top: 40px;
  height: 750px;
}
.RegionMap-page .el-tabs__nav,
.RegionMap-page .el-tabs__content{
  margin-left: 20px;
}
  .RegionMap-page .leftview{
    width: 20%;
    height: 700px;
  }
  .RegionMap-page .review{
    /* width: 70%; */
    height: 700px;
  }
  .RegionMap-page li{
    list-style: none;
  }
  .RegionMap-page .areali{
    border-bottom: 1px solid #D8D8D8;
    line-height: 40px;
    width: 70%;
    margin: 0 auto;
  }
  .RegionMap-page ul{
    border:1px solid rgba(216,216,216,1);
    width: 90%;
    height: 90%;
  }
  .RegionMap-page .Layertop{
    font-size:15px;
    margin-top:25px;
  }
  .RegionMap-page .Layerto{
    margin-top:17px;
  }
  .RegionMap-page .map{
    margin-top:0%;
    height: 100%;
    width: 100%;
    border-radius:5px;
  }
  .RegionMap-page .layertopostition{
    background:rgb(210, 211, 214);
    height:99%;
    width: 100%;
  }
  .RegionMap-page .el-main{
    padding: 0
  }
  .RegionMap-page .mapbuttom{
    display: none;
  }
  .RegionMap .el-message-box__message p{
    top: 0;
  }
</style>
