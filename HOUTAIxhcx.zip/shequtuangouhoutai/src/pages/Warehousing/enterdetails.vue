<template>
	<div class="select enterdetails-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="入库管理详情" name="first"></el-tab-pane></el-tabs>
			<h4>基本信息</h4>
			<el-row>
				<!--第一-->
				<el-col :span="12">
					<div class="grid-content bg-purple ">
						<ul>
							<li class="flex ">
								<div class="labeltext">
									配送单号：
								</div>
								<div class="labeltext">
									{{basic_info.storage_number}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									单据日期：
								</div>
								<div class="labeltext">
									{{basic_info.storage_time}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									入库类型：
								</div>
								<div class="labeltext">
									{{basic_info.storage_type}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									备注：
								</div>
								<div class="labeltext">
									{{basic_info.remark}}
								</div>
							</li>
						</ul>
					</div>
				</el-col>
				<!--第二-->
				<el-col :span="12">
					<div class="grid-content bg-purple">
						<ul>
							<li class="flex ">
								<div class="labeltext">
									入库时间：
								</div>
								<div class="labeltext">
									{{basic_info.input_tiem}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									仓库：
								</div>
								<div class="labeltext">
									{{basic_info.warehouse_name}}
								</div>
							</li>
							<li class="flex ">
								<div class="labeltext">
									关联单号：
								</div>
								<div class="labeltext">
									{{basic_info.purchase_bill}}
								</div>
							</li>
						</ul>
					</div>
				</el-col>
				<!--交货日期-->
			</el-row>
			<el-table :data="goodsList" tooltip-effect="dark" style="width: 100%">
				<!-- <el-table-column align="center"width="55"></el-table-column> -->
				<el-table-column align="center" prop="product_name" label="商品名称" ></el-table-column>
				<el-table-column align="center" prop="describe" label="描述" ></el-table-column>
				<el-table-column align="center" prop="units" label="单位"></el-table-column>
				<el-table-column align="center" prop="storage_count" label="入库数量"></el-table-column>
				<el-table-column align="center" prop="actual_storage_count" label="实际入库数量"></el-table-column>
				<el-table-column align="center" prop="price_total" label="单价"></el-table-column>
				<el-table-column align="center" prop="price" label="金额"></el-table-column>
				<!-- <el-table-column align="center"prop="not" label="库区"></el-table-column>
				<el-table-column align="center"prop="total" label="库位"></el-table-column> -->
			</el-table>
			<div class="footer top">
				<span>合计：</span>
				<span style="color: #436BE5">{{Calculation}}</span>
			</div>

			<br />
			<h4>单据操作历史</h4>
			<el-table :data="record" tooltip-effect="dark" style="width: 100%">
				<el-table-column align="center" prop="operator" label="操作人"></el-table-column>
				<el-table-column align="center" prop="operator_time" label="时间"></el-table-column>
				<el-table-column align="center" prop="operator_type" label="类型"></el-table-column>
				<el-table-column align="center" prop="operator_Record" label="日志"></el-table-column>
			</el-table>
			<br />
			<br />
			<el-button size="small" type="primary" @click="returnback">返回</el-button>
		</div>
		<br />
	</div>
</template>

<script>
import axios from '../../axios.js';
import https from "../../../api/https.vue"
import Rootpath from "../../../api/index.js"
import qs from '../../../node_modules/qs'
export default {
	data() {
		return {
			activeName: 'first',
			basic_info: [],
			goodsList:[],
			record:[],
		};
	},
	//计算属性
	computed:{
			 Calculation:function(){
	 			let gl=this.goodsList;
	 			let t=0;
	 			for (var i = 0; i < gl.length; i++) {
	 				t+=gl[i].actual_storage_count * gl[i].price_total;
	 			}
	 			return t;
	 		}
	 },
	created() {
			this.getData();
	},
	methods: {
		async getData() {
		    var storage_number = this.$route.query.sno
		    const result = await axios.get(Rootpath.BASE_URL + 'storageInfo?sno=' + storage_number);
				this.basic_info=result.data.info.basic_info;
				this.goodsList=result.data.info.goodsList;
				this.record=result.data.info.record;
		},
		returnback(){
			this.$router.push({path:'/library/enter'})
		}
	}
};
</script>

<style scoped>
.grid-content {
	height: 160px;
	font-size: 8px;
}
.labeltext{
	font-size: 14px;
	line-height: 30px
}
.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
	.footer{
		text-align: right;
	}
</style>
