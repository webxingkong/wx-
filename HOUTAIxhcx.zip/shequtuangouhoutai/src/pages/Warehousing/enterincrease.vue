<template>
	<div class="select enterincrease-page">
		<div class="select-table">
			<el-tabs v-model="activeName"><el-tab-pane label="新增入库" name="first"></el-tab-pane></el-tabs>
			<h4>基本信息</h4>
			<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				<el-row>
					<!--类型-->
					<el-col :span="8">
							<el-form-item label="入库仓库:" style="margin-top: 20px;">
								<el-select v-model="price" placeholder="默认" size="small" style="width: 200px;">
									<el-option v-for="item in option" :key="item.price" :label="item.labe" :value="item.price" :disabled="item.disabled"></el-option>
								</el-select>
							</el-form-item>
					</el-col>
					<!--仓库-->
					<el-col :span="8">
							<el-form-item label="入库类型:" style="margin-top: 20px;">
								<el-select :disabled="true" v-model="value" placeholder="其他出库" size="small" style="width: 200px;">
								</el-select>
							</el-form-item>
					</el-col>
				</el-row>
				制单人：张老板
			</el-form>
<br>
			<h4>入库商品清单</h4>
			<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
				<el-row>
					<el-col :span="8">
						<div class="grid-content bg-purple">
							<el-form-item label="商品" style="margin-top: 20px;">
								<el-input size="small" v-model="formInline.states" placeholder="请选择商品名称/编码/关键字" style="width: 200px;"></el-input>
							&emsp;
							<el-button size="small" type="primary"  @click="dialogTableVisible = true">选择商品</el-button>
							</el-form-item>
						</div>
					</el-col>

					<el-col :span="8">
						<div class="grid-content bg-purple">
							<el-form-item label="数量" style="margin-top: 20px;">
								<el-input size="small" v-model="formInline.state" placeholder="请输入数字" style="width: 200px;"></el-input>
								&emsp;
								<el-button size="small" type="primary" @click="open">添加</el-button>
							</el-form-item>
						</div>
					</el-col>
				</el-row>
			</el-form>
			<!--表单-->
			<div>
				<el-table :data="tableData" style="width: 100%" max-height="250">
					<el-table-column prop="shop" label="商品名称" width="150"></el-table-column>
					<el-table-column prop="name" label="描述" width="120"></el-table-column>
					<el-table-column prop="province" label="单位" width="120"></el-table-column>
					<el-table-column prop="address" label="入库数量" width="120">
						<input  style="width: 50px;"></input>
					</el-table-column>
					<el-table-column prop="zip" label="单价" width="120"><input  style="width: 50px;"></input></el-table-column>
					<el-table-column prop="zips" label="金额" width="120"></el-table-column>
					<el-table-column prop="area" label="库区" width="120"></el-table-column>
					<el-table-column prop="position" label="库位" ></el-table-column>
					<el-table-column fixed="right" label="操作" width="50">
						<template slot-scope="scope">
							<el-button @click.native.prevent="deleteRow(scope.$index, tableData)" type="text" size="small">移除</el-button>
						</template>
					</el-table-column>
				</el-table>
				<br><br>
				<span>备注 ： </span>
				<el-input
				  type="textarea"
				  :autosize="{ minRows: 2, maxRows: 4}"
				  placeholder="请输入内容"
				  v-model="textarea2" style=" width: 500px;">
				</el-input>
			</div>
			<br></br>
			<el-button size="small" type="primary">保存</el-button>&emsp;
			<el-button size="small" >取消</el-button>
		</div><br>
	<el-dialog title="请选择商品" :visible.sync="dialogTableVisible" width="60%">
				<el-form :inline="true" :model="formInline" class="demo-form-inline search-Button">
					<el-form-item label="商品名称" style="margin-top: 20px;"><el-input size="small" v-model="formInline.goodsname" style="width: 120px;"></el-input></el-form-item>
					<el-form-item label="商品编码" style="margin-top: 20px;"><el-input size="small" v-model="formInline.goodscode" style="width: 120px;"></el-input></el-form-item>

					<el-form-item><el-button size="small" type="primary" @click="onSubmit" style="margin-top: 23px;">搜索</el-button></el-form-item>
				</el-form>

				<el-table ref="multipleTable" :data="gridData" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
					<el-table-column type="selection" width="55"></el-table-column>
					<el-table-column prop="name" label="商品名称" width="110"></el-table-column>
					<el-table-column prop="code" label="名称编码" width="120"></el-table-column>
					<el-table-column prop="Company" label="单位" width="70"></el-table-column>
					<el-table-column prop="class" label="商品分类" width="120"></el-table-column>
					<el-table-column prop="Warehouse" label="仓库" width="100"></el-table-column>
					<el-table-column prop="Price" label="价格" width="100"></el-table-column>
					<el-table-column prop="Stock" label="库存" width="100"></el-table-column>
					<el-table-column prop="address" label="数量">
						<input style="width: 44px;"></input>
					</el-table-column>
				</el-table>
				<br />
				<br />
				<!--分页-->
				 <el-pagination class="block"
				     background
				     @size-change="handleSizeChange"
				     @current-change="handleCurrentChange"
				     :current-page="currentPage"
				     :page-sizes="[5, 10, 20, 50]"
				     :page-size="pagesize"
				     layout="total, sizes, prev, pager, next, jumper"
				     :total="total">
				   </el-pagination>
				<br />
				<div style="text-align: right;"><el-button size="small" type="primary">选择</el-button></div>
			</el-dialog>
	</div>
</template>
<script>
export default {
	data() {
		return {
			 textarea2: '',
			activeName: 'first',
			tableData: [
				{
					shop:'八宝粥500g/一罐',
					name:'说明',
					province:'盒',
					city:'00.0/0',
					zips:'￥12.0',
					area:'什么',
					position:'不知道'


				},
				{
				shop:'八宝粥500g/一罐',
				name:'说明',
				province:'盒',
				city:'00.0/0',
				zips:'￥12.0'
				}
			],
			formInline: {
				user: '',
				region: '',
				Name: '',
				times: '',
				Mobilephone: '',
				Names: '',
				states: '',
				state: ''
			},
			option: [
				{
					price: '选项1',
					labe: '农贸市场'
				},
				{
					price: '选项2',
					labe: '南宁农贸市场'
				},
				{
					price: '选项3',
					labe: '北海农贸市场'
				},
				{
					price: '选项4',
					labe: '就是农贸市场'
				},
				{
					price: '选项5',
					labe: '石埠农贸市场'
				}
			],
			price: '',

			gridData: [{
			          name: '八宝粥',
					  code:'SFS65986',
					  Company:'盒',
					  class:'饮品',
					  Warehouse:'默认',
					  Price:'￥12.0',
					  Stock:'500'
			        }, {
			         name: '八宝粥',
			         code:'SFS65986',
			         Company:'盒',
			         class:'饮品',
			         Warehouse:'默认',
			         Price:'￥12.0',
			         Stock:'500'
			        }, {
			          name: '八宝粥',
			          code:'SFS65986',
			          Company:'盒',
			          class:'饮品',
			          Warehouse:'默认',
			          Price:'￥12.0',
			          Stock:'500'
			        }, {
			          name: '八宝粥',
			          code:'SFS65986',
			          Company:'盒',
			          class:'饮品',
			          Warehouse:'默认',
			          Price:'￥12.0',
			          Stock:'500'
			        }],
			        dialogTableVisible: false,
		};
	},
	methods: {
		onSubmit() {
			console.log('submit!');
		},
		//详情
		Accessdetails(Accessdetails) {
			this.$router.push({ path: '/library/Access/Accessdetails', query: { id: Accessdetails } });
		},
		  deleteRow(index, rows) {
		        rows.splice(index, 1);
		      },
			  //商品添加失败
			  	open() {
			  		this.$confirm('商品有误无法添加', '有误', {
			  			confirmButtonText: '确定',
			  			type: 'error'

			  		})


			  	},
		//分页
		handleSizeChange(size) {
		  this.pagesize = size
		},
		handleCurrentChange(currentPage) {
		  this.currentPage = currentPage
		},
	}
};
</script>

<style scoped>
	.block{
		text-align: right;
	}
.el-col {
	border-radius: 4px;
}
.select-table {
		margin: auto;
		width: 96%;
		margin-top: 20px;
	}
	.select {
		margin: auto;
		width: 96%;
		background-color: #ffffff;
	}
</style>
