// 菜单配置
// headerMenuConfig：头部导航配置
// asideMenuConfig：侧边导航配置

const headerMenuConfig = [];

const asideMenuConfig = [
  {
    path: '/dashboard',
    name: '商品',
    icon: 'el-icon-goods',
    children: [
      { path: '/analysis', name: '商品档案', id: 'Menu_j5bwp' },
      { path: '/monitor', name: '商品分类', id: 'Menu_kosxw' },
      { path: '/workplace', name: '辅助资料', id: 'Menu_ubk2k' },
      { name: '商品图片', id: 'Menu_wiqhg', path: '/img' },
    ],
    id: 'Menu_0cu5v',
  },
  {
    path: '/table',
    name: '订单',
    icon: 'el-icon-tickets',
    children: [
      { path: '/basic', name: '订单管理', id: 'Menu_73ihv' },
      { path: '/fixed', name: '售后管理', id: 'Menu_7jd7n' },
      { name: '售后原因', path: '/cause', id: 'Menu_cxvwb' },
      { name: '取消订单', path: '/order', id: 'Menu_g92yf' },
    ],
    id: 'Menu_058b6',
  },
  {
    path: '/form',
    name: '会员',
    icon: 'el-icon-user',
    children: [
      { path: '/Members', name: '会员管理', id: 'Menu_y6afi' },
      { path: '/signup', name: '会员等级', id: 'Menu_vu85r' },
      { name: '会员标签', path: '/tag', id: 'Menu_t50o9' },
      { name: '会员积分', path: '/integral', id: 'Menu_0idqf' },
    ],
    id: 'Menu_yg69n',
  },
  {
    path: '/charts',
    name: '团长',
    icon: 'el-icon-star-off',
    children: [
      { path: '/line', name: '团长管理', id: 'Menu_jiylr' },
      { path: '/histogram', name: '团长等级', id: 'Menu_vcrqs' },
      { path: '/bar', name: '配送单', id: 'Menu_8ipjs' },
      { name: '异常配送单', path: '/abnormal', id: 'Menu_m0xc2' },
      { name: '配送汇总', path: '/collect', id: 'Menu_w0iw7' },
      { name: '团长排名', path: '/ranking', id: 'Menu_3xpe6' },
      { name: '团长推荐', path: '/recommend', id: 'Menu_gu1jy' },
    ],
    id: 'Menu_n6cej',
  },
  {
    path: '/profile',
    name: '采购',
    icon: 'el-icon-shopping-cart-full',
    children: [
      { path: '/success', name: '采购单', id: 'Menu_lqgox' },
      { path: '/fail', name: '采购退回', id: 'Menu_3q6po' },
      { name: '供应商', id: 'Menu_e3rwq', path: '/Supplier' },
      { name: '采购员', path: '/Buyer', id: 'Menu_mrrrp' },
    ],
    id: 'Menu_awsf6',
  },
  {
    name: '库房',
    children: [
      { name: '发货出库', id: 'Menu_v7sq6', path: '/hair' },
      { name: '入库管理', path: '/enter', id: 'Menu_js8nn' },
      { name: '出库管理', id: 'Menu_xh1rn', path: '/Out' },
      { name: '现有库存', id: 'Menu_srl9c', path: '/Stock' },
      { name: '出入库存', id: 'Menu_b176a', path: '/Access' },
      { name: '仓库档案', id: 'Menu_b2bxo', path: '/archives' },
    ],
    id: 'Menu_wgia6',
    path: '/library',
    icon: 'el-icon-house',
  },
  {
    name: '配送',
    children: [
      { name: '配送方式', id: 'Menu_081q4', path: '/give' },
      { name: '配送路线', path: '/distributionroute', id: 'Menu_dv0xh' },
      { name: '区域', path: '/region', id: 'Menu_cl9x1' },
      { name: '配送地图', path: '/regionMap', id: 'Menu_lr74w' },
    ],
    id: 'Menu_xge2o',
    path: '/Delivery',
    icon: 'el-icon-truck',
  },
  {
    name: '营销',
    children: [
      { name: '秒杀商品', path: '/Seckill', id: 'Menu_uj5dk' },
      { name: '首页精选', id: 'Menu_w91uf', path: '/network' },
      { name: '优惠劵', path: '/Discount', id: 'Menu_9e6ar' },
    ],
    id: 'Menu_hnvnn',
    path: '/market',
    icon: 'el-icon-monitor',
  },
  {
    name: '商城',
    children: [
      { name: '页面装修', id: 'Menu_a2i17', path: '/fruit' },
      { name: '积分商城', id: 'Menu_9iffd', path: '/integral' },
      { name: '转发设置', id: 'Menu_so7a8', path: '/Forward' },
    ],
    id: 'Menu_cjjfq',
    path: '/goodscity',
    icon: 'el-icon-s-shop',
  },
  {
    name: '财务',
    children: [
      { name: '团长结算', id: 'Menu_yui7m', path: '/finance' },
      { name: '团长提现', path: '/group', id: 'Menu_m3yvn' },
      { name: '会员结算', path: '/Settlement', id: 'Menu_wqug2' },
      { name: '会员提现', path: '/present', id: 'Menu_gmis3' },
      { name: '采购结算', path: '/procurecount', id: 'Menu_ni7aq' },
    ],
    id: 'Menu_cyst4',
    path: '/finance',
    icon: 'el-icon-notebook-2',
  },
  {
    name: '报表',
    children: [
      { name: '营业数据', id: 'Menu_aqdnl', path: '/surface' },
      { name: '商品销量', id: 'Menu_6tu3j', path: '/pin' },
      { name: '毛利统计', id: 'Menu_dbbtf', path: '/Statistics' },
      { name: '新营业数据', id: 'Menu_mlxcv', path: '/new' },
    ],
    id: 'Menu_5wft3',
    path: '/surface',
    icon: 'el-icon-data-line',
  },
  { name: '应用管理', path: '/app', id: 'Menu_susdl', icon: 'el-icon-menu' },
  {
    name: '设置',
    icon: 'el-icon-setting',
    children: [
      { name: '系统参数', id: 'Menu_i8uc7', path: '/system' },
      { name: '操作日志', id: 'Menu_cesv6', path: '/Journal' },
      { name: '打印配置', id: 'Menu_1jpqh', path: '/Printing' },
      { name: '修改密码', id: 'Menu_ejg5u', path: '/changepassword' },
    ],
    id: 'Menu_1mxxe',
    path: '/Setup',
  },
];

export { headerMenuConfig, asideMenuConfig };
