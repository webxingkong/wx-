//总后台
import Citymanage from '@/pages/Citymanage';
import Useragreement from '@/pages/Useragreement';
import Apply from '@/pages/Apply';
import Companyinformation from '@/pages/Companyinformation';
import Systemparameter from '@/pages/Systemparameter';
import Operation from '@/pages/Operation';
import Operator from '@/pages/Operator';
import Role from '@/pages/Role';
import Initialization from '@/pages/Initialization';

//商品档案编辑
import Sort from '@/pages/Sort';
import Data from '@/pages/Data';
import Img from '@/pages/Img';
import HeaderAsideLayout from '@/layouts/HeaderAsideLayout'; //导航组件
import NotFound from '@/pages/NotFound'; //404页面
import Dashboard from '@/pages/Dashboard/Dashboard'; //商品档案 editdashboard
import Editdashboard from '@/pages/Dashboard/editdashboard';
import Addnew from '@/pages/Dashboard/addnew';


// import Record from '@/pages/Record';
import Reason from '@/pages/Reason';

import Grade from '@/pages/Grade';

import Label from '@/pages/Label';
import Lntegral from '@/pages/Lntegral';
import GroupManage from '@/pages/GroupManage/index'; //
import Grroupedit from '@/pages/GroupManage/grroupedit'; //
import GroupGrade from '@/pages/GroupGrade';
import Delivery from '@/pages/Delivery/index'; //配送单
import Distribution_details from '@/pages/Delivery/Distribution_details'; //
import Abnormal from '@/pages/Abnormal';
import Summary from '@/pages/Summary';
import Ranking from '@/pages/Ranking';
import Recommend from '@/pages/Recommend';
// import Deposit from '@/pages/Deposit';
// import Rule from '@/pages/Rule';
// import Card from '@/pages/Card';
import Manage from '@/pages/Manage/index'; //
import Details from '@/pages/Manage/details'; //
import Service from '@/pages/Service';
import Cancel from '@/pages/Cancel';
import MembersManagement from '@/pages/MembersManagement/index'; //会员管理
import Detailed from '@/pages/MembersManagement/detailed'; //加会员管理详情

import Single from '@/pages/Single/index'; //采购单
import Buymore from '@/pages/Single/buymore'; //采购单新增
import Buydetails from '@/pages/Single/buydetails'; //采购单详情
import Return from '@/pages/Return/index'; //采购退回
import Returnplus from '@/pages/Return/returnplus'; //采购退回增加
import Returnfeeling from '@/pages/Return/returnfeeling'; //采购退回详情
import History from '@/pages/History';
import Supplier from '@/pages/Supplier/index'; //供应商
import Supplydetails from '@/pages/Supplier/supplydetails'; //供应商详情
import Supplyedit from '@/pages/Supplier/supplyedit'; //供应商编辑
import Supplyincrease from '@/pages/Supplier/supplyincrease '; //供应商新增

import Buyer from '@/pages/Buyer';
import Delivergoods from '@/pages/Delivergoods';
import Warehousing from '@/pages/Warehousing/index'; //入库管理
import Enterincrease from '@/pages/Warehousing/enterincrease'; //入库管理新增
import Enterdetails from '@/pages/Warehousing/enterdetails'; //入库管理详情
import OutAdministration from '@/pages/OutAdministration/index'; //出库管理
import Outincrease from '@/pages/OutAdministration/Outincrease'; //出库管理新增
import Outdetails from '@/pages/OutAdministration/Outdetails'; //出库管理详情
import Stock from '@/pages/Stock';
import Access from '@/pages/Access'; //出入库
import Accessdetails from '@/pages/Access/Accessdetails'; //出入库详情

import Archives from '@/pages/Archives';
import Give from '@/pages/Give';
// import Network from '@/pages/Network';营销
import Network from '@/pages/Network/index'; //营销
import New_selection from '@/pages/Network/New_selection'; //营销新增选择
import Fruit from '@/pages/Fruit';
import Finance from '@/pages/Finance/index'; //团长结算
import Settlement_details from '@/pages/Finance/Settlement_details'; //团长结算详情
import Surface from '@/pages/Surface';
import App from '@/pages/App';

import DistributionRoute from '@/pages/DistributionRoute'; //配送路线
import Region from '@/pages/Region'; //区域
import RegionMap from '@/pages/RegionMap'; //配送地图
import Integral from '@/pages/Integral';
import Forward from '@/pages/Forward';
import Group from '@/pages/Group';
import Settlement from '@/pages/Settlement/index'; //财务会员页
import Membership_details from '@/pages/Settlement/Membership_details'; //财务会员详情
import Present from '@/pages/Present';
import Procurecount from '@/pages/Procurecount';
import Pin from '@/pages/Pin';
import Statistics from '@/pages/Statistics';
import New from '@/pages/New';
import Index from '@/pages/Index';

import Seckill from '@/pages/Seckill/index'; //秒杀
import Spike_added from '@/pages/Seckill/Spike_added'; //秒杀新增
import Seckill_details from '@/pages/Seckill/Seckill_details'; //秒杀详情
import Seckill_copy from '@/pages/Seckill/Seckill_copy'; //秒杀详情

//秒杀复制活动
import Discount from '@/pages/Discount/index'; //优惠劵
import New_discount from '@/pages/Discount/New_discount'; //新增优惠劵
import Edit_Coupon from '@/pages/Discount/Edit_Coupon'; //编辑惠劵
import System from '@/pages/System';
import Journal from '@/pages/Journal';
import Printing from '@/pages/Printing';
import Changepassword from '@/pages/Changepassword';
import Login from '@/pages/Login';
const routerConfig = [
  {
    path: '/city',
    component: HeaderAsideLayout,
    children: [
      { path: '/city/citymanage', component: Citymanage },
    ],
  },
  {
    path: '/login',
    component: HeaderAsideLayout,
    children: [
      { path: '/login/login', component: Login },
    ],
  },
  {
    path: '/goodshop',
    component: HeaderAsideLayout,
    children: [
      { path: '/goodshop/useragreement', component: Useragreement },
      { path: '/goodshop/apply', component: Apply },
    ],
  },
  {
    path: '/dispose',
    component: HeaderAsideLayout,
    children: [
      { path: '/dispose/companyinformation', component: Companyinformation },
      { path: '/dispose/systemparameter', component: Systemparameter },
      { path: '/dispose/operation', component: Operation },
      { path: '/dispose/operator', component: Operator },
      { path: '/dispose/role', component: Role },
      { path: '/dispose/initialization', component: Initialization },
    ],
  },
  {
    path: '/form',
    component: HeaderAsideLayout,
    children: [
      { path: '/form/tag', component: Label },
      { path: '/form/signup', component: Grade },
      { path: '/form/integral', component: Lntegral },
      // { path: '/form/deposit', component: Deposit },
      // { path: '/form/rule', component: Rule },
      // { path: '/form/card', component: Card },
      { path: '/form/Members/Detailed', component: Detailed },
      { path: '/form/Members', component: MembersManagement },
    ],
  },
  { path: '*', component: NotFound },
  {
    path: '/charts',
    component: HeaderAsideLayout,
    children: [
      { path: '/charts/line/Grroupedit', component: Grroupedit },
      { path: '/charts/line', component: GroupManage },
      { path: '/charts/histogram', component: GroupGrade },
      {
        path: '/charts/bar/Distribution_details',
        component: Distribution_details,
      },
      { path: '/charts/bar', component: Delivery },
      { path: '/charts/abnormal', component: Abnormal },
      { path: '/charts/collect', component: Summary },
      { path: '/charts/ranking', component: Ranking },
      { path: '/charts/recommend', component: Recommend },
    ],
  },
  {
    path: '/profile',
    component: HeaderAsideLayout,
    children: [
      { path: '/profile/history', component: History },
      { path: '/profile/success/Buydetails', component: Buydetails },
      { path: '/profile/Supplier/Supplyincrease', component: Supplyincrease },
      { path: '/profile/fail/Returnplus', component: Returnplus },
      { path: '/profile/fail/Returnfeeling', component: Returnfeeling },
      { path: '/profile/fail', component: Return },
      { path: '/profile/success/Buymore', component: Buymore },
      { path: '/profile/Supplier/Supplydetails', component: Supplydetails },
      { path: '/profile/Supplier/Supplyedit', component: Supplyedit },
      { path: '/profile/Supplier', component: Supplier },
      { path: '/profile/success', component: Single },
      { path: '/profile/Buyer', component: Buyer },
    ],
  },
  {
    path: '/goodscity',
    component: HeaderAsideLayout,
    children: [
      { path: '/goodscity/fruit', component: Fruit },
      { path: '/goodscity/integral', component: Integral },
      { path: '/goodscity/useragreement',component:Useragreement },
      // { path: '/goodscity/apply',component:Apply },
      { path: '/goodscity/Forward', component: Forward },
    ],
  },
  {
    path: '/table',
    component: HeaderAsideLayout,
    children: [
      // { path: '/table/record', component: Record },
      { path: '/table/cause', component: Reason },
      { path: '/table/basic/Details', component: Details },
      { path: '/table/basic', component: Manage },
      { path: '/table/fixed', component: Service },
      { path: '/table/order', component: Cancel },
    ],
  },
  {
    path: '/library',
    component: HeaderAsideLayout,
    children: [
      { path: '/library/Out/Outincrease', component: Outincrease },
      { path: '/library/hair', component: Delivergoods },
      { path: '/library/enter/Enterdetails', component: Enterdetails },
      { path: '/library/Out', component: OutAdministration },
      { path: '/library/Access/Accessdetails', component: Accessdetails },
      { path: '/library/enter/Enterincrease', component: Enterincrease },
      { path: '/library/Out/Outdetails', component: Outdetails },
      { path: '/library/Stock', component: Stock },
      { path: '/library/Access', component: Access },
      { path: '/library/enter', component: Warehousing },
      { path: '/library/archives', component: Archives },
    ],
  },
  {
    path: '/Delivery',
    component: HeaderAsideLayout,
    children: [
      { path: '/Delivery/give', component: Give },
      { path: '/delivery/distributionroute', component: DistributionRoute },
      { path: '/Delivery/regionMap', component: RegionMap },
      { path: '/Delivery/region', component: Region },
    ],
  },
  {
    path: '/market',
    component: HeaderAsideLayout,
    children: [
      { path: '/market/network/New_selection', component: New_selection },
      { path: '/market/network', component: Network },
      { path: '/market/Seckill/Spike_added', component: Spike_added },
      { path: '/market/Seckill/Seckill_details', component: Seckill_details },
      { path: '/market/Seckill/Seckill_copy', component: Seckill_copy },
      { path: '/market/Seckill', component: Seckill },
      { path: '/market/Discount', component: Discount },
	   { path: '/market/Discount/New_discount', component: New_discount },
	    { path: '/market/Discount/Edit_Coupon', component: Edit_Coupon },
    ],
  },
  {
    children: [
      {
        path: '/finance/finance/Settlement_details',
        component: Settlement_details,
      },
      { path: '/finance/finance', component: Finance },
      { path: '/finance/group', component: Group },
      {
        path: '/finance/Settlement/Membership_details',
        component: Membership_details,
      },
      { path: '/finance/Settlement', component: Settlement },
      { path: '/finance/present', component: Present },
      { path: '/finance/procurecount', component: Procurecount },
    ],
    path: '/finance',
    component: HeaderAsideLayout,
  },
  {
    path: '/surface',
    component: HeaderAsideLayout,
    children: [
      { path: '/surface/surface', component: Surface },
      { path: '/surface/pin', component: Pin },
      { path: '/surface/Statistics', component: Statistics },
      { path: '/surface/new', component: New },
      { path: '/surface/index', component: Index },
    ],
  },
  {
    path: '/app',
    component: HeaderAsideLayout,
    children: [{ path: '/app', component: App }],
  },
  {
    children: [
      { path: '/Setup/system', component: System },
      { path: '/Setup/Journal', component: Journal },
      { path: '/Setup/Printing', component: Printing },
      { path: '/Setup/changepassword', component: Changepassword },
    ],
    path: '/Setup',
    component: HeaderAsideLayout,
  },
  {
    path: '/',
    component: HeaderAsideLayout,
    children: [
      { path: '/pages/Label', component: Label },
      { path: '/dashboard/monitor', component: Sort },
      { path: '/dashboard/analysis', component: Dashboard },
      { path: '/dashboard/analysis/Editdashboard', component: Editdashboard },//商品档案
      { path: '/dashboard/analysis/Addnew', component: Addnew },//商品档案
      { path: '/dashboard/img', component: Img },
      { path: '/dashboard/workplace', component: Data },
    ],
  },
];

export default routerConfig;
