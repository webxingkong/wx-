// 菜单配置
// headerMenuConfig：头部导航配置
// asideMenuConfig：侧边导航配置

const headerMenuConfig = [];

const backMenuConfig = [
  {
    path: '/city',
    name: '城市',
    icon: 'el-icon-goods',
    children: [
      { path: '/citymanage', name: '城市管理', id: 'Menu_jback' },
    ],
    id: 'Menu_0cu5v',
  },
  {
    path: '/dashboard',
    name: '商品',
    icon: 'el-icon-goods',
    children: [
      { path: '/analysis', name: '商品档案', id: 'Menu_j5bwp' },
      { path: '/monitor', name: '商品分类', id: 'Menu_kosxw' },
      { path: '/workplace', name: '辅助资料', id: 'Menu_ubk2k' },
      { name: '商品图片', id: 'Menu_wiqhg', path: '/img' },
    ],
    id: 'Menu_0cu5v',
  },
  {
    path: '/table',
    name: '订单',
    icon: 'el-icon-tickets',
    children: [
      { path: '/basic', name: '订单管理', id: 'Menu_73ihv' },
      { path: '/fixed', name: '售后管理', id: 'Menu_7jd7n' },
      { name: '售后原因', path: '/cause', id: 'Menu_cxvwb' },
      { name: '取消订单', path: '/order', id: 'Menu_g92yf' },
    ],
    id: 'Menu_058b6',
  },
  {
    path: '/form',
    name: '会员',
    icon: 'el-icon-user',
    children: [
      { path: '/Members', name: '会员管理', id: 'Menu_y6afi' },
      { path: '/signup', name: '会员等级', id: 'Menu_vu85r' },
      { name: '会员标签', path: '/tag', id: 'Menu_t50o9' },
      { name: '会员积分', path: '/integral', id: 'Menu_0idqf' },
      { name: '会员预存款', id: 'Menu_aqj25', path: '/deposit' },
      { name: '充值规则', id: 'Menu_e4bfx', path: '/rule' },
      { name: '充值卡', id: 'Menu_eo28n', path: '/card' },
    ],
    id: 'Menu_yg69n',
  },
  {
    path: '/charts',
    name: '团长',
    icon: 'el-icon-star-off',
    children: [
      { path: '/line', name: '团长管理', id: 'Menu_jiylr' },
      { path: '/histogram', name: '团长等级', id: 'Menu_vcrqs' },
      { path: '/bar', name: '配送单', id: 'Menu_8ipjs' },
      { name: '异常配送单', path: '/abnormal', id: 'Menu_m0xc2' },
      { name: '配送汇总', path: '/collect', id: 'Menu_w0iw7' },
      { name: '团长排名', path: '/ranking', id: 'Menu_3xpe6' },
      { name: '团长推荐', path: '/recommend', id: 'Menu_gu1jy' },
    ],
    id: 'Menu_n6cej',
  },
  {
    name: '报表',
    children: [
      { name: '营业数据', id: 'Menu_aqdnl', path: '/surface' },
      { name: '商品销量', id: 'Menu_6tu3j', path: '/pin' },
      { name: '毛利统计', id: 'Menu_dbbtf', path: '/Statistics' },
      { name: '新营业数据', id: 'Menu_mlxcv', path: '/new' },
    ],
    id: 'Menu_5wft3',
    path: '/surface',
    icon: 'el-icon-data-line',
  },
  {
    name: '商城',
    children: [
      { name: '用户协议', id: 'Menu_a727', path: '/useragreement' },
      { name: '团长申请', id: 'Menu_9a727', path: '/apply' },
    ],
    id: 'Menu_c728a',
    path: '/goodshop',
    icon: 'el-icon-s-shop',
  },
  {
    name: '配置',
    icon: 'el-icon-setting',
    children: [
      { name: '企业信息', id: 'Menu_ici', path: '/companyinformation' },
      { name: '系统参数', id: 'Menu_isp', path: '/systemparameter' },
      { name: '操作日志', id: 'Menu_cop', path: '/operation' },
      { name: '操作员管理', id: 'Menu_1jot', path: '/operator' },
      { name: '角色管理', id: 'Menu_erol', path: '/role' },
      { name: '系统初始化', id: 'Menu_eitz', path: '/initialization' },
    ],
    id: 'Menu_1mxxe',
    path: '/dispose',
  },

];

export { headerMenuConfig, backMenuConfig };
