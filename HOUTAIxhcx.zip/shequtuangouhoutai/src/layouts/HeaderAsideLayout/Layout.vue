<template>
  <div class="app-wrapper">

    <!-- 左侧栏 -->
    <side-bar class="sidebar-container" />
    <!-- <side-bar v-if="realswitch==false" class="sidebar-container" /> -->
    <!-- <backstage-bar class="sidebar-container" /> -->
    <backstage-bar v-if="realswitch==true" class="sidebar-container" />
    <div class="main-container">
      <!-- 顶部 -->
      <nav-bar ref="child" />
      <app-main />
    </div>
  </div>
</template>

<script>
import { NavBar, SideBar, AppMain, BackstageBar } from './components';
export default {
  data() {
    return {
      realswitch:null
    }
  },
  name: 'Layout',
  components: {
    NavBar,
    SideBar,
    AppMain,
    BackstageBar,
  },

  created() {
  },
  methods:{
    switchleft(){
      this.realswitch=this.$refs.child.realswitch;
    },
  }
};
</script>

<style lang="scss" scoped>
.app-wrapper {
  position: relative;
  height: 100%;
  width: 100%;
  &:after {
    content: "";
    display: table;
    clear: both;
  }
}

.main-container {
  min-height: 100vh;
  transition: margin-left 0.28s;
  margin-left: 200px;
  background-color: #f0f2f5;
}
</style>
